'''
This is a idaPython script used for helping NS atmosphere cheat code production

This Script is Programmed by Eiffel2018
    Works in IDA PRO v7.5 up 
    Requirement: Python 3.9.x (with idapyswitch) and Keystone 
    Operate with a clean NSO (main.elf is preferred) 

How to get the AOB pattern?
    First you need to run the python/cheatGen.py once.
    then move the cursor to the place where you want to hack, 
    Trun the type of command line below the output windows from IDC to Python
    type getAOB() onto the command line
    You will get the AOB pattern in the output windows

What commands can be used in this file?
    AOB(pattern) return the first search result
    AllOccur(pattern) or AllOccur(pattern,offset) return all the search results found
    AOB2(pattern1,offset) return the address of a BL/B function inside [pattern1 + offset]
    AOB2(pattern1,offset,pattern2) return the result of second search, inside the BL/B function found by pattern1 + offset (pattern11 may be an address or pattern)
    AOB3(pattern1,pattern2) return the nearest result of second search from the first search. pattern2 may be an offset or pattern

    AddCheat(cheatname,cheatnameInChinese=None,newOption=0,isSuggest=False) newOption is default 0, it can be 1 and 2 if you want a/b/c/d/e sub index (1 for new index, 2 for next index)

    HackAll(pattern,codes,offset=0,showRestoreCode=True,useButton=None,elseCode=None) hack all the pattern found
    Hack(pattern,codes,showRestoreCode=True,useButton=None,elseCode=None,returnCode=False) hack one the first searched result 
    CodeCave(cheatAddr, codes, showrestoreCodes=True, use_BL=True, returnCode=False) a code cave function with caller address 
    CodeFunc(listOfCaveFunctionCodes) a function build into master code without call
    
    Float2DWord(float) a function returns Hex Text of a float
    Value2DWord(int)  a function returns Hex Text of a 32-bit integer

Note: 
    This python script cannot be used in GDB since the search function is very slow
    However you can use on a NSO and then copy the output result (codes generated) into the GDB environment (press F2, paste and execute)

'''
if 'GetBase' in dir(): ClearCache('cheatLib');ClearCache('idahelper')

import sys
sys.path.insert(1,'P:\GamesHandled\__python__') # <<<<<<<<< to be corrected
from cheatLib import *

################################ START ######################################

Init('It Takes Two' , '雙人成行', False)

juGameEngine = GetADRP(AOB('08 ? ? F9 13 01 40 F9 ? ? 00 B4 ? ? ? ? 68 0A 40 F9',0x1000,0x8000))
juWorld = GetADRP(AOB('08 ? ? F9 00 01 40 F9 ? ? 00 B4 ? ? ? ? 08 04 00 51',0x1000,0x8000))
if notFound(juGameEngine) or notFound(juWorld): halt('UGameEngine or UWorld not found!')
uGameEngine = GetQword(juGameEngine) 
uWorld = GetQword(juWorld)
# AddMasterCode(PointerCodeHeader((uWorld,0x180,0x38,0,0x30,0x260,0x288)))

# FpsCode(2,0x7a66c)
# FpsCode(4) # for normal games / unity games
FpsCode([1,3]) # for unreal engine

AddCheat('Enable Dynamic Resolution',1)
AddCheatCode(PointerCodeHeader([uGameEngine,0x228]))
AddCheatCode(PointerCodeAddRegister(0x29))
AddCheatCode(PointerCodeWrite(1,1,use_D=False))
AddCheat('Enable Dynamic Resolution',2)
AddCheatCode(PointerCodeHeader([uGameEngine,0x228]))
AddCheatCode(PointerCodeAddRegister(0x29))
AddCheatCode(PointerCodeWrite(1,0,use_D=False))

AddCheat('Enable Smooth Frame Rate',1)
AddCheatCode(PointerCodeHeader([uGameEngine]))
AddCheatCode(PointerCodeAddRegister(0x7A4))
AddCheatCode(PointerCodeWrite(1,0x27,use_D=False))
AddCheat('Enable Smooth Frame Rate',2)
AddCheatCode(PointerCodeHeader([uGameEngine]))
AddCheatCode(PointerCodeAddRegister(0x7A4))
AddCheatCode(PointerCodeWrite(1,0x07,use_D=False))

################################# END #######################################

HackComplete()

'''
[[main+ACF8858]+228]+29

uGameEngine [main+ACF8858]
    +228 UGameUserSettings
         +28        bool	UGameUserSettings.bUseVSync (9B4DFA0) 
         +29        bool	UGameUserSettings.bUseDynamicResolution (9B4DFD8) 
         +80         s32	UGameUserSettings.ResolutionSizeX (9B4E010) 
         +84         s32	UGameUserSettings.ResolutionSizeY (9B4E038) 
         +88         s32	UGameUserSettings.LastUserConfirmedResolutionSizeX (9B4E060) 
         +8C         s32	UGameUserSettings.LastUserConfirmedResolutionSizeY (9B4E088) 
         +90         u32	UGameUserSettings.WindowPosX (9B4E0B0) 
         +94         u32	UGameUserSettings.WindowPosY (9B4E0D8) 
         +98         u32	UGameUserSettings.FullscreenMode (9B4E100) 
         +9C         u32	UGameUserSettings.LastConfirmedFullscreenMode (9B4E128) 
         +A0         u32	UGameUserSettings.PreferredFullscreenMode (9B4E150) 
         +A4         s32	UGameUserSettings.Version (9B4E178) 
         +A8         u32	UGameUserSettings.AudioQualityLevel (9B4E1A0) 
         +AC         u32	UGameUserSettings.LastConfirmedAudioQualityLevel (9B4E1C8) 
         +B0       Float	UGameUserSettings.FrameRateLimit (9B4E1F0) 
         +B8         u32	UGameUserSettings.DesiredScreenWidth (9B4E218) 
         +BC        bool	UGameUserSettings.bUseDesiredScreenHeight (9B4E240) 
         +C0         u32	UGameUserSettings.DesiredScreenHeight (9B4E278) 
         +C4         u32	UGameUserSettings.LastUserConfirmedDesiredScreenWidth (9B4E2A0) 
         +C8         u32	UGameUserSettings.LastUserConfirmedDesiredScreenHeight (9B4E2C8) 
         +CC       Float	UGameUserSettings.LastRecommendedScreenWidth (9B4E2F0) 
         +D0       Float	UGameUserSettings.LastRecommendedScreenHeight (9B4E318) 
         +D4       Float	UGameUserSettings.LastCPUBenchmarkResult (9B4E340) 
         +D8       Float	UGameUserSettings.LastGPUBenchmarkResult (9B4E368) 
         +E0  FloatArray	UGameUserSettings.LastCPUBenchmarkSteps (9B4E3B8) 
         +F0  FloatArray	UGameUserSettings.LastGPUBenchmarkSteps (9B4E410) 
        +100       Float	UGameUserSettings.LastGPUBenchmarkMultiplier (9B4E440) 
        +104        bool	UGameUserSettings.bUseHDRDisplayOutput (9B4E468) 
        +108         u32	UGameUserSettings.HDRDisplayOutputNits (9B4E4A0) 
        +110  M.Delegate	UGameUserSettings.OnGameUserSettingsUINeedsUpdate (9B4E4C8) 
    +780 UGameViewportClient
    +7A0         u32	UEngine.MaximumLoopIterationCount (9B01EF0) 
    +7A4      bool^0	UEngine.bCanBlueprintsTickByDefault (9B01F18) 
    +7A4      bool^1	UEngine.bOptimizeAnimBlueprintMemberVariableAccess (9B01F50) 
    +7A4      bool^2	UEngine.bAllowMultiThreadedAnimationUpdate (9B01F88) 
    +7A4      bool^3	UEngine.bEnableEditorPSysRealtimeLOD (9B01FC0) 
    +7A4      bool^5	UEngine.bSmoothFrameRate (9B01FF8) 
    +7A4      bool^6	UEngine.bUseFixedFrameRate (9B02030) 
    +7A8       Float	UEngine.FixedFrameRate (9B02068) 
    +7AC  Struct(10)	UEngine.SmoothedFrameRateRange (9B02090) SDK('FloatRange')
    +7C0      Object	UEngine.CustomTimeStep (9B020C0) SDK('UEngineCustomTimeStep')
    +7E8  Struct(18)	UEngine.CustomTimeStepClassName (9B020F0) SDK('SoftClassPath')
    +800      Object	UEngine.TimecodeProvider (9B02120) SDK('UTimecodeProvider')
    +828  Struct(18)	UEngine.TimecodeProviderClassName (9B02150) SDK('SoftClassPath')
    +840        bool	UEngine.bGenerateDefaultTimecode (9B02180) 
    +844   Struct(8)	UEngine.GenerateDefaultTimecodeFrameRate (9B021B8) SDK('FrameRate')
    +84C       Float	UEngine.GenerateDefaultTimecodeFrameDelay (9B021E8) 
    +850      bool^0	UEngine.bCheckForMultiplePawnsSpawnedInAFrame (9B02210) 
    +854         u32	UEngine.NumPawnsAllowedToBeSpawnedInAFrame (9B02248) 
    +858      bool^0	UEngine.bShouldGenerateLowQualityLightmaps (9B02270) 
    +8D4       Float	UEngine.CameraRotationThreshold (9B02658) 
    +8D8       Float	UEngine.CameraTranslationThreshold (9B02680) 
    +8DC       Float	UEngine.PrimitiveProbablyVisibleTime (9B026A8) 
    +8E0       Float	UEngine.MaxOcclusionPixelsFraction (9B026D0) 
    +8E4      bool^0	UEngine.bPauseOnLossOfFocus (9B026F8) 
    +8E8         u32	UEngine.MaxParticleResize (9B02730) 
    +8EC         u32	UEngine.MaxParticleResizeWarn (9B02758) 
    +8F0Struct(28)Array	UEngine.PendingDroppedNotes (9B027B0) SDK('DropNoteInfo')
    +900       Float	UEngine.NetClientTicksPerSecond (9B027E0) 
    +904       Float	UEngine.DisplayGamma (9B02808) 
    +908       Float	UEngine.MinDesiredFrameRate (9B02830) 
    +90C  Struct(10)	UEngine.DefaultSelectedMaterialColor (9B02858) SDK('LinearColor')
    +91C  Struct(10)	UEngine.SelectedMaterialColor (9B02888) SDK('LinearColor')
    +92C  Struct(10)	UEngine.SelectionOutlineColor (9B028B8) SDK('LinearColor')
    +93C  Struct(10)	UEngine.SubduedSelectionOutlineColor (9B028E8) SDK('LinearColor')
    +94C  Struct(10)	UEngine.SelectedMaterialColorOverride (9B02918) SDK('LinearColor')
    +95C        bool	UEngine.bIsOverridingSelectedColor (9B02948) 
    +95D      bool^0	UEngine.bEnableOnScreenDebugMessages (9B02980) 
    +95D      bool^1	UEngine.bEnableOnScreenDebugMessagesDisplay (9B029B8) 
    +95D      bool^2	UEngine.bSuppressMapWarnings (9B029F0) 
    +95D      bool^3	UEngine.bDisableAILogging (9B02A28) 
    +960         s32	UEngine.bEnableVisualLogRecordingOnStart (9B02A60) 
    +964         u32	UEngine.ScreenSaverInhibitorSemaphore (9B02A88) 
    +968      bool^0	UEngine.bLockReadOnlyLevels (9B02AB0) 
    +970      String	UEngine.ParticleEventManagerClassPath (9B02AE8) 
    +980       Float	UEngine.SelectionHighlightIntensity (9B02B10) 
    +984       Float	UEngine.BSPSelectionHighlightIntensity (9B02B38) 
    +988       Float	UEngine.SelectionHighlightIntensityBillboards (9B02B60) 
    +BF8Struct(18)Array	UEngine.NetDriverDefinitions (9B02BB8) SDK('NetDriverDefinition')
    +C08 StringArray	UEngine.ServerActors (9B02C10) 
    +C18 StringArray	UEngine.RuntimeServerActors (9B02C68) 
    +C28       Float	UEngine.NetErrorLogInterval (9B02C98) 
    +C2C      bool^0	UEngine.bStartedLoadMapMovie (9B02CC0) 
    +C40         u32	UEngine.NextWorldContextHandle (9B02CF8) 
'''