#This Script is Programmed by Eiffel2018
# Works in IDA PRO v7.5+
# Requirement: Python 3.9.x (with idapyswitch)
#
# This script is used in IDA PRO with a NSO(elf) opened or new instance connected to GDB
#
# It is a helper library for making NS cheats
#
#

import idc, ida_bytes, ida_search, struct, idautils, sys, ida_kernwin, ida_funcs, idaapi, ida_segment, math, os, ida_nalt, re
from idahelper import *
from keystone import *

SetDebug(True)

english=''
VER = RGN = None
TM='E'
TM2='F'

dataAddr = BADADDR if isGDB() else ida_segment.get_segm_by_name('.bss').end_ea
            
def SetAsmRegister(register):
    global TM
    TM = register
def SetPtrRegister(register):
    global TM2
    TM2 = register

def Addr2DWord(opAddr):
    return "{:08X}".format(opAddr & 0xFFFFFFFF)
def Value2DWord(value):
    if type(value) is str: value=int(value.replace(' ',''), 16)
    return "{:08X}".format(value & 0xFFFFFFFF)
def Value2QWord(value):
    if type(value) is str: value=int(value.replace(' ',''), 16)
    return "{:08X} {:08X}".format(value // 0x100000000, value & 0xFFFFFFFF)
def Double2QWord(d):
    return Value2QWord(struct.unpack('<Q', struct.pack('<d', d))[0])
def Float2DWord(f):
    return Value2DWord(struct.unpack('<I', struct.pack('<f', f))[0])
def GetBytes(length,opAddr):
    return {1:ida_bytes.get_original_byte(opAddr), 2:ida_bytes.get_original_word(opAddr), 4:ida_bytes.get_original_dword(opAddr), 8:ida_bytes.get_original_dword(opAddr)}[length]

def CheatCode(length,opAddr,value):
    if opAddr>base and base>0x10000000: opAddr-=base
    if type(value) not in (list,tuple):
        if type(value) is str and re.match(r"^[0-9a-fA-F]{8}$", value[0:8]) is None: value=ASM(value) 
        if type(value) is int and length==4: value=Value2DWord(value)
        return '0{}0E0000 {} {}\n'.format(length,Addr2DWord(opAddr),Value2DWord(value) if length<=4 else Value2QWord(value))
    lastInstruction = ResultCode = ''
    for instruction in value:
        if type(instruction) is str: instruction=instruction.replace('{there}',OperandAddr(opAddr))
        if type(instruction) is str and re.match(r"^[0-9a-fA-F]{8}$", instruction[0:8]) is None: instruction=ASM(instruction) 
        if type(instruction) is int: instruction=Value2DWord(instruction)
        if lastInstruction=='':
            lastInstruction = instruction
        else:
            ResultCode += CheatCode(8,opAddr-4,instruction+lastInstruction)
            lastInstruction = ''
        opAddr+=4
    if (lastInstruction != ''): ResultCode += CheatCode(4,opAddr-4,lastInstruction)
    return ResultCode
def RestoreCode(length,opAddr):
    if isGDB(): return ''
    if length>=8: return CheatCode(length,opAddr,[ 0 if (opAddr+i>=GetCodeK() and opAddr+i<codeEnd) else (ida_bytes.get_wide_dword(opAddr+i)) for i in range(0,length,4) ])
    return CheatCode(length,opAddr,0 if (opAddr>=GetCodeK() and opAddr<codeEnd) else (GetBytes(length,opAddr) if length<=4 else GetQword(opAddr)))
def PointerCodeHeader(offsets,register=None): # offsets use tuples/list with at least 2 element
    if register == None: register = TM2
    if type(offsets) not in (tuple, list): offsets=[offsets]
    code = '580{}0000 {:08X}\n'.format(register,offsets[0])
    if len(offsets)>1: code += PointerCodeAddOffset(offsets[1:],register)
    return code
def PointerCodeAddOffset(offsets,register=None,length=8):
    if register == None: register = TM2
    if type(offsets) not in (tuple, list): offsets=[offsets]
    code=''
    for offset in offsets: 
        code += '5{}0{}1000 {:08X}\n'.format(length,register,offset)
    return code
def PointerCodeAddRegister(offset,register=None):
    if register == None: register = TM2
    return '780{}0000 {:08X}\n'.format(register,offset) if offset>=0 else '780{}1000 {:08X}\n'.format(register,-offset)
def PointerCodeSetValue(value,register='D',length=8):
    return '4{}0{}0000 {}\n'.format(length,register,Value2QWord(value))
def PointerCodeWrite(length, value, value2=None, register=None, use_D=True, increase=False):
    if register == None: register = TM2
    if value2!=None and length==8:  
        code = '6{}0{}{}{}0 {} {}\n'.format(length, register,'1' if increase else '0','1D' if use_D else '00',Value2DWord(value2), Value2DWord(value))
    else:
        code = '6{}0{}{}{}0 {}\n'.format(length, register,'1' if increase else '0', '1D' if use_D else '00', Value2QWord(value))
    return code
def PointerCodeBody(offset, length, value, value2=None, register=None):
    if register == None: register = TM2
    return PointerCodeSetValue(offset) + PointerCodeWrite(length, value, value2, register)
def PointerCodeArithmetic(operater,r0,r1,r2=None,length=8): # Code Type 0x9
    operations = {'+':'0', '-':'0', '*':'2', '<<':'3', '>>':'4', 'and':'5', 'or':'6', 'not':'7', 'xor':'8', 'mov':'9'}
    if r2==None or type(r2) is str: # 9TCRS0s0
        if r2==None: r2='0'
        result = '9{}{}{}{}0{}0\n'.format(length,operations[operater.lower()],r0,r1,r2)
    else: # 9TCRS100 VVVVVVVV 
        result = '9{}{}{}{}100 {}\n'.format(length,operations[operater.lower()],r0,r1, Value2DWord(r2) if length<8 else Value2QWord(r2))
    return result
def PointerCodeStoreRegisterValueToRegisterAddress(valueRegister='D', addrRegister=None, offset=0): # Code Type 0xA  A4SR1000
    if addrRegister == None: addrRegister = TM2
    return 'A4{}{}1000\n'.format(valueRegister, addrRegister) if offset==0 else 'A4{}{}0200 {}\n'.format(valueRegister, addrRegister, Value2DWord(offset))
def PointerCodeStoreRegisterValueToMemoryAddress(addr, length=8, register='F'): # Code Type 0xA
    return 'A{}{}00400 {:08X}\n'.format(length, register, addr)
def PointerCodeCopyRegister(dest, source): 
    return PointerCodeArithmetic('mov', dest, source)
def PointerCodeCondition(register,condition,value,length=4):
    Conditions={'>':'1', '>=':'2', '<':'3', '<=':'4', '==':'5', '!=':'6'}
    return 'C0{}{}{}400 {}\n'.format(length,Conditions[condition],register,Value2DWord(value) if length<8 else Value2QWord(value))
def PointerCodeEndBlock():
    return '20000000\n'
def PointerCode(offsets, length, value, extras=None):
    code = PointerCodeHeader(offsets[0:-1])
    code += PointerCodeBody(offsets[-1], length, value)
    if extra!=None:
        for extra in extras:
            code += PointerCodeBody(extra[0], length, extra[1])
    return code
def ButtonCode(key,code=None,elseCode=None): # note: the ElseCode is not supported by Yuzu currently 
    keymap={'a':0x1,'b':0x2,'x':0x4,'y':0x8,'l3':0x10,'r3':0x20,'l':0x40,'r':0x80,'zl':0x100,'zr':0x200,'plus':0x400,'minus':0x800,'left':0x1000,'up':0x2000,'right':0x4000,'down':0x8000,'l3left':0x10000,'l3up':0x20000,'l3right':0x40000,'l3down':0x80000,'r3left':0x100000,'r3up':0x200000,'r3right':0x400000,'r3down':0x800000,'sl':0x1000000,'sr':0x2000000}
    if isinstance(key, str) and key.lower() in keymap: key=keymap[key.lower()]
    key=key & 0xFFFFFFF
    return '8{:07X}\n{}\n{}20000000\n'.format(key,code.strip('\n '),'' if elseCode==None else '21000000\n%s\n'%(elseCode.strip('\n '))) if code != None else '8%07X'%key
def MixButtons(keys):
    result=0
    for key in keys:
        result=result|int(ButtonCode(key),16)
    return result
def ConditionCode(length,opAddr,value,commands,otherwise=None):
    if type(value) is str and re.match(r"^[0-9a-fA-F]{8}$", value[0:8]) is None: value=ASM(value) 
    result = '1%d050000 %s %s\n%s'%(length,Addr2DWord(opAddr),Value2DWord(value) if length<=4 else Value2QWord(value),commands)
    if otherwise != None: result += '21000000\n%s'%(otherwise)
    result += '20000000\n'
    return result
def ToggleCode(button,length,opAddr,code1,code2=None):
    if code2==None: code2=RestoreCode(length,opAddr)
    return ButtonCode(button,ConditionCode(length,opAddr,code2,CheatCode(length,opAddr,code1),CheatCode(length,opAddr,code2)))
def ASM(asm_code):
    ks = Ks(KS_ARCH_ARM64, KS_MODE_LITTLE_ENDIAN)
    try:
        bytecode, cnt = ks.asm(asm_code, as_bytes=True)
    except:
        idaapi.warning("Error in code: %s"%asm_code)
        bytecode=b'FFFFFFFF'
    return ''.join(map('{:02X}'.format, reversed(bytecode)))

def OperandAddr(addr):  # return something like "B.NE 0x12345678" become "B 0x12345678" 
    return hex(idc.get_operand_value(addr,0 if idc.print_insn_mnem(addr) in ('B','BL') else (2 if idc.print_insn_mnem(addr) in ('TBZ','TBNZ') else 1))-addr)
def Hack(pattern,codes,showRestoreCode=True,useButton=None,elseCode=None,returnCode=False):
    if isGDB(): return
    global cheatCodes, restoreCodes, masterCodes
    output=''
    cheatAddr=AOB(pattern) if type(pattern) is str else pattern
    if notFound(cheatAddr): 
        idaapi.warning(cheatName+': AOB broken!\n%s'%(pattern if type(pattern) is str else hex(pattern)))
    else:
        if type(codes) is str and re.match(r"^[0-9a-fA-F]{8} $", codes[0:9]) is not None: codes=list(reversed(codes.split(' ')))
        if type(codes) is str or type(codes) is int: codes=[codes]
        length = len(codes)*4
        if showRestoreCode=='masterCodes': 
            masterCodes += RestoreCode(length,cheatAddr)
        elif showRestoreCode and useButton==None: 
            restoreCodes += RestoreCode(length,cheatAddr)
        output += CheatCode(length, cheatAddr, codes)
        if useButton != None: 
            output=(RestoreCode(length,cheatAddr) if showRestoreCode else '') + ButtonCode(useButton,output,elseCode)
        if not returnCode: cheatCodes += output
    return output
def HackAll(pattern,codes,offset=0,showRestoreCode=True,useButton=None,elseCode=None):
    if isGDB(): return
    global cheatCodes
    cheatAddrs=AllOccur(pattern,offset)
    if len(cheatAddrs)<1: 
        idaapi.warning(cheatName+': AOB broken!')
    else:
        if useButton != None: cheatCodes += ButtonCode(useButton) # Note: EMU cheat-vm does not support button activator on ASM codes
        for cheatAddr in cheatAddrs: Hack(cheatAddr,codes,showRestoreCode)
        if useButton != None and elseCode!=None: cheatCodes += '21000000\n%s\n'%(elseCode.strip('\n '))
        if useButton != None: cheatCodes += '20000000\n'
def CodeFunc(codes,retAddr=None):
    global codeK
    if isGDB(): return
    ResultCode=lastInstruction=''
    end=GetCodeK()
    for instruction in reversed(codes):
        codeK-=4
        if type(instruction) is int: instruction='%08X'%instruction
        instruction=instruction.replace('{here}',hex(codeK)).replace('{end}',hex(end-codeK)).replace('{back}',hex(retAddr-codeK)).replace('{start}',hex(end-len(codes)*4-codeK))
        if re.match(r"^[0-9a-fA-F]{8}$", instruction[0:8]) is None: instruction=ASM(instruction) 
        if lastInstruction=='':
            lastInstruction = instruction
        else:
            ResultCode += CheatCode(8,codeK,(lastInstruction)+(instruction))
            lastInstruction = ''
    if (lastInstruction != ''): ResultCode += CheatCode(4,codeK,(lastInstruction))
    return ResultCode
def CodeCave(cheatAddr,codes, showRestoreCode=True, use_BL=True,  returnCode=False):
    if isGDB(): return
    global cheatCodes, masterCodes, restoreCodes
    if type(cheatAddr) is str: cheatAddr=AOB(cheatAddr)
    if notFound(cheatAddr): 
        idaapi.warning(cheatName+': AOB broken!')
    else:
        output = CodeFunc(codes,cheatAddr+4)
        if showRestoreCode=="masterCodes": 
            masterCodes += RestoreCode(4,cheatAddr)
        elif showRestoreCode: 
            restoreCodes += RestoreCode(4,cheatAddr)
        output += Hack(cheatAddr, ('BL ' if use_BL else 'B ')+hex(GetCodeK()-cheatAddr), False, None, returnCode=True) 
        if not returnCode: cheatCodes += output
        return output 
def GetCodeK():
    if isGDB(): return BADADDR
    return codeK
def SetCodeK(addr):
    if isGDB(): return
    global codeK
    codeK=addr
def RegCodeK(size=4):
    if isGDB(): return BADADDR
    global codeK
    codeK-=size
    return codeK
def RegData(assignValue,size=4):
    if isGDB(): return
    return CheatCode(size,RegCodeK(size),assignValue)
def DefineWriteableAddress(size=4):
    if isGDB(): return BADADDR
    global dataAddr
    dataAddr-=size
    return dataAddr
def Either(aob1,aob2):
    if isGDB(): return
    if type(aob1) is str: aob1=AOB(aob1)
    if type(aob2) is str: aob2=AOB(aob2)
    return aob1 if isFound(aob1) else aob2
def GetADRP(addr):
    if notFound(addr): return BADADDR
    register = idc.print_operand(addr,1)[1:4].replace(',','')
    baseAddr = SearchPrevASM(addr,'ADRP',register)
    return idc.get_operand_value(baseAddr,1)+idc.get_operand_value(addr,1)
def WriteFile(filepath,content):
    folder = os.path.dirname(filepath)
    if not os.path.exists(folder): os.makedirs(folder)
    with open(filepath, "w", encoding='utf-8') as out:
        out.write(content)

def GetBID(length=8):
    gnu=AOB("00 00 00 47 4E 55 00",dataStart,dataEnd)
    return ''.join('%02X'%ida_bytes.get_wide_byte(gnu+7+i) for i in range(length)) if isFound(gnu) else None
def SetBID(bid):
    global BID
    BID = bid
def GetVersion():
    global VER
    if VER == None:
        try:
            VER = os.path.basename(idc.get_idb_path()).split(')')[1].split('(')[0].strip()
            if VER[0]!='v': VER='v'+VER
        except IndexError:
            VER = None
    return VER
def GetRegion():
    global RGN
    if RGN == None:
        try:
            RGN = os.path.basename(idc.get_idb_path()).split(')')[0].split('(')[1].strip()
        except IndexError:
            RGN = None
    return RGN

def AddMasterCode(codes):
    if isGDB(): return
    global masterCodes
    masterCodes+=codes
def AddCheatCode(codes):
    if isGDB(): return
    global cheatCodes
    cheatCodes+=codes
def AddRestoreCode(codes):
    if isGDB(): return
    global restoreCodes
    restoreCodes+=codes
def AddCheat(nameEN,nameZH=None,newOption=0,isSuggest=False): # newOption=0(不是)/1(新)/2(接上)
    if isGDB(): return
    global cheatCnt, idx, cheatCodes, cheatName
    cheatName=nameEN if english or nameZH==None else nameZH
    if newOption<2: 
        cheatCnt+=1
        idx=ord('a')
    else:
        idx+=1
    title = '#%02d. %s'%(cheatCnt,cheatName) if newOption==0 else '#%02d%s %s'%(cheatCnt,chr(idx),cheatName)
    if isSuggest: title+=' ★'
    Show(title)
    cheatCodes += '\n[%s]\n'%title

def HackComplete():
    if isGDB(): return
    header = ("[%s %s TID=%s BID=%s]\n"%(gameName,VER,TID,BID))
    footer = ('[This set of cheats is created by Eiffel2018, enjoy!]' if english else '[此套金手指由 Eiffel2018 制作, 免費提供, 歡迎轉載, 但請註明來源出處]')
    if isEMU: 
        cheats=cheatCodes.replace('\r','').split('\n\n')
        if masterCodes!='':
            cheatfilename="# Master Code (include share functions)"
            cheat = '{%s}\n%s'%(cheatfilename,masterCodes.strip('\n '))
            cheats= [cheat]+cheats
        for i in range(len(cheats)):
            cheat=cheats[i]=cheats[i].strip('\n ')
            if cheat=='': continue
            cheatfilename=(cheat.split('\n'))[0].strip('{}[] ')
            path='%s\%s for Yuzu\\%s\\cheats\\%s.txt'%(os.path.dirname(idc.get_idb_path()),TID,cheatfilename,BID)
            content = '%s\n'%cheat
            if codeK<ida_segment.get_segm_by_name('.bss').end_ea: WriteFile(path,content) # skip Yuzu if using sdk code cave
        path='%s\%s for Ryujinx\\%s %s\\cheats\\%s.txt'%(os.path.dirname(idc.get_idb_path()),TID,gameName,VER,BID)
        content = '%s\n'%('\n\n'.join(cheats))
        WriteFile(path,content)
    else:
        if masterCodes != '': 
            header += (('\n{%s}\n'%('Master Code (includes share functions)' if english else '關鍵碼 (含共用函式及還原碼)'))+masterCodes)
        restoreCode = '' if restoreCodes=='' else '\n[%s]\n%s'%('Restore Code (Use after unchecking any cheats below)' if english else '還原碼 (當取消以下金手指時使用)', restoreCodes)
            
        path='%s\%s\\cheats\\%s.txt'%(os.path.dirname(idc.get_idb_path()),('' if english else gameName+' 金手指\\')+TID,BID)
        content = '%s%s%s\n%s\n'%(header,restoreCode,cheatCodes,footer)
        WriteFile(path,content)
    cls()
    print('ApplyPatch(\'\'\'\n'+header+cheatCodes+'\'\'\')')


def Init(enName,zhName=None,EMU=None):
    if isGDB(): return
    cls()
    if zhName == None: zhName = enName
    global isEMU, english, TID, BID, VER, RGN, gameName, cheatCnt, cheatCodes, masterCodes, restoreCodes

    TID = os.path.basename(idc.get_idb_path()).replace('800 ','000 ').split(' ')[0].strip()
    if re.match(r"^[0-9a-fA-F]{16}$", TID) is None: TID=ida_kernwin.ask_str('', 0, "Please enter TID")

    BID = GetBID()
    if BID==None: BID=ida_kernwin.ask_str('', 11, "Please enter BID")

    VER = GetVersion()
    if VER==None: VER = ida_kernwin.ask_str('v1.0.0', 12, "Please enter VER")
    
    RGN = GetRegion()
    if RGN==None: RGN = ida_kernwin.ask_str('US', 13, "Please enter Region")

    isEMU = ida_kernwin.ask_yn(False, 'HIDECANCEL\nUse RyujinX / Yuzu?') if EMU == None else EMU
    
    english = True if isEMU else ida_kernwin.ask_yn(True, 'HIDECANCEL\nUse english?')

    gameName= (enName if english else zhName) + ' (%s)'%RGN

    cheatCnt=0
    cheatCodes = masterCodes = restoreCodes = ''
    SetCodeK(GetCodeEnd())
    
def FpsCode(methods,SDK_FPS_Addr=None):
    if type(methods) not in (tuple, list): methods=[methods]
    cheatAddr1 = cheatAddr2 = cheatAddr3 = cheatAddr4 = cheatAddr5 = cheatAddr6 = cheatAddr7 = BADADDR
    if 1 in methods:
        cheatAddr1=AOB('? ? ? 97 F4 00 00 34 68 3A 42 B9')
    if 2 in methods and SDK_FPS_Addr != None:
        nnmusl_init_dso=AOB('? ? ? 94 80 ? ? B9 88 ? ? B9') #i.e. ida_segment.get_segm_by_name('.got.plt').start_ea + 0x18
        cheatAddr2=GetADRP(idc.get_operand_value(nnmusl_init_dso,0)+4) if isFound(nnmusl_init_dso) else ida_segment.get_segm_by_name('.got.plt').start_ea + 0x18
        # SDK_FPS_Addr = 0x7a66c # find in sdk: p( AOB("AB 26 4F B9") - get_name_ea(0,'__nnmusl_init_dso') )
    if 3 in methods:
        targetAddrs = AllOccur('88 01 00 34 ? ? ? 94 ? ? ? 94 ? ? ? ? 08 ? ? F9 08 01 40 B9 1F 01 00 6B E8 07 9F 1A 60 7A 68 BC ? ? ? ? ? ? ? ? C0 03 5F D6 E8 03 1F AA 60 7A 68 BC ? ? ? ? ? ? ? ? C0 03 5F D6')
        cheatAddr3= GetADRP(SearchPrevASM(targetAddrs[1], 'LDR', 'X19', limit=0x40)) if len(targetAddrs)==2 else BADADDR
    if 4 in methods:
        temp=AOB('08 ? ? F9 01 01 40 F9 ? ? ? ? 08 ? ? F9 08 01 40 F9 A0 23 03 D1 00 01 3F D6 ? ? ? ? ? 02 40 B9 A0 23 03 D1 08 ? ? F9 08 01 40 F9 00 01 3F D6')  # unity
        # temp=AOB('08 ? ? F9 01 01 40 F9 ? ? ? ? 08 ? ? F9 08 01 40 F9 A0 23 03 D1 00 01 3F D6 ? ? ? ? E1 02 40 B9')
        if isFound(temp):
            cheatAddr4=[GetQword(GetADRP(temp))]
        else:
            temp=AOB('08 ? ? F9 01 01 40 F9 ? ? ? ? 08 ? ? F9 08 01 40 F9 A0 ? ? D1 00 01 3F D6 ? ? ? ? ? 02 40 B9  08 ? ? F9 08 01 40 F9 A0 ? ? D1 00 01 3F D6 ? ? ? ? 81 02 40 B9 08 ? ? F9 08 01 40 F9 A0 ? ? D1 00 01 3F D6')  # old version unity
            # temp=AOB('08 ? ? F9 01 01 40 F9 ? ? ? ? 08 ? ? F9 08 01 40 F9 A0 23 03 D1 00 01 3F D6 ? ? ? ? E1 02 40 B9')
            # if isFound(temp):
                # cheatAddr4=[GetQword(GetADRP(temp))]
            # else:
                # temp=AOB('08 ? ? F9 01 01 40 F9 ? ? ? ? 08 ? ? F9 08 01 40 F9 00 01 3F D6 ? ? ? ? ? 02 40 F9 08 ? ? F9 08 01 40 39')
                # if isFound(temp):
                    # cheatAddr4=[GetQword(GetADRP(temp))]
                # else:
                    # temp=AOB('? ? ? ? ? ? ? 91 E0 03 16 AA 00 01 3F D6 ? ? ? ? 08 ? ? F9')
                    # if isFound(temp):
                        # cheatAddr4=[idc.get_operand_value(temp,1)+0x18]
                    # else:
                        # temp=AOB('28 ? ? F9 B5 06 00 11')
                        # if isFound(temp):
                            # cheatAddr4=[GetADRP(temp),0xF0]
                        # else:
                            # temp=AOB('01 03 40 F9 00 ? ? F9 ? ? ? 94')
                            # if isFound(temp):
                                # cheatAddr4=[GetQword(GetADRP(temp+4))]
    if 5 in methods:
        temp=AOB('1A ? ? F9 28 03 40 39')
        if isFound(temp):
            cheatAddr5=GetADRP(temp)
    if 6 in methods: # search sysFps::m_flipSync
        cheatAddr6=AOB('F3 03 00 2A ? ? ? 97 ? ? ? ? 08 ? ? F9')
    if 7 in methods and SDK_FPS_Addr != None:
        cheatAddr7=SDK_FPS_Addr

    AddCheat('60 FPS',None,1,isSuggest=True)
    if isFound(cheatAddr1):
        Hack(cheatAddr1,'MOV W0, #1', False)
    if isFound(cheatAddr2):
        AddCheatCode(PointerCodeHeader((cheatAddr2))) 
        AddCheatCode(PointerCodeAddRegister(SDK_FPS_Addr))
        AddCheatCode(PointerCodeWrite(4,ASM('MOV W11, #1'),use_D=False))
    if isFound(cheatAddr3): 
        AddCheatCode(PointerCodeHeader((cheatAddr3)))
        AddCheatCode(PointerCodeWrite(8,Float2DWord(60),Float2DWord(60),use_D=False))
    if isFound(cheatAddr4): 
        AddCheatCode(PointerCodeHeader(cheatAddr4))
        AddCheatCode(PointerCodeAddRegister(0xF14))
        AddCheatCode(PointerCodeWrite(4,1,use_D=False))
    if isFound(cheatAddr5): 
        AddCheatCode(PointerCodeHeader((cheatAddr5)))
        AddCheatCode(PointerCodeWrite(8, 1, 1, use_D=False))
    if isFound(cheatAddr6): 
        Hack('62 6A 68 B8 08 26 86 52', 'MOV W2, #1', False)
        Hack(cheatAddr6, 'MOV W0, #1', False)
        Hack(GetQword(GetADRP(cheatAddr6+12)), 1, False)
    if isFound(cheatAddr7): 
        Hack(SDK_FPS_Addr,'MOV W11, #1', False)
        
    AddCheat('30 FPS',None,2)
    if isFound(cheatAddr1):
        Hack(cheatAddr1,'MOV W0, #2', False)
    if isFound(cheatAddr2):
        AddCheatCode(PointerCodeHeader((cheatAddr2))) 
        AddCheatCode(PointerCodeAddRegister(SDK_FPS_Addr))
        AddCheatCode(PointerCodeWrite(4,ASM('MOV W11, #2'),use_D=False))
    if isFound(cheatAddr3): 
        AddCheatCode(PointerCodeHeader((cheatAddr3)))
        AddCheatCode(PointerCodeWrite(8,Float2DWord(30),Float2DWord(30),use_D=False))
        # FPS method 3 if fail
        # search 60 D2 4B BD  check something like LDR S0, [X21,X8,LSL#2] or LDR S8, [X21,X8,LSL#2]
    if isFound(cheatAddr4): 
        AddCheatCode(PointerCodeHeader(cheatAddr4))
        AddCheatCode(PointerCodeAddRegister(0xF14))
        AddCheatCode(PointerCodeWrite(4,2,use_D=False))
    if isFound(cheatAddr5): 
        AddCheatCode(PointerCodeHeader((cheatAddr5)))
        AddCheatCode(PointerCodeWrite(8, 2, 2, use_D=False))
    if isFound(cheatAddr6): 
        Hack('62 6A 68 B8 08 26 86 52', 'MOV W2, #2', False)
        Hack(cheatAddr6, 'MOV W0, #2', False)
        Hack(GetQword(GetADRP(cheatAddr6+12)), 2, False)
    if isFound(cheatAddr7): 
        Hack(cheatAddr7,'MOV W11, #2', False)

