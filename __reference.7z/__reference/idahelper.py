from ida_idaapi import BADADDR
import idc, ida_kernwin, ida_bytes, ida_search, idautils, ida_funcs, ida_segment, ida_auto, os, sys, ida_nalt, ida_lines, idaapi #,ida_struct, math, pathlib


def ClearCache(lib='idahelper'):
    loaded_package_modules = [key for key, value in sys.modules.items() if lib in str(value)]
    for key in loaded_package_modules: del sys.modules[key]

def isGDB():
    return os.path.dirname(ida_nalt.get_input_file_path()) == ''

if isGDB() and ida_kernwin.ask_yn(False, 'HIDECANCEL\nMark Regions?'):
    ClearCache('markRegions')
    from markRegions64 import markRegions


base=main= ida_segment.get_segm_by_name('main').start_ea if isGDB() else ida_segment.get_segm_by_name('.text').start_ea
codeStart = base+0x30
codeEnd = ida_segment.get_segm_by_name('main').end_ea if isGDB() else ida_segment.get_segm_by_name('.rodata').start_ea
dataStart = ida_segment.get_segm_by_name('main_data').start_ea if isGDB() else ida_segment.get_segm_by_name('.rodata').start_ea
dataEnd = ida_segment.get_segm_by_name('main_data').end_ea if isGDB() else ida_segment.get_segm_by_name('.bss').start_ea
mainEnd = ida_segment.get_segm_by_name('main_data').end_ea if isGDB() else ida_segment.get_segm_by_name('.bss').end_ea
def GetBase(): return base
def GetCodeStart(): return codeStart
def GetCodeEnd(): return codeEnd
def GetDataStart(): return dataStart
def GetDataEnd(): return dataEnd
def GetMainEnd(): return dataEnd

_UTF16start = _AsciiSTRstart = dataStart
_UTF16end = _AsciiSTRend = dataEnd


s=idc.get_screen_ea
j=ida_kernwin.jumpto
def g(name):
    ida_kernwin.jumpto(idc.get_name_ea(codeStart,name))
def p(x):
    print(hex(x) if isinstance(x, int) and x>1 else x)
def a(): # print current address as [main+??????] used for GBD environment
    if not isGDB(): return
    heap=ida_segment.get_segm_by_name('heap').start_ea
    if s()>heap and heap>base or s()<base:
        print('heap+%X'%(s()-heap))
    else:
        print('main+%X'%(s()-base))
def r():
    MakeFunc(s())
def cls():
    ida_kernwin.activate_widget(ida_kernwin.find_widget("Output window"), True);
    ida_kernwin.process_ui_action("msglist:Clear");
def r(ea=None): #Fix Functions Regions
    RemoveAllFuncTail()
    if ea==None: ea=codeStart
    while ea<codeEnd:
        if not isFunc(ea): AddFunc(ea);j(ea)
        ea=find_func_end(ea)
        if notFound(ea): break
        while GetDword(ea) in (0,0xE7FFDEFE): ea+=4
def halt(msg):
    raise ImportError(msg)
def Debug(msg):
    if isDebug: print(msg)
def SetDebug(bool):
    global isDebug
    isDebug=bool
def Show(msg):
    if not isDebug: print(msg)
    ida_kernwin.replace_wait_box(msg)
    # time.sleep(0.00000001)
def isCode(targetAddr):
    targetAddr=targetAddr//4 * 4
    if not inCodeRange(targetAddr): return False
    if not ida_bytes.is_code(ida_bytes.get_full_flags(targetAddr)): ida_auto.auto_make_code(targetAddr)
    # return ida_bytes.is_code(ida_bytes.get_full_flags(targetAddr))
    return ida_bytes.is_code(ida_bytes.get_full_flags(targetAddr)) or ida_bytes.is_code(ida_bytes.get_full_flags(targetAddr-4))
def inCodeRange(targetAddr):
    return codeStart<=targetAddr<codeEnd
def inDataRange(targetAddr):
    return dataStart<=targetAddr<dataEnd
def inWriteableMemory(targetAddr):
    if isGDB(): return inDataRange(targetAddr)
    # return ida_segment.get_segm_by_name('.bss').start_ea <= targetAddr < ida_segment.get_segm_by_name('.bss').end_ea 
    return ida_segment.get_segm_by_name('.bss').start_ea <= targetAddr < 0x80000000
def inHeapRange(targetAddr):
    if not isGDB(): return BADADDR
    return ida_segment.get_segm_by_name('heap').start_ea <= targetAddr < ida_segment.get_segm_by_name('heap').end_ea
def inAliasRange(targetAddr):
    if not isGDB(): return BADADDR
    return ida_segment.get_segm_by_name('alias').start_ea <= targetAddr < ida_segment.get_segm_by_name('alias').end_ea
def inStackRange(targetAddr):
    if not isGDB(): return BADADDR
    return ida_segment.get_segm_by_name('stack').start_ea <= targetAddr < ida_segment.get_segm_by_name('stack').end_ea


def SetUTFRange(a,b):
    global _UTF16start,_UTF16end
    (_UTF16start,_UTF16end) = (a,b)
def SetAsciiRange(a,b):
    global _AsciiSTRstart,_AsciiSTRend
    (_AsciiSTRstart,_AsciiSTRend) = (a,b)

def SearchUTF16(name):
    pattern='00 00 '+' '.join('{:02X}'.format(x) for x in name.encode('utf-16le'))+' 00 00'
    # for i in ((_UTF16start, _UTF16end, pattern, 0, idc.SEARCH_DOWN)): p(i)
    result=ida_search.find_binary(_UTF16start, _UTF16end, pattern, 0, idc.SEARCH_DOWN)
    return result+2 if isFound(result) else BADADDR
def SearchAscii(name):
    pattern='00 '+' '.join('{:02X}'.format(x) for x in name.encode('utf-8'))+' 00'
    result=ida_search.find_binary(_AsciiSTRstart, _AsciiSTRend, pattern, 0, idc.SEARCH_DOWN)
    return result+1 if isFound(result) else BADADDR
def SearchDataRef(targetAddr):
    dataSeg=ida_segment.get_segm_by_name('.data')
    return ida_search.find_binary(dataSeg.start_ea, dataSeg.end_ea, '%X'%targetAddr, 0, idc.SEARCH_DOWN)

def inUTF16Range(targetAddr):
    return _UTF16start<=targetAddr<_UTF16end
def inASCIIRange(targetAddr):
    return _AsciiSTRstart<=targetAddr<_AsciiSTRend
def isPointer(targetAddr):
    if not inDataRange(targetAddr): return False
    if ida_segment.get_segm_by_name('.bss').start_ea <= targetAddr < ida_segment.get_segm_by_name('.bss').end_ea: return True
    return codeStart<GetQword(targetAddr)<dataEnd
def isFound(targetAddr):
    if targetAddr==BADADDR: return False
    if type(targetAddr) in (tuple, list): return True
    return codeStart<=targetAddr<dataEnd or ((inHeapRange(targetAddr)or inAliasRange(targetAddr)) if isGDB() else inWriteableMemory(targetAddr))
def notFound(targetAddr):
    return not isFound(targetAddr)
def GetQword(targetAddr):
    return ida_bytes.get_qword(targetAddr) if isFound(targetAddr) and targetAddr!=None else BADADDR
def GetDword(targetAddr):
    return ida_bytes.get_wide_dword(targetAddr) if isFound(targetAddr) and targetAddr!=None else BADADDR
def GetADRP(addr):
    if notFound(addr): return BADADDR
    register = idc.print_operand(addr,1)[1:4].replace(',','')
    baseAddr = SearchPrevASM(addr,'ADRP',register)
    return idc.get_operand_value(baseAddr,1)+idc.get_operand_value(addr,1)
def isString(targetAddr):
    return ida_bytes.is_strlit(ida_bytes.get_full_flags(targetAddr))
def isFunc(addr):
    return ida_bytes.is_func(ida_bytes.get_full_flags(addr)) and idc.get_func_attr(addr,idc.FUNCATTR_START)==addr
def inFunc(addr):
    return ida_funcs.get_fchunk(addr)!=None
def isFuncTail(addr):
    return ida_funcs.is_func_tail(ida_funcs.get_fchunk(addr))
def iter_all_funcs():
    for func_ea in idautils.Functions():
        yield ida_funcs.get_func(func_ea)
def RemoveAllFuncTail():
    for func_t in iter_all_funcs():
        if func_t.tailqty > 0:
            RemoveFuncTail(func_t.start_ea)
def RemoveFuncTail(addr):
    ida_funcs.remove_func_tail(ida_funcs.get_func(addr),ida_funcs.get_fchunk(addr).start_ea)
def RemakeFunc(addr):
    if isFuncTail(addr): RemoveFuncTail(addr)
    if isFunc(addr): ida_funcs.del_func(addr)
    AddFunc(addr)
def MakeFunc(addr): # find the prev function end, and add new function there
    if not(codeEnd>addr>codeStart): return
    addr=addr//4*4
    if isFuncTail(addr): RemoveFuncTail(addr)
    if inFunc(addr): return
    prevFunc=ida_funcs.get_prev_func(addr)
    while prevFunc.end_ea>addr and prevFunc.tailqty>0:
        AddFunc(ida_funcs.get_fchunk(prevFunc.end_ea).start_ea)
        prevFunc=ida_funcs.get_prev_func(addr)
    funcStart=idc.get_func_attr(idc.get_prev_fchunk(addr),idc.FUNCATTR_END)
    while GetDword(funcStart) in (0,0xD503201F,0xE7FFDEFE) and funcStart<codeEnd: funcStart+=4
    while not inFunc(addr) and funcStart<=addr<codeEnd:
        if funcStart==addr and not isFuncEnd(addr-4):
            CombineFunc(addr)
            break
        AddFunc(funcStart)
        funcStart=idc.get_func_attr(idc.get_prev_fchunk(addr),idc.FUNCATTR_END)
        while GetDword(funcStart) in (0,0xD503201F,0xE7FFDEFE) and funcStart<codeEnd: funcStart+=4
def AddFunc(funcStart): # force Add function here
    if not inCodeRange(funcStart): return
    if ida_bytes.get_item_size(funcStart)>4: ida_bytes.del_items(funcStart)
    if isFuncTail(funcStart): RemoveFuncTail(funcStart)
    if isFunc(funcStart): return
    Debug('%X: Making Function at %X'%(funcStart,funcStart))
    ida_funcs.del_func(funcStart)
    ida_auto.auto_make_proc(funcStart)
    if not isFunc(funcStart):
        funcEnd=idc.find_func_end(funcStart)
        if notFound(funcEnd) or funcEnd<funcStart:
            funcEnd=funcStart+4
            while not isFuncEnd(funcEnd) and funcEnd<codeEnd: funcEnd+=4
            if idc.print_insn_mnem(funcEnd) in ('RET','B','BR'): funcEnd+=4
        ida_funcs.add_func(funcStart,funcEnd)
        ida_auto.auto_wait_range(funcStart,funcEnd)
def isFuncEnd(funcEnd):
    return idc.print_insn_mnem(funcEnd) in ('RET','B','BR','NOP') or GetDword(funcEnd) in (0,0xE7FFDEFE)
def CombineFunc(ea):
    # ea=GetFuncStart(ea)
    prevFunc=ida_funcs.get_prev_func(ea)
    if prevFunc.end_ea!=ea or isFuncEnd(ea-4): return
    ida_funcs.del_func(ea)
    RemakeFunc(prevFunc.start_ea)
def GetFuncStart(targetAddr):
    if not inCodeRange(targetAddr): halt('Error in GetFuncStart at %X'%targetAddr) 
    if isFunc(targetAddr): CombineFunc(targetAddr)
    if isFuncTail(targetAddr): RemoveFuncTail(targetAddr)
    while not inFunc(targetAddr): MakeFunc(targetAddr)
    return idc.get_func_attr(targetAddr,idc.FUNCATTR_START)
def GetFuncEnd(targetAddr):
    if not inCodeRange(targetAddr): halt('Error in GetFuncEnd at %X'%targetAddr) 
    if isFuncTail(targetAddr): RemoveFuncTail(targetAddr)
    while not inFunc(targetAddr): MakeFunc(targetAddr)
    return idc.get_func_attr(targetAddr,idc.FUNCATTR_END)
def AOB(pattern,searchStart=codeStart,searchEnd=codeEnd):
    return ida_search.find_binary(searchStart, searchEnd, pattern, 0, idc.SEARCH_DOWN|idc.SEARCH_NEXT) if not isGDB() else BADADDR
def AOB2(pattern,offset,pattern2=None): # funcion inside
    opAddr=AOB(pattern) if type(pattern) is str else pattern
    if notFound(opAddr): return BADADDR
    return idc.get_operand_value(opAddr+offset,0) if pattern2 is None else AOB(pattern2,idc.get_operand_value(opAddr+offset,0)) 
def AOB3(pattern,pattern2):
    opAddr=AOB(pattern) if type(pattern) is str else pattern
    if notFound(opAddr): return BADADDR
    return AOB(pattern2,opAddr) if type(pattern2) is str else opAddr+pattern2
def AllOccur(pattern,offset=0):
    result=[]
    cheatAddr=AOB(pattern)
    while isFound(cheatAddr):
        result.append(cheatAddr+offset)
        cheatAddr=AOB(pattern,cheatAddr+4)
    return result
def checkUnique(pattern):
    cheatAddr=AOB(pattern)
    return notFound(AOB(pattern,cheatAddr)) if isFound(cheatAddr) else None
def GetBytesPattern(opAddr):
    return ' '.join('{:02X}'.format(x) for x in ida_bytes.get_bytes(opAddr, 4))
def anaysis(opAddr):
    cmd=idc.print_insn_mnem(opAddr)
    if cmd == 'BL' or cmd == 'B':
        return '? ? ? {:02X}'.format(ida_bytes.get_original_byte(opAddr+3))
    elif cmd == 'ADRP' or cmd == 'ADRL':
        return '? ? ? ?'
    elif cmd == '' and idc.print_insn_mnem(opAddr-4)=='ADRL':
        return "? ? ? {:02X}".format(ida_bytes.get_original_byte(opAddr+3))
    elif 'PAGEOFF' in idc.print_operand(opAddr,1):
        return "{:02X} ? ? {:02X}".format(ida_bytes.get_original_byte(opAddr),ida_bytes.get_original_byte(opAddr+3))
    else:
        return GetBytesPattern(opAddr)
def GetAOB(opAddr=BADADDR):
    if notFound(opAddr): opAddr=s()
    pattern=space=''
    result=False
    funcEnd=GetFuncEnd(opAddr)
    while opAddr<funcEnd and result==False:
        pattern+=space+anaysis(opAddr)
        space=' '
        opAddr+=4
        result=checkUnique(pattern)
    print(pattern)
    if result==None: Warning('Pattern not Unqiue!')
    
def SearchNextASM(addr,command,operand0=None,operand1=None, operand2=None, limit=0):
    if notFound(addr): halt('invalid start searching address '+hex(addr))
    if not inFunc(addr): MakeFunc(addr)
    while GetDword(addr) in (0,0xD503201F,0xE7FFDEFE): addr+=4
    limitAddr=GetFuncEnd(addr) if limit==0 else addr+limit
    addr+=4
    while addr<limitAddr:
        if command in ('LDR','LDRB','STR','STRB'):
            if (idc.print_insn_mnem(addr)==command) and \
               (operand0==None or idc.print_operand(addr,0)==operand0) and \
               (operand1==None or idc.print_operand(addr,1)==operand1 or idc.print_operand(addr,1)[1:len(operand1)+1]==operand1) and \
               (operand2==None or idc.get_operand_value(addr,1)==operand2): break
        elif command in ('LDP','STP'):
            if(idc.print_insn_mnem(addr)==command) and \
               (operand0==None or idc.print_operand(addr,0)==operand0) and \
               (operand1==None or idc.print_operand(addr,1)==operand1) and \
               (operand2==None or (isinstance(operand2, str) and idc.print_operand(addr,2)[1:len(operand2)+1]==operand2) or (isinstance(operand2, int) and idc.get_operand_value(addr,2)==operand2)): break
        else:
            if (idc.print_insn_mnem(addr)==command) and \
               (operand0==None or idc.print_operand(addr,0)==operand0 or (isinstance(operand0, int) and idc.get_operand_value(addr,0)==operand0)) and \
               (operand1==None or idc.print_operand(addr,1)==operand1 or (isinstance(operand1, int) and idc.get_operand_value(addr,1)==operand1)) and \
               (operand2==None or idc.print_operand(addr,2)==operand2 or (isinstance(operand2, int) and idc.get_operand_value(addr,2)==operand2)): break
        addr+=4
    return addr if addr<limitAddr else BADADDR
    
def SearchPrevASM(addr,command,operand0=None,operand1=None,operand2=None,limit=0):
    if notFound(addr): halt('invalid start searching address '+hex(addr))
    # if limit==0 and not inFunc(addr): MakeFunc(addr)
    if limit==0 and not inFunc(addr): limit=0x3000
    addr-=4
    while GetDword(addr) in (0,0xD503201F,0xE7FFDEFE): addr-=4
    # p(addr)
    limitAddr = GetFuncStart(addr) if limit==0 else addr-limit
    while addr>=limitAddr:
        if command in ('LDR','LDRB','STR','STRB'):
            if (idc.print_insn_mnem(addr)==command) and \
               (operand0==None or idc.print_operand(addr,0)==operand0) and \
               (operand1==None or idc.print_operand(addr,1)==operand1 or idc.print_operand(addr,1)[1:len(operand1)+1]==operand1) and \
               (operand2==None or idc.get_operand_value(addr,1)==operand2): break
        elif command in ('LDP','STP'):
            if(idc.print_insn_mnem(addr)==command) and \
               (operand0==None or idc.print_operand(addr,0)==operand0) and \
               (operand1==None or idc.print_operand(addr,1)==operand1) and \
               (operand2==None or (isinstance(operand2, str) and idc.print_operand(addr,2)[1:len(operand2)+1]==operand2) or (isinstance(operand2, int) and idc.get_operand_value(addr,2)==operand2)): break
        else:
            if (idc.print_insn_mnem(addr)==command) and \
               (operand0==None or idc.print_operand(addr,0)==operand0 or (isinstance(operand0, int) and idc.get_operand_value(addr,0)==operand0)) and \
               (operand1==None or idc.print_operand(addr,1)==operand1 or (isinstance(operand1, int) and idc.get_operand_value(addr,1)==operand1)) and \
               (operand2==None or idc.print_operand(addr,2)==operand2 or (isinstance(operand2, int) and idc.get_operand_value(addr,2)==operand2)): break
        addr-=4
    return addr if addr>=limitAddr else BADADDR

def SearchXrefASM(funcAddr,command,operand0=None,operand1=None,listAll=False):
    addr=BADADDR
    results=[]
    for xref in idautils.XrefsTo(funcAddr,0):
        if (idc.print_insn_mnem(xref.frm)==command) and \
           (operand0==None or (idc.print_operand(xref.frm,0)!=operand0[1:] if operand0[0]=='!' else idc.print_operand(xref.frm,0)==operand0) or (isinstance(operand0, int) and idc.get_operand_value(xref.frm,0)==operand0)) and \
           (operand1==None or idc.get_operand_value(xref.frm,1)==operand1): 
            addr=xref.frm; 
            results.append(addr)
            if not listAll: break
    return results if listAll else addr
    
def ApplyComment(targetAddr,comment):
    idc.set_cmt(targetAddr,comment,1)
def AddEmptyLines(targetAddr):
    ida_lines.del_extra_cmt(targetAddr,ida_lines.E_NEXT)
    ida_lines.del_extra_cmt(targetAddr,ida_lines.E_NEXT+1)
    ida_lines.add_extra_line(targetAddr,False,'\n\n')
def ReplacePriorComment(targetAddr,comment):
    ida_lines.delete_extra_cmts(targetAddr,ida_lines.E_PREV)
    ida_lines.add_extra_line(targetAddr,True,comment) 
def AddPriorComment(targetAddr,comment):
    lines=ida_lines.get_extra_cmt(targetAddr, ida_lines.E_PREV)
    if lines != None:
        for l in lines.replace('; ','').split('\n'):
            if comment==l: return
    ida_lines.add_extra_cmt(targetAddr,True,comment)       

def GetParameterHelper(funcAddr,regName,memType=None):
    x=SearchPrevASM(funcAddr,'ADRL',regName,limit=0x60)
    r=SearchPrevASM(funcAddr,'MOV',regName,limit=0x60)
    a=SearchPrevASM(funcAddr,'ADD',regName,limit=0x60)
    l1=SearchPrevASM(funcAddr,'LDR',regName,limit=0x60)
    l2=SearchPrevASM(funcAddr,'LDUR',regName,limit=0x60)
    l = max(l1,l2) if isFound(l1) and isFound(l2) else min(l1,l2)
    if isFound(r) and (notFound(x) or r>x):
        x=SearchPrevASM(r,'ADRL',idc.print_operand(r,1))
        if memType=='Code': 
            while not inCodeRange(idc.get_operand_value(x,1)) and isFound(x): x=SearchPrevASM(x,'ADRL',idc.print_operand(r,1))
        elif memType=='UTF':
            while not inUTF16Range(idc.get_operand_value(x,1)) and isFound(x): x=SearchPrevASM(x,'ADRL',idc.print_operand(r,1))
        elif memType=='ASC':
            while not inASCIIRange(idc.get_operand_value(x,1)) and isFound(x): x=SearchPrevASM(x,'ADRL',idc.print_operand(r,1))
        elif memType=='Pointer':
            while not isPointer(idc.get_operand_value(x,1)) and isFound(x): x=SearchPrevASM(x,'ADRL',idc.print_operand(r,1))
        elif memType=='Writeable':
            while not inWriteableMemory(idc.get_operand_value(x,1)) and isFound(x): x=SearchPrevASM(x,'ADRL',idc.print_operand(r,1))
        if notFound(x): # far function call
            # xref=list(idautils.CodeRefsTo(GetFuncStart(r),1))
            # if len(xref)==1:
                # caller=next(xref)
                # return GetParameterHelper(caller,idc.print_operand(r,1),memType)
            b=SearchPrevASM(r,'B')
            if isFound(b) and b>GetFuncStart(r):
                caller=next(idautils.CodeRefsTo(b+4,1))
            else:
                xref=list(idautils.CodeRefsTo(GetFuncStart(r),1))
                caller=xref[0] if len(xref)==1 else BADADDR
            if isFound(caller) and inCodeRange(caller):
                # print('GetParameterHelper(0x%X,"%s","%s")'%(caller,idc.print_operand(r,1),memType))
                return GetParameterHelper(caller,idc.print_operand(r,1),memType)
                
    elif isFound(l) and notFound(r) and notFound(x) and (notFound(a) or l>a):
        if idc.print_operand(l,1)[1:4] not in ('SP,','X29'):
            return GetADRP(l)
        else:
            r1=SearchPrevASM(l,'STR',None,idc.print_operand(l,1))
            r2=SearchPrevASM(l,'STUR',None,idc.print_operand(l,1))
            r=max(r1,r2) if isFound(r1) and isFound(r2) else min(r1,r2)
            x=SearchPrevASM(r,'ADRL',idc.print_operand(r,0))
            if notFound(x): # far function call
                xref=list(idautils.CodeRefsTo(GetFuncStart(r),1))
                if len(xref)==1 and inCodeRange(xref[0]):
                    return GetParameterHelper(xref[0],idc.print_operand(r,0),memType)
    elif isFound(a) and (notFound(x) or a>x): 
        b=SearchPrevASM(a,'ADRP',idc.get_operand_value(a,1))
        if isFound(b): return idc.get_operand_value(b,1) + idc.get_operand_value(a,2)
    # if notFound(x): halt('%X interrupt at line %d'%(funcAddr,getframeinfo(currentframe()).lineno))
    return idc.get_operand_value(x,1) if isFound(x) else BADADDR
    
def ApplyPatch(code):# use 3 """ to quote the multiline codes
    lines=code.split('\n')
    for line in lines:
        if len(line)<26 or line[0]!='0': continue
        type,addr,value=(int(x.replace(' ',''),16) for x in line.split(' ',2))
        size=(type&0x0F000000)//0x1000000
        PatchBytes(size,base+addr,value)
        ida_bytes.del_items(addr+base)
        idc.create_insn(addr+base)
        
def PatchBytes(length,opAddr,value):
    if type(value) is str: value=int(value.replace(' ',''), 16)
    if (length==1):
        ida_bytes.patch_byte(opAddr,value)
    elif (length==2):
        ida_bytes.patch_word(opAddr,value)
    elif (length==4):
        ida_bytes.patch_dword(opAddr,value)
    elif (length==8):
        ida_bytes.patch_qword(opAddr,value)
    else:
        print('Error in PatchBytes(%X,%X,%X)'%(length,opAddr,value))

def ptr(offsets,length=0): # return the address/value of pointer expression, e.g. [[main+123456]+1234]+32 , type ptr((123456,0x1234,0x32)) or ptr((123456,0x1234,0x32),4)
    if type(offsets) not in (tuple, list): return 'Error with NOEXES expression'
    addr=base
    for offset in offsets[:-1]: 
        addr = GetQword(addr+offset)
    addr += offsets[-1]
    return addr if length==0 else GetBytes(length,addr)

def GetUTFstr(addr):
    if not inUTF16Range(addr): halt(hex(addr));return 'unknown'
    end=ida_search.find_binary(addr, addr+0x100, '0 0 0', 0, idc.SEARCH_DOWN)
    length=end-addr+3
    result=idc.get_strlit_contents(addr,length,ida_nalt.STRTYPE_C_16).decode()
    if not isString(addr) or idaapi.get_item_head(addr+length-1)!=addr or idaapi.get_item_head(addr)!=addr: 
        ida_bytes.del_items(addr,0,length)
        ida_bytes.create_strlit(addr, length, ida_nalt.STRTYPE_C_16)
    idc.set_name(addr,'utf_'+result,0x3981)
    return result
    
def GetASCstr(addr):
    if not inASCIIRange(addr): halt(hex(addr));return 'unknown'
    end=ida_search.find_binary(addr, addr+0x100, '0', 0, idc.SEARCH_DOWN)
    length=end-addr+1
    result=idc.get_strlit_contents(addr,length,ida_nalt.STRTYPE_C).decode()
    if not isString(addr) or idaapi.get_item_head(addr+length-1)!=addr or idaapi.get_item_head(addr)!=addr: 
        ida_bytes.del_items(addr,0,length)
        ida_bytes.create_strlit(addr, length, ida_nalt.STRTYPE_C)
    idc.set_name(addr,'str_'+result,0x3981)
    return result
    
def Patch(targetAddr,newName,ref=BADADDR, force=False):
    if isGDB() and targetAddr<base: targetAddr+=base
    if not isGDB() and inCodeRange(targetAddr): 
        AddFunc(targetAddr)
    if isFound(ref):
        Debug('Patch(0x%X, \'%s\', 0x%X)' % (targetAddr,newName,ref))
    else:
        Debug('Patch(0x%X, \'%s\')' % (targetAddr,newName))
    tempAddr=idc.get_name_ea(codeStart,newName)
    if force and isFound(tempAddr) and tempAddr != targetAddr:
        idc.set_name(tempAddr,'')
        idc.set_name(targetAddr, newName, (0x3901 if targetAddr<=codeEnd else 0x3981))
        idc.set_name(tempAddr, newName, (0x3901 if targetAddr<=codeEnd else 0x3981))
    else:
        idc.set_name(targetAddr, newName, (0x3901 if targetAddr<=codeEnd else 0x3981))
