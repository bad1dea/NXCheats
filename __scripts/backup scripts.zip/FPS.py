import idc,ida_search,ida_segment,ida_kernwin,ida_funcs
gdb = ida_segment.get_segm_by_name('main') != None
Base= ida_segment.get_segm_by_name('main').start_ea if gdb else ida_segment.get_segm_by_name('.text').start_ea
CodeStart = Base+0x30
CodeEnd = ida_segment.get_segm_by_name('main').end_ea if gdb else ida_segment.get_segm_by_name('.rodata').start_ea
DataStart = ida_segment.get_segm_by_name('main_data').start_ea if gdb else ida_segment.get_segm_by_name('.rodata').start_ea
DataEnd = ida_segment.get_segm_by_name('main_data').end_ea if gdb else ida_segment.get_segm_by_name('.init_array').end_ea

def cls():
    ida_kernwin.activate_widget(ida_kernwin.find_widget("Output window"), True);
    ida_kernwin.process_ui_action("msglist:Clear");
def isFound(opAddr):
    return opAddr != BADADDR
def notFound(opAddr):
    return opAddr == BADADDR
def isCode(targetAddr):
    return is_code(get_full_flags(targetAddr))
def makeFunc(addr):
    if not(CodeEnd>addr>CodeStart): return
    addr=addr//4*4
    while idaapi.get_func(addr)==None or not(isCode(addr)):
        funcStart=get_func_attr(get_prev_func(addr),FUNCATTR_END)
        while get_wide_dword(funcStart) in (0,0xD503201F,0xE7FFDEFE): funcStart+=4
        print('Making Function at %X'%(funcStart))
        del_items(funcStart)
        if not(ida_funcs.add_func(funcStart)):
            funcEnd=find_func_end(funcStart)
            if notFound(funcEnd) or funcEnd<funcStart:
                funcEnd=funcStart+4
                while print_insn_mnem(funcEnd) not in ('RET','B','BR') and funcEnd<CodeEnd and not(get_wide_dword(funcEnd) in (0,0xD503201F,0xE7FFDEFE)): funcEnd+=4
                if print_insn_mnem(funcEnd) in ('RET','B','BR'): funcEnd+=4
                ida_funcs.add_func(funcStart,funcEnd)
                auto_wait()
def getFuncStart(targetAddr):
    makeFunc(targetAddr)
    return get_func_attr(targetAddr,FUNCATTR_START)
def getFuncEnd(targetAddr):
    makeFunc(targetAddr)
    return get_func_attr(targetAddr,FUNCATTR_END)
def AOB(pattern,searchStart=CodeStart,searchEnd=CodeEnd):
    return ida_search.find_binary(searchStart, searchEnd, pattern, 0, SEARCH_DOWN|SEARCH_NEXT)
def searchNextASM(addr,command,operand=None):
    funcEnd=getFuncEnd(addr)
    while addr<funcEnd:
        if operand==None:
            if print_insn_mnem(addr)==command: break
        else:
            if print_insn_mnem(addr)==command and operand==print_operand(addr,0): break
        addr+=4
    return addr if addr<funcEnd else BADADDR
def searchPrevASM(addr,command,operand=None):
    funcStart=getFuncStart(addr)
    while addr>=funcStart:
        if operand==None:
            if print_insn_mnem(addr)==command: break
        else:
            if print_insn_mnem(addr)==command and operand==print_operand(addr,0): break
        addr-=4
    return addr if addr>=funcStart else BADADDR
    
def getXrefsTo(func_st, single=False):
    xrefs = []
    for xref in XrefsTo(func_st):
        if single==True:
            return(xref.frm)
        xrefs.append(xref.frm)        
    return xrefs
    
cls()

addr=getXrefsTo(AOB('6E 76 6E 57 69 6E 64 6F 77 53 65 74 43 72 6F 70 00',DataStart,DataEnd),single=True)
#print('0x%016X'%addr)
jumpto(addr)
xaddr0=searchPrevASM(addr, 'ADRP')
xaddr1=searchPrevASM(addr, 'LDR')
X=get_operand_value(xaddr0,1)+get_operand_value(xaddr1,1)
#print('0x%016X'%X)
xrefs=getXrefsTo(X)
for xref in xrefs:
    #print('funcStart: 0x%016X\nxref: 0x%016X'%(getFuncStart(xref),xref))
    if(searchNextASM(xref,'MOV','W1') != BADADDR):
        print('Potential FPS location: 0x%016X'%searchNextASM(xref,'MOV','W1'))
