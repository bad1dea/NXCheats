

# This Script is Programmed by Eiffel2018
# Tested in IDA PRO v7.5+ with Python 3.9.x
# Operate with a clean NSO (or main.elf)

import idc,ida_search,ida_segment,ida_kernwin,ida_funcs
gdb = ida_segment.get_segm_by_name('main') != None
Base= ida_segment.get_segm_by_name('main').start_ea if gdb else ida_segment.get_segm_by_name('.text').start_ea
CodeStart = Base+0x30
CodeEnd = ida_segment.get_segm_by_name('main').end_ea if gdb else ida_segment.get_segm_by_name('.rodata').start_ea
DataStart = ida_segment.get_segm_by_name('main_data').start_ea if gdb else ida_segment.get_segm_by_name('.rodata').start_ea
DataEnd = ida_segment.get_segm_by_name('main_data').end_ea if gdb else ida_segment.get_segm_by_name('.init_array').end_ea

def cls():
    ida_kernwin.activate_widget(ida_kernwin.find_widget("Output window"), True);
    ida_kernwin.process_ui_action("msglist:Clear");
def isFound(opAddr):
    return opAddr != BADADDR
def notFound(opAddr):
    return opAddr == BADADDR
def isCode(targetAddr):
    return is_code(get_full_flags(targetAddr))
def makeFunc(addr):
    if not(CodeEnd>addr>CodeStart): return
    addr=addr//4*4
    while idaapi.get_func(addr)==None or not(isCode(addr)):
        funcStart=get_func_attr(get_prev_func(addr),FUNCATTR_END)
        while get_wide_dword(funcStart) in (0,0xD503201F,0xE7FFDEFE): funcStart+=4
        print('Making Function at %X'%(funcStart))
        del_items(funcStart)
        if not(ida_funcs.add_func(funcStart)):
            funcEnd=find_func_end(funcStart)
            if notFound(funcEnd) or funcEnd<funcStart:
                funcEnd=funcStart+4
                while print_insn_mnem(funcEnd) not in ('RET','B','BR') and funcEnd<CodeEnd and not(get_wide_dword(funcEnd) in (0,0xD503201F,0xE7FFDEFE)): funcEnd+=4
                if print_insn_mnem(funcEnd) in ('RET','B','BR'): funcEnd+=4
                ida_funcs.add_func(funcStart,funcEnd)
                auto_wait()
def getFuncStart(targetAddr):
    makeFunc(targetAddr)
    return get_func_attr(targetAddr,FUNCATTR_START)
def getFuncEnd(targetAddr):
    makeFunc(targetAddr)
    return get_func_attr(targetAddr,FUNCATTR_END)
def AOB(pattern,searchStart=CodeStart,searchEnd=CodeEnd):
    return ida_search.find_binary(searchStart, searchEnd, pattern, 0, SEARCH_DOWN|SEARCH_NEXT)
def searchNextASM(addr,command,operand=None):
    funcEnd=getFuncEnd(addr)
    while addr<funcEnd:
        if operand==None:
            if print_insn_mnem(addr)==command: break
        else:
            if print_insn_mnem(addr)==command and operand==print_operand(addr,0): break
        addr+=4
    return addr if addr<funcEnd else BADADDR
def searchPrevASM(addr,command,operand=None):
    funcStart=getFuncStart(addr)
    while addr>=funcStart:
        if operand==None:
            if print_insn_mnem(addr)==command: break
        else:
            if print_insn_mnem(addr)==command and operand==print_operand(addr,0): break
        addr-=4
    return addr if addr>=funcStart else BADADDR

cls()
nnMain=get_name_ea(0,'nnMain')
addr=AOB('E0 03 00 32 ? ? ? 97 ? ? ? 97 ? ? ? 97',nnMain,getFuncEnd(nnMain))
if notFound(addr): addr=AOB('20 00 80 52 ? ? ? 97 ? ? ? 97 ? ? ? 97',nnMain,getFuncEnd(nnMain))
if notFound(addr): warning('Pattern not found')
funcAddr=get_operand_value(addr+12,0)
X0Addr=searchNextASM(funcAddr,'ADRP','X0')
if notFound(X0Addr): warning('Logic Error')
X0Addr2=searchNextASM(X0Addr,'LDR','X0')
if notFound(X0Addr2): warning('Logic Error')
X0=get_operand_value(X0Addr,1)+get_operand_value(X0Addr2,1)

X1Addr=searchNextASM(funcAddr,'ADRP','X1')
if notFound(X1Addr): warning('Logic Error')
X1Addr2=searchNextASM(X0Addr,'LDR','X1')
if notFound(X1Addr2): warning('Logic Error')
X1=get_operand_value(X1Addr,1)+get_operand_value(X1Addr2,1)

jumpto(X0)
print('CodeRegistration=%X\nMetadataRegistration=%X'%(get_qword(X0),get_qword(X1)))

