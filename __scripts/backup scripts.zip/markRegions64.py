import idc,ida_idd,re,ida_dbg,idaapi,ida_kernwin,ida_dbg,ida_segment

def markRegions():
    print('----- Script created by Eiffel2018 -----')

    info = idc.send_dbg_command('get info')
    infoheader, dummy, infobody = info.partition('\nLayout:\n')
    layout, dummy, modules = infobody.partition('\nModules:\n')
    regions = ida_idd.meminfo_vec_t()
    for region in layout.splitlines():
        name, start, end = re.split('[:|-]',region.replace(' ', ''))
        if (name=='Alias' or name=='Heap' or name=='Stack'): 
            print(name, start, hex(int(end,16)+1))
            info = ida_idd.memory_info_t()
            info.name = name.lower()
            info.start_ea = int(start,16)
            info.end_ea = int(end,16)+1
            info.sclass = 'DATA'
            info.sbase = 0
            info.bitness = 2
            info.perm = 6
            regions.push_back(info)
    lastend=0
    lastbase=0
    lastname=''
    for region in modules.splitlines():
        start, end, name = region.strip().replace(' - ', ' ').split(' ');
        name, dummy, ext = name.partition('.');
        if (ext=='nss'): 
            name='main'
        if (ext=='nrs.elf'): 
            name='nro'
        if (lastend>0):
            info = ida_idd.memory_info_t()
            info.name = lastname + '-data'
            info.start_ea = lastend
            info.end_ea = int(start,16)
            info.sclass = 'DATA'
            # info.sbase = lastbase
            info.sbase = 0
            info.bitness = 2
            info.perm = 6
            regions.push_back(info)
            print(lastname + '-data', hex(lastend), start)
            lastend=0
        if (name=='saltysd_core' or name=='saltysd_core-data'):
            continue
        if (name=='' or name=='-data'):
            continue
        # if (name=='nnSdk'):
            # continue
        print(name, start, hex(int(end,16)+1))
        info = ida_idd.memory_info_t()
        info.name = name
        info.start_ea = int(start,16)
        info.end_ea = int(end,16)+1
        info.sclass = 'CODE'
        info.sbase = 0
        if (name=='main'):
            main=int(start[:-1],16)
            info.sbase = main
        info.bitness = 2
        info.perm = 5
        regions.push_back(info)
        lastend=info.end_ea
        lastbase=info.sbase
        lastname=info.name
        if (ext=='nrs.elf'): 
            mapping = idc.send_dbg_command('get mapping '+hex(int(end,16)+1))
            start, end, dummy, nextName, dummy = mapping.replace(' - ', ' ').split(' ', 4);
            if (nextName=='AliasCode'):
                name='nro-static'
                print(name, start, hex(int(end,16)+1))
                info = ida_idd.memory_info_t()
                info.name = name
                info.start_ea = int(start,16)
                info.end_ea = int(end,16)+1
                info.sclass = 'DATA'
                info.sbase = 0
                info.bitness = 2
                info.perm = 4
                regions.push_back(info)
                lastend=info.end_ea
                lastbase=info.sbase
                lastname=info.name
                mapping = idc.send_dbg_command('get mapping '+hex(int(end,16)+1))
                start, end, dummy, nextName, dummy = mapping.replace(' - ', ' ').split(' ', 4);
            if (nextName=='AliasCodeData'):
                name='nro-data'
                mapping = idc.send_dbg_command('get mapping '+hex(int(end,16)+1))
                start2, end2, dummy, nextName2, dummy = mapping.replace(' - ', ' ').split(' ', 4);
                if (nextName2=='AliasCodeData'):
                    end = end2
                    mapping = idc.send_dbg_command('get mapping '+hex(int(end,16)+1))
                    start2, end2, dummy, nextName2, dummy = mapping.replace(' - ', ' ').split(' ', 4);
                    if (nextName2=='AliasCodeData'):
                        end = end2
                print(name, start, hex(int(end,16)+1))
                info = ida_idd.memory_info_t()
                info.name = name
                info.start_ea = int(start,16)
                info.end_ea = int(end,16)+1
                info.sclass = 'DATA'
                info.sbase = 0
                info.bitness = 2
                info.perm = 6
                regions.push_back(info)
                lastend=info.end_ea
                lastbase=info.sbase
                lastname=info.name
                mapping = idc.send_dbg_command('get mapping '+hex(int(end,16)+1))
                start, end, dummy, nextName, dummy = mapping.replace(' - ', ' ').split(' ', 4);
                lastend=0
    ida_dbg.set_manual_regions(regions)
    ida_dbg.enable_manual_regions(0)
    ida_dbg.refresh_debugger_memory()
    ida_dbg.enable_manual_regions(1)
    ida_dbg.refresh_debugger_memory()
    ida_dbg.edit_manual_regions()
    pc = idaapi.get_reg_val('PC')
    ida_kernwin.jumpto(pc)
    ida_kernwin.refresh_idaview_anyway()
    
markRegions()
base=main= ida_segment.get_segm_by_name('main').start_ea 
codeStart = base+0x30
codeEnd = ida_segment.get_segm_by_name('main').end_ea 
dataStart = ida_segment.get_segm_by_name('main_data').start_ea
dataEnd = ida_segment.get_segm_by_name('main_data').end_ea 