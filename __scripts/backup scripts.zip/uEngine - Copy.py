# This Script is Programmed by Eiffel2018
# Works in IDA PRO v7.5+
# Requirement: Python 3.9.x (with idapyswitch) and Keystone 
#
# This script perform in with NSO that was fully analysed
# (i.e. Before run this script, you need to wait painfully until the IDA shows IDLE at the bottom status bar )
#
# The script will rename the functions with proper name.
# It will also generate another script on the View of Output Window 
# You can copy it and run the generated script in another IDA that connected to GBD Debugger and defined sections
#
# Note: the analysis may wrong, and it may damage your .i64 file.
# So, better making a save before using this script!
#
#

isDebug = True
reverseSDK=False

import idc, ida_bytes, ida_search, ida_struct, idautils, sys, ida_kernwin, ida_funcs, idaapi, ida_segment, math, pathlib, ida_auto
from inspect import currentframe, getframeinfo
from ida_idaapi import BADADDR

if sys.hexversion < 0x03090000:
    raise ImportError("This script is tested on Python 3.9.x only\nCurrently, your python version is " + sys.version)

gdb = ida_segment.get_segm_by_name('main') != None
base=main= ida_segment.get_segm_by_name('main').start_ea if gdb else ida_segment.get_segm_by_name('.text').start_ea
codeStart = base+0x30
codeEnd = ida_segment.get_segm_by_name('main').end_ea if gdb else ida_segment.get_segm_by_name('.rodata').start_ea
dataStart = ida_segment.get_segm_by_name('main_data').start_ea if gdb else ida_segment.get_segm_by_name('.rodata').start_ea
dataEnd = ida_segment.get_segm_by_name('main_data').end_ea if gdb else ida_segment.get_segm_by_name('.init_array').end_ea

FF_OFFSET=0x30500400 #ida_bytes.FF_QWORD|FF_DATA|ida_bytes.off_flag()
FF_4BIT=ida_bytes.FF_DWORD|ida_bytes.FF_DATA|ida_bytes.dec_flag()
FF_8BIT=ida_bytes.FF_QWORD|ida_bytes.FF_DATA|ida_bytes.dec_flag()

j=ida_kernwin.jumpto
s=idc.get_screen_ea
def p(x):
    print(hex(x) if isinstance(x, int) and x>1 else x)
def cls():
    ida_kernwin.activate_widget(ida_kernwin.find_widget("Output window"), True);
    ida_kernwin.process_ui_action("msglist:Clear");
def r():
    addr=get_next_func(get_screen_ea())-4
    while ida_bytes.get_wide_dword(addr) in (0,0xD503201F,0xE7FFDEFE): addr-=4
    MakeFunc(addr)
def g(name):
    jumpto(idc.get_name_ea(codeStart,name))
def halt(msg):
    raise ImportError(msg)
def Debug(msg):
    if isDebug: print(msg)
def show(msg):
    if not isDebug: print(msg)
    ida_kernwin.replace_wait_box(msg)
    # time.sleep(0.00000001)
def isCode(targetAddr):
    # return ida_bytes.is_code(ida_bytes.get_full_flags(targetAddr))
    return codeStart<targetAddr<codeEnd and (ida_bytes.is_code(ida_bytes.get_full_flags(targetAddr)) or ida_bytes.is_code(ida_bytes.get_full_flags(targetAddr-4)))
def isFunc(targetAddr):
    return ida_bytes.is_func(ida_bytes.get_full_flags(targetAddr))
def isPointer(targetAddr):
    # return is_off(ida_bytes.get_full_flags(targetAddr),OPND_ALL)
    addr=idc.get_qword(targetAddr);
    return addr>codeStart and addr<dataEnd
def isFound(targetAddr):
    return targetAddr != BADADDR
def notFound(targetAddr):
    return targetAddr == BADADDR
def isString(targetAddr):
    return is_strlit(ida_bytes.get_full_flags(targetAddr))
def Patch(targetAddr,newName,ref=BADADDR):
    if targetAddr<codeEnd: 
        MakeFunc(targetAddr)
    Debug('Patch(0x%X, \'%s\', 0x%X)' % (targetAddr-base,newName,ref-base))
    idc.set_name(targetAddr, newName, (0x3901 if targetAddr<=codeEnd else 0x3981))
def PatchBytes(length,opAddr,value):
    if isinstance(value, str): value=int(value, 16).replace(' ','')
    if (length==1):
        ida_bytes.Patch_byte(opAddr,value)
    elif (length==2):
        ida_bytes.Patch_word(opAddr,value)
    elif (length==4):
        ida_bytes.Patch_dword(opAddr,value)
    elif (length==8):
        ida_bytes.Patch_qword(opAddr,value)
    else:
        Debug('Error in PatchBytes({},{},{})',length,opAddr,value) 

def applyPatch(code):
    lines=code.split('\n')
    for line in lines:
        type,addr,value=(int(x.replace(' ',''),16) for x in line.split(' ',3))
        size=(type&0x0F000000)//0x1000000
        PatchBytes(size,addr,value)
        ida_bytes.del_items(addr)
        create_insn(addr)

def ApplyStruct(targetAddr,name):
    if targetAddr<base: targetAddr+=base
    sid=ida_struct.get_struc_id(name)
    size=ida_struct.get_struc_size(sid)
    ida_bytes.create_struct(targetAddr, size, ida_struct.get_struc_id(name),True)
def applyUStruct(targetAddr,name):
    Debug('ApplyStruct('+hex(targetAddr-base)+',\''+name+'\')')
    ApplyStruct(targetAddr,name)
def applyArray(targetAddr,size):
    Debug('make_array(0x%X,%d)' % (targetAddr-base,size))
    make_array(targetAddr,size)
def ApplyStructArray(targetAddr,name,n):
    sid=ida_struct.get_struc_id(name)
    size=ida_struct.get_struc_size(sid)
    for i in range(n): ApplyStruct(targetAddr+size*i,name)

def searchUTF16(name):
    pattern='00 00 '+' '.join('{:02X}'.format(x) for x in name.encode('utf-16le'))+' 00 00'
    result=ida_search.find_binary(UTF16start, UTF16end, pattern, 0, idc.SEARCH_DOWN)
    if isFound(result): result+=2
    return result
def searchAscii(name):
    pattern='00 '+' '.join('{:02X}'.format(x) for x in name.encode('utf-8'))+' 00'
    result=ida_search.find_binary(AsciiSTRstart, AsciiSTRend, pattern, 0, idc.SEARCH_DOWN)
    if isFound(result): result+=1
    return result
def searchDataRef(targetAddr):
    dataSeg=ida_segment.get_segm_by_name('.data')
    return ida_search.find_binary(dataSeg.start_ea, dataSeg.end_ea, '%X'%targetAddr, 0, idc.SEARCH_DOWN)
def MakeFunc(addr):
    if not(codeEnd>addr>codeStart): return
    addr=addr//4*4
    while ida_bytes.get_wide_dword(addr) in (0,0xD503201F,0xE7FFDEFE): addr+=4
    if ida_funcs.is_func_tail(ida_funcs.get_fchunk(addr)):
        ida_funcs.remove_func_tail(ida_funcs.get_func(addr),ida_funcs.get_fchunk(addr).start_ea)
        AddFunc(addr)
    while idaapi.get_func(addr)==None or not(isCode(addr)):
        funcStart=idc.get_func_attr(idc.get_prev_fchunk(addr),idc.FUNCATTR_END)
        while ida_bytes.get_wide_dword(funcStart) in (0,0xD503201F,0xE7FFDEFE): funcStart+=4
        Debug('%X: Making Function at %X'%(addr,funcStart))
        ida_bytes.del_items(funcStart)
        AddFunc(funcStart)
    ida_auto.auto_wait()
def AddFunc(funcStart):
    if not(ida_funcs.add_func(funcStart)):
        funcEnd=idc.find_func_end(funcStart)
        if notFound(funcEnd) or funcEnd<funcStart:
            funcEnd=funcStart+4
            while idc.print_insn_mnem(funcEnd) not in ('RET','B','BR') and funcEnd<codeEnd and not(ida_bytes.get_wide_dword(funcEnd) in (0,0xD503201F,0xE7FFDEFE)): funcEnd+=4
            if idc.print_insn_mnem(funcEnd) in ('RET','B','BR'): funcEnd+=4
            ida_funcs.add_func(funcStart,funcEnd)
            ida_auto.auto_wait()
def GetFuncStart(targetAddr):
    func=ida_funcs.get_fchunk(targetAddr)
    if func==None: MakeFunc(targetAddr);func=ida_funcs.get_fchunk(targetAddr)
    targetAddr=ida_funcs.get_fchunk(targetAddr).start_ea
    if ida_funcs.is_func_tail(ida_funcs.get_fchunk(targetAddr)):
        ida_funcs.remove_func_tail(ida_funcs.get_func(targetAddr),ida_funcs.get_fchunk(targetAddr).start_ea)
        AddFunc(targetAddr)
    MakeFunc(targetAddr)
    return idc.get_func_attr(targetAddr,idc.FUNCATTR_START)
def GetFuncEnd(targetAddr):
    MakeFunc(targetAddr)
    return idc.get_func_attr(targetAddr,idc.FUNCATTR_END)
def AOB(pattern,searchStart=codeStart,searchEnd=codeEnd):
    return ida_search.find_binary(searchStart, searchEnd, pattern, 0, idc.SEARCH_DOWN|SEARCH_NEXT) if not(gdb) else BADADDR
def AOB2(pattern,offset,pattern2=None): # funcion inside
    opAddr=AOB(pattern) if type(pattern) is str else pattern
    if notFound(opAddr): return BADADDR
    return get_operand_value(opAddr+offset,0) if pattern2 is None else AOB(pattern2,get_operand_value(opAddr+offset,0)) 
def AOB3(pattern,pattern2):
    opAddr=AOB(pattern) if type(pattern) is str else pattern
    if notFound(opAddr): return BADADDR
    return AOB(pattern2,opAddr) if type(pattern2) is str else opAddr+pattern2
def AllOccur(pattern,offset=0):
    result=[]
    cheatAddr=AOB(pattern)
    while isFound(cheatAddr):
        result.append(cheatAddr+offset)
        cheatAddr=AOB(pattern,cheatAddr+4)
    return result
def checkUnique(pattern):
    cheatAddr=AOB(pattern)
    return notFound(AOB(pattern,cheatAddr)) if isFound(cheatAddr) else None
def GetBytesPattern(opAddr):
    return ' '.join('{:02X}'.format(x) for x in ida_bytes.get_bytes(opAddr, 4))
def anaysis(opAddr):
    cmd=idc.print_insn_mnem(opAddr)
    if cmd == 'BL' or cmd == 'B':
        return '? ? ? {:02X}'.format(ida_bytes.get_original_byte(opAddr+3))
    elif cmd == 'ADRP' or cmd == 'ADRL':
        return '? ? ? ?'
    elif cmd == '' and idc.print_insn_mnem(opAddr-4)=='ADRL':
        return "? ? ? {:02X}".format(ida_bytes.get_original_byte(opAddr+3))
    elif 'PAGEOFF' in print_operand(opAddr,1):
        return "{:02X} ? ? {:02X}".format(ida_bytes.get_original_byte(opAddr),ida_bytes.get_original_byte(opAddr+3))
    else:
        return GetBytesPattern(opAddr)
def GetAOB(opAddr=BADADDR):
    if notFound(opAddr): opAddr=get_screen_ea()
    pattern=space=''
    result=False
    funcEnd=GetFuncEnd(opAddr)
    while opAddr<funcEnd and result==False:
        pattern+=space+anaysis(opAddr)
        space=' '
        opAddr+=4
        result=checkUnique(pattern)
    print(pattern)
    if result==None: warning('Pattern not Unqiue!')
    
def SearchNextASM(addr,command,operand0=None,operand1=None,operand2=None,limit=0):
    while ida_bytes.get_wide_dword(addr) in (0,0xD503201F,0xE7FFDEFE): addr+=4
    limitAddr=GetFuncEnd(addr) if limit==0 else addr+limit
    addr+=4
    while addr<limitAddr:
        if command in ('LDR','LDRB','STR','STRB'):
            if (idc.print_insn_mnem(addr)==command) and \
               (operand0==None or print_operand(addr,0)==operand0) and \
               (operand1==None or print_operand(addr,1)[1:len(operand1)+1]==operand1) and \
               (operand2==None or get_operand_value(addr,1)==operand2): break
        elif command in ('LDP','STP'):
            if(idc.print_insn_mnem(addr)==command) and \
               (operand0==None or print_operand(addr,0)==operand0) and \
               (operand1==None or print_operand(addr,1)==operand1) and \
               (operand2==None or (isinstance(operand2, str) and print_operand(addr,2)[1:len(operand2)+1]==operand2) or (isinstance(operand2, int) and get_operand_value(addr,2)==operand2)): break
        else:
            if (idc.print_insn_mnem(addr)==command) and \
               (operand0==None or print_operand(addr,0)==operand0 or (isinstance(operand0, int) and get_operand_value(addr,0)==operand0)) and \
               (operand1==None or print_operand(addr,1)==operand1 or (isinstance(operand1, int) and get_operand_value(addr,1)==operand1)) and \
               (operand2==None or print_operand(addr,2)==operand2 or (isinstance(operand2, int) and get_operand_value(addr,2)==operand2)): break
        addr+=4
    return addr if addr<limitAddr else BADADDR
    
def SearchPrevASM(addr,command,operand0=None,operand1=None,operand2=None,limit=0):
    addr-=4
    while ida_bytes.get_wide_dword(addr) in (0,0xD503201F,0xE7FFDEFE): addr-=4
    # p(addr)
    limitAddr = GetFuncStart(addr) if limit==0 else limitAddr-limit
    while addr>=limitAddr:
        if command in ('LDR','LDRB','STR','STRB'):
            if (idc.print_insn_mnem(addr)==command) and \
               (operand0==None or print_operand(addr,0)==operand0) and \
               (operand1==None or print_operand(addr,1)[1:len(operand1)+1]==operand1) and \
               (operand2==None or get_operand_value(addr,1)==operand2): break
        elif command in ('LDP','STP'):
            if(idc.print_insn_mnem(addr)==command) and \
               (operand0==None or print_operand(addr,0)==operand0) and \
               (operand1==None or print_operand(addr,1)==operand1) and \
               (operand2==None or (isinstance(operand2, str) and print_operand(addr,2)[1:len(operand2)+1]==operand2) or (isinstance(operand2, int) and get_operand_value(addr,2)==operand2)): break
        else:
            if (idc.print_insn_mnem(addr)==command) and \
               (operand0==None or print_operand(addr,0)==operand0 or (isinstance(operand0, int) and get_operand_value(addr,0)==operand0)) and \
               (operand1==None or print_operand(addr,1)==operand1 or (isinstance(operand1, int) and get_operand_value(addr,1)==operand1)) and \
               (operand2==None or print_operand(addr,2)==operand2 or (isinstance(operand2, int) and get_operand_value(addr,2)==operand2)): break
        addr-=4
    return addr if addr>=limitAddr else BADADDR

def SearchXrefASM(funcAddr,command,operand0=None,operand1=None,listAll=False):
    addr=BADADDR
    results=[]
    for xref in XrefsTo(funcAddr,0):
        if (idc.print_insn_mnem(xref.frm)==command) and \
           (operand0==None or (print_operand(xref.frm,0)!=operand0[1:] if operand0[0]=='!' else print_operand(xref.frm,0)==operand0) or (isinstance(operand0, int) and get_operand_value(xref.frm,0)==operand0)) and \
           (operand1==None or get_operand_value(xref.frm,1)==operand1): 
            addr=xref.frm; 
            results.append(addr)
            if not listAll: break
    return results if listAll else addr

def fixUTF16():
    addr=UTF16start
    while addr<UTF16end:
        end=ida_search.find_binary(addr, UTF16end, '0 0 0', 0, idc.SEARCH_DOWN)
        if notFound(end) or addr>=UTF16end:break
        length=end-addr+3
        ida_bytes.del_items(addr,0,length)
        ida_bytes.create_strlit(addr, length, 0x2000001)
        show(idc.get_strlit_contents(addr,length,STRTYPE_C_16).decode())
        addr+=length
        while get_wide_word(addr)==0: addr+=2
def fixUTF32(addr):
    while ida_bytes.has_xref(ida_bytes.get_full_flags(addr)) and idc.get_qword(addr)&0xFFFF0000==0:
        end=addr+4
        while not(ida_bytes.has_xref(ida_bytes.get_full_flags(end))) and idc.get_qword(end)&0xFFFF0000==0:end+=4
        assert ida_bytes.has_xref(ida_bytes.get_full_flags(end))
        length=end-addr
        ida_bytes.del_items(addr,0,length)
        ida_bytes.create_strlit(addr, length, STRTYPE_C_32)
        show(idc.get_strlit_contents(addr,length,STRTYPE_C_32).decode())
        addr+=length
        while get_wide_word(addr)==0: addr+=4
def fixSTR():
    addr=get_screen_ea()
    segend=ida_segment.Getseg(addr).end_ea
    while (ida_bytes.has_xref(ida_bytes.get_full_flags(addr)) or get_wide_byte(addr-1)==0) and get_wide_byte(addr)!=0 and addr<segend:
        end=addr+1
        while not(ida_bytes.has_xref(ida_bytes.get_full_flags(end))) and get_wide_byte(end-1)!=0:end+=1
        length=end-addr
        if length<2 or end>segend:break
        ida_bytes.del_items(addr,0,length)
        ida_bytes.create_strlit(addr, length,STRTYPE_C)
        show(idc.get_strlit_contents(addr,length).decode())
        addr+=length
def fixAscString():
    addr=AsciiSTRstart+1
    while addr<AsciiSTRend1:
        end=ida_search.find_binary(addr, AsciiSTRend1, '0', 0, idc.SEARCH_DOWN)
        if notFound(end) or addr>=AsciiSTRend1:break
        length=end-addr+1
        ida_bytes.del_items(addr,0,length)
        ida_bytes.create_strlit(addr, length, STRTYPE_C)
        show(idc.get_strlit_contents(addr).decode())
        addr+=length
        while get_wide_word(addr)==0: addr+=1
def GetUTFstr(addr):
    end=ida_search.find_binary(addr, addr+0x100, '0 0 0', 0, idc.SEARCH_DOWN)
    return idc.get_strlit_contents(addr,end-addr+3,STRTYPE_C_16).decode()
def GetASCstr(addr):
    end=ida_search.find_binary(addr, addr+0x100, '0', 0, idc.SEARCH_DOWN)
    return idc.get_strlit_contents(addr,end-addr+1).decode()
def createStruct(name,members):
    global ReBuildStruct
    struct=ida_struct.get_struc_id(name)
    if isFound(struct):
        # if ReBuildStruct is None: ReBuildStruct=ida_kernwin.ask_yn(False, 'HIDECANCEL\nReBuild all struct?')
        ReBuildStruct=False
        if not(ReBuildStruct): return
        idc.del_struc(struct)
    struct=idc.add_struc(BADADDR, name, False)
    for fieldname,ftype in members:
        size=dict(((ida_bytes.FF_BYTE,1),(ida_bytes.FF_WORD,2),(ida_bytes.FF_DWORD,4),(ida_bytes.FF_FLOAT,4),(FF_4BIT,4),(ida_bytes.FF_QWORD,8),(FF_OFFSET,8),(ida_bytes.FF_DOUBLE,8),(FF_8BIT,8)))[ftype]
        idc.add_struc_member(struct, fieldname, BADADDR, ftype, BADADDR, size) 
def createStructs():
    createStruct('U50',(('init',FF_OFFSET),('class',FF_OFFSET),('id',ida_bytes.FF_QWORD),('Parents',FF_OFFSET),('Methods',FF_OFFSET),('Properties',FF_OFFSET),('FList',FF_OFFSET),('ParentCount',FF_4BIT),('MethodsCount',FF_4BIT),('PropertiesCount',FF_4BIT),('FListCount',FF_4BIT),('f48',ida_bytes.FF_WORD),('f4A',ida_bytes.FF_WORD),('f4C',ida_bytes.FF_DWORD)))
    createStruct('O48',(('class',FF_OFFSET),('f8',ida_bytes.FF_QWORD),('delegateSign',FF_OFFSET),('parents',FF_OFFSET),('funcName',FF_OFFSET),('f28',ida_bytes.FF_DWORD),('UProperty',FF_OFFSET),('f38',ida_bytes.FF_DWORD),('f3C',ida_bytes.FF_DWORD),('id',ida_bytes.FF_QWORD)))
    createStruct('F48',(('class',FF_OFFSET),('f8',ida_bytes.FF_QWORD),('methodName',FF_OFFSET),('f18',ida_bytes.FF_QWORD),('f20',ida_bytes.FF_QWORD),('f28',ida_bytes.FF_QWORD),('arguments',FF_OFFSET),('ArgsNum',ida_bytes.FF_DWORD),('f3C',ida_bytes.FF_DWORD),('id',ida_bytes.FF_QWORD)))
    createStruct('S48',(('class',FF_OFFSET),('f8',ida_bytes.FF_QWORD),('script',FF_OFFSET),('scriptName',FF_OFFSET),('size',ida_bytes.FF_QWORD),('u28',ida_bytes.FF_QWORD),('properties',FF_OFFSET),('propertiesCount',ida_bytes.FF_DWORD),('f3C',ida_bytes.FF_DWORD),('type',ida_bytes.FF_QWORD)))
    createStruct('E38',(('class',FF_OFFSET),('f8',ida_bytes.FF_QWORD),('name',FF_OFFSET),('typeName',FF_OFFSET),('Enum',FF_OFFSET),('EnumCount',FF_4BIT),('f2C',ida_bytes.FF_DWORD),('f30',ida_bytes.FF_QWORD)))
    createStruct('P20',(('ClassName',FF_OFFSET),('delegateSign',FF_OFFSET),('count',ida_bytes.FF_DWORD),('f14',ida_bytes.FF_DWORD),('ID',ida_bytes.FF_QWORD)))
    createStruct('E10',(('enumName',FF_OFFSET),('index',FF_8BIT)))
    createStruct('F10',(('funcName',FF_OFFSET),('funcAddr',FF_OFFSET)))
    createStruct('M10',(('methodAddr',FF_OFFSET),('methodName',FF_OFFSET)))
    createStruct('P28',(('fieldname',FF_OFFSET),('f8',ida_bytes.FF_QWORD),('f10',ida_bytes.FF_DWORD),('f14',ida_bytes.FF_DWORD),('f18',ida_bytes.FF_DWORD),('f1C',ida_bytes.FF_DWORD),('f20',ida_bytes.FF_DWORD),('f24',ida_bytes.FF_DWORD)))
    createStruct('P30',(('fieldname',FF_OFFSET),('f8',ida_bytes.FF_QWORD),('f10',ida_bytes.FF_DWORD),('f14',ida_bytes.FF_DWORD),('f18',ida_bytes.FF_DWORD),('f1C',ida_bytes.FF_DWORD),('f20',ida_bytes.FF_DWORD),('offset',ida_bytes.FF_DWORD),('f28',FF_OFFSET)))
    createStruct('P38',(('fieldname',FF_OFFSET),('f8',ida_bytes.FF_QWORD),('f10',ida_bytes.FF_DWORD),('f14',ida_bytes.FF_DWORD),('f18',ida_bytes.FF_DWORD),('f1C',ida_bytes.FF_DWORD),('f20',ida_bytes.FF_DWORD),('f24',ida_bytes.FF_DWORD),('f28',ida_bytes.FF_QWORD),('f30',FF_OFFSET)))
    createStruct('UFunc',(('FunctionBuilder',FF_OFFSET),('f08',ida_bytes.FF_DWORD),('f0C',ida_bytes.FF_DWORD),('f10',FF_OFFSET),('f18',ida_bytes.FF_QWORD),('f20',FF_OFFSET),('f28',ida_bytes.FF_QWORD),('f30',FF_OFFSET),('f38',ida_bytes.FF_QWORD),('f40',ida_bytes.FF_QWORD),('f48',ida_bytes.FF_QWORD),('f50',FF_OFFSET),('f58',ida_bytes.FF_DWORD),('f5C',ida_bytes.FF_DWORD),('f60',ida_bytes.FF_QWORD),('f68',ida_bytes.FF_QWORD),('f70',FF_OFFSET),('f78',ida_bytes.FF_QWORD),('f80',ida_bytes.FF_QWORD),('f88',ida_bytes.FF_QWORD),('f90',ida_bytes.FF_QWORD),('f98',ida_bytes.FF_QWORD),('fA0',ida_bytes.FF_QWORD),('fA8',ida_bytes.FF_QWORD),('fB0',ida_bytes.FF_QWORD),('fB8',ida_bytes.FF_QWORD),('fC0',ida_bytes.FF_QWORD),('fC8',ida_bytes.FF_QWORD),('fD0',ida_bytes.FF_QWORD),('fD8',FF_OFFSET)))
    createStruct('FuncMap',(('fname',FF_OFFSET),('loader',FF_OFFSET),('funcAddr',FF_OFFSET),('isOffset',ida_bytes.FF_QWORD),('f20',FF_OFFSET),('f28',ida_bytes.FF_QWORD),('f30',FF_OFFSET)))
    createStruct('Array',(('content',FF_OFFSET),('s1',ida_bytes.FF_DWORD),('s2',ida_bytes.FF_DWORD)))
    createStruct('Object',(('Assets',FF_OFFSET),('f08',ida_bytes.FF_DWORD),('f0C',ida_bytes.FF_DWORD),('Parent',FF_OFFSET),('f18',ida_bytes.FF_DWORD),('f1C',ida_bytes.FF_DWORD),('Owner',FF_OFFSET)))
def Rebase(targetAddr):
    if idc.get_qword(targetAddr)<base: Patch_qword(targetAddr,idc.get_qword(targetAddr)+base)
def ApplyComment(targetAddr,comment):
    idc.set_cmt(targetAddr,comment,1)
def addEmptyLines(targetAddr):
    ida_lines.del_extra_cmt(targetAddr,E_NEXT)
    ida_lines.del_extra_cmt(targetAddr,E_NEXT+1)
    ida_lines.add_extra_line(targetAddr,False,'\n\n')
def addPriorComment(targetAddr,comment):
    ida_lines.del_extra_cmt(targetAddr,E_PREV)
    ida_lines.add_extra_line(targetAddr,True,comment)
def ExtractUObjectClass(objectAddr,name):
    applyUStruct(objectAddr, 'U50')
    Patch(objectAddr,name+'_Class',next(XrefsTo(objectAddr)).frm)
    addEmptyLines(objectAddr)
    if isPointer(objectAddr+0x30):
        addr=idc.get_qword(objectAddr+0x30)
        count=ida_bytes.get_wide_dword(objectAddr+0x44)
        ApplyStructArray(addr,'E10',count)
        Patch(addr,name+'_FList',objectAddr+0x30)
    if isPointer(objectAddr+0x28):
        addr=idc.get_qword(objectAddr+0x28)
        count=ida_bytes.get_wide_dword(objectAddr+0x40)
        ExtractUProperty(addr,count,name)
        Patch(addr,name+'_Properties',objectAddr+0x28)
    if isPointer(objectAddr+0x20):
        addr=idc.get_qword(objectAddr+0x20)
        count=ida_bytes.get_wide_dword(objectAddr+0x3C)
        ExtractMethodPairs(addr,count,name)
        Patch(addr,name+'_Methods',objectAddr+0x20)
    if isPointer(objectAddr+0x18):
        addr=idc.get_qword(objectAddr+0x18)
        count=ida_bytes.get_wide_dword(objectAddr+0x38)
        ExtractParents(addr,count)
        Patch(addr,name+'_Parents',objectAddr+0x18)
    if isPointer(objectAddr):
        assetAddr=idc.get_qword(objectAddr)
        if idc.print_insn_mnem(assetAddr)=='B':
            assetName=ExtractUAsset(get_operand_value(assetAddr,0))
            Patch(assetAddr,'j_%s'%assetName,addr)
        elif idc.print_insn_mnem(assetAddr+8)=='BL' and idc.print_insn_mnem(assetAddr+16)=='RET':
            assetName=ExtractUAsset(get_operand_value(assetAddr+8,0))
            Patch(assetAddr,'j_%s'%assetName,addr)
        else:
            ExtractUAsset(assetAddr)

def ExtractUAsset(loaderAddr):
    loaderAddr=GetFuncStart(loaderAddr)
    funcEnd=GetFuncEnd(loaderAddr)
    blUassetBuilder=SearchPrevASM(funcEnd,'BL',GetUassetBuilder())
    x1=SearchPrevASM(blUassetBuilder,'ADRL','X1')
    if notFound(x1): Debug(hex(loaderAddr)+' interrupt at line %d'%getframeinfo(currentframe()).lineno);return
    nameAddr=get_operand_value(x1,1)-2
    objectName=GetUTFstr(nameAddr)
    fullObjectName='%s'%objectName
    Patch(loaderAddr,'%s_Loader'%fullObjectName,x1)

    x2=SearchPrevASM(blUassetBuilder,'MOV','X2')
    if isFound(x2):
        addr=SearchPrevASM(x2,'ADRL',print_operand(x2,1))
        if isFound(addr): Patch(get_operand_value(addr,1),'%s_Pointer'%fullObjectName,addr)
    ExtractUAssetConstructor(blUassetBuilder,fullObjectName)
    ExtractUAssetFunctions(blUassetBuilder,fullObjectName)
    return fullObjectName

def ExtractUAssetFunctions(blUassetBuilder,fullObjectName):
    x3=SearchPrevASM(blUassetBuilder,'ADRL','X3')
    if isFound(x3):
        FListLoader=get_operand_value(x3,1)
        if not(isFunc(FListLoader)): MakeFunc(FListLoader)
        if idc.print_insn_mnem(FListLoader)=='RET':
            Patch(FListLoader,'null_%s_FList_Loader'%fullObjectName,x3)
        else:
            if idc.print_insn_mnem(FListLoader)=='B':
                Patch(FListLoader,'j_%s_FList_Loader'%fullObjectName,x3)
                x3=FListLoader
                FListLoader=get_operand_value(x3,0)
            Patch(FListLoader,'%s_FList_Loader'%fullObjectName,x3)
            FuncAddr=SearchNextASM(FListLoader,'BL')
            # adrl=SearchPrevASM(FuncAddr,'ADRL','X3')
            # if isFound(adrl):
                # Patch(get_operand_value(adrl,1),'%s'%fullObjectName,adrl)
            # adrl=SearchPrevASM(FuncAddr,'MOV','X2')
            # if isFound(adrl):
                # adrl=SearchPrevASM(adrl,'ADRL',print_operand(adrl,1))
                # if isFound(adrl):
                    # Patch(get_operand_value(adrl,1),'ptr_%s_FList'%fullObjectName,adrl)
            adrl=SearchNextASM(FuncAddr,'ADRL','X1')
            FList=get_operand_value(adrl,1)
            if dataStart<=FList<dynamicStart:
                Patch(FList,'%s'%fullObjectName,adrl)
                addr=FList
                while isString(idc.get_qword(addr)) and isFunc(idc.get_qword(addr+8)):
                    applyUStruct(addr, 'F10')
                    functionName=idc.get_strlit_contents(idc.get_qword(addr)).decode()
                    Patch(idc.get_qword(addr),'s_%s'%functionName,addr)
                    functionLoader=idc.get_qword(addr+8)
                    Patch(functionLoader,'%s.%s'%(fullObjectName,functionName),addr+8)
                    addr+=16
                    ExtractUAssetFunctionLoader(functionLoader,'%s.%s'%(fullObjectName,functionName))

def ExtractUAssetFunctionLoader(functionLoader,functionName):
    x0=SearchNextASM(functionLoader,'MOV',None,'X0') # to find MOV ??, X0
    if notFound(x0):
        addr=functionLoader
    else:    
        addr=SearchNextASM(x0,'MOV','X0',print_operand(x0,0)) # to find MOV X0, Xn
        if notFound(addr):show('Cannot found %s at %X'%(functionName,x0));return 
    bl=SearchNextASM(addr,'BL')
    if notFound(bl):show('Cannot found %s at %X'%(functionName,addr));return 
    Patch(get_operand_value(bl,0),functionName,bl)    

def ExtractUAssetConstructor(blUassetBuilder,fullObjectName):
    AssetConstructorRegAddr=SearchPrevASM(blUassetBuilder,'STP',None,None,0)
    if isFound(AssetConstructorRegAddr): 
        AssetConstructorAddr=SearchPrevASM(AssetConstructorRegAddr,'ADRL',print_operand(AssetConstructorRegAddr,1))
        if isFound(AssetConstructorAddr): 
            AssetConstructor=get_operand_value(AssetConstructorAddr,1) # [SP+8] load functions for this class  (SP+20 = parent's functions)
            if not(isFunc(AssetConstructor)): MakeFunc(AssetConstructor)
            addr=SearchNextASM(AssetConstructor,'B')
            if isFound(addr) and addr-AssetConstructor<16:
                Patch(AssetConstructor,'j_%s_Constructor'%fullObjectName,AssetConstructorAddr)
                AssetConstructor=get_operand_value(addr,0)
                AssetConstructorAddr=addr
                if not(isFunc(AssetConstructor)): MakeFunc(AssetConstructor)

                x0=SearchNextASM(AssetConstructor,'MOV',None,'X0') # to find MOV ??, X0
                temp=SearchNextASM(AssetConstructor,'STR','X0','X29')  # to find STR X0, [X29,??]
                if isFound(temp) and (notFound(x0) or temp<x0):
                    x0=SearchNextASM(AssetConstructor,'LDR',None,'X29',get_operand_value(temp,1))  # to find LDR X?, [X29,n]
            else:
                x0=SearchNextASM(AssetConstructor,'LDR',None,'X0',0) 
            if notFound(x0): 
                show('Cannot found %s_Constructor %X'%(fullObjectName,AssetConstructor))
                return fullObjectName
            Patch(AssetConstructor,'%s_Constructor'%fullObjectName,AssetConstructorAddr)
            x8=SearchNextASM(x0,'STR',None,print_operand(x0,0),0) # to find STR X?, [Xn]
            AssetAddr=BADADDR
            if isFound(x8):
                regName=print_operand(x8,0)
                adrl=SearchPrevASM(x8,'ADRL',regName)
                if isFound(adrl):
                    AssetAddr=get_operand_value(adrl,1)
                else:
                    addend=SearchPrevASM(x8,'ADD',regName)
                    offset=SearchPrevASM(addend,'LDR',print_operand(addend,1))
                    offset2=SearchPrevASM(x8,'LDR',regName)
                    if isFound(addend) and isFound(offset) and (notFound(offset2) or addend>offset2):
                        regName=print_operand(addend,1)
                        addendOffset=get_operand_value(addend,2)
                    elif isFound(offset2):
                        addendOffset=0
                        offset=offset2
                    else:
                        show('Cannot found %s_Constructor %X'%(fullObjectName,AssetConstructor))
                        return fullObjectName
                    base=SearchPrevASM(offset,'ADRP',print_operand(offset,0))
                    if isFound(base):
                        AssetAddr=get_operand_value(base,1)+get_operand_value(offset,1)
                    else:
                        show('Cannot found %s_Constructor %X'%(fullObjectName,AssetConstructor))
                        return fullObjectName
            else:
                show('Cannot found %s_Constructor %X'%(fullObjectName,AssetConstructor))
                return fullObjectName
            if RELAstart<=AssetAddr<RELAend or GOTstart<=AssetAddr<GOTend:
                Patch(AssetAddr,'j_%s_Assets'%fullObjectName,AssetConstructorAddr)
                AssetConstructorAddr=AssetAddr
                AssetAddr=idc.get_qword(AssetConstructorAddr)
            Patch(AssetAddr,'%s_Assets'%fullObjectName,AssetConstructorAddr)

def ExtractUClass(UClassAddr,UClassName):
    x0=SearchPrevASM(GetFuncEnd(UClassAddr),'MOV','X0')
    if notFound(x0): halt('UOBject %s Pointer %X cannot be found!'%(UClassName,UClassAddr))
    UClassPointer=SearchPrevASM(x0,'ADRL',print_operand(x0,1))
    Patch(get_operand_value(UClassPointer,1),'%s_Pointer'%UClassName,UClassAddr)
    x1=SearchPrevASM(GetFuncEnd(UClassAddr),'ADRL','X1')
    if notFound(x1): halt('UOBject %s %X cannot be found!'%(UClassName,UClassAddr))
    ExtractUObjectClass(get_operand_value(x1,1),UClassName)

def ExtractPackage(objectAddr):
    applyUStruct(objectAddr,'P20')
    nameAddr=idc.get_qword(objectAddr)
    PackageName=idc.get_strlit_contents(nameAddr).decode().replace('/Script/','')
    Patch(nameAddr,'s_'+PackageName,objectAddr)
    PackageName='%s'%(PackageName)
    Patch(objectAddr,PackageName+'_Class',nameAddr)
    addEmptyLines(objectAddr)
    if isPointer(objectAddr+0x8) and idc.get_qword(objectAddr+0x10)>0:
        startAddr=idc.get_qword(objectAddr+0x8)
        Patch(startAddr,PackageName,objectAddr+0x8)
    return PackageName
    
def ExtractMethodPairs(startAddr,count,parentName):
    for i in range(count):
        addr=startAddr+i*16
        if not(isString(idc.get_qword(addr+8)) and isFunc(idc.get_qword(addr))): continue
        applyUStruct(addr, 'M10')
        methodName='%s.%s'%(parentName,idc.get_strlit_contents(idc.get_qword(addr+8)).decode())
        Patch(idc.get_qword(addr+8),'s_%s'%methodName,addr)
        methodAddr=idc.get_qword(addr)
        Patch(methodAddr,'%s_Loader'%methodName,addr)
        
        addr=SearchPrevASM(GetFuncEnd(methodAddr),'MOV','X0')
        if isFound(addr):
            addr=SearchPrevASM(addr,'ADRL',print_operand(addr,1))
            if isFound(addr): Patch(get_operand_value(addr,1),'%s_Pointer'%methodName,addr)

        addr=SearchPrevASM(GetFuncEnd(methodAddr),'ADRL','X1')
        if isFound(addr): ExtractMethodObject(get_operand_value(addr,1))

def ExtractUProperty(start,count,className):
    op_plain_offset(start,0,0);
    applyArray(start,count)
    lastPos=start
    for i in reversed(range(count)):
        aProperty=idc.get_qword(start+i*8)
        length=lastPos-aProperty
        lastPos=aProperty
        applyUStruct(aProperty,'P%02X'%length)
        propertyName=GetASCstr(idc.get_qword(aProperty))
        Patch(aProperty,className+'.'+propertyName,idc.get_qword(aProperty))
        if length==0x38:
            setter=aProperty+0x30
            if isPointer(setter) and isFunc(idc.get_qword(setter)):
                Patch(idc.get_qword(setter),'%s.%s_Setter'%(className,propertyName),setter)
        # elif length==0x30:
            # setter=aProperty+0x28
            # if isPointer(setter) and isFunc(idc.get_qword(setter)):
                # Patch(idc.get_qword(setter),'%s_Setter'%(className,propertyName),setter)

def studyMethod(addr):
    methodName=GetASCstr(idc.get_qword(addr+8))
    target=idc.get_qword(addr)
    Patch(target,methodName,addr)
    while not(idc.print_insn_mnem(target)=='ADRL' and print_operand(target,0)=='X1'): target+=4
    aMethod=get_operand_value(target,1)
    Patch(aMethod, methodName+'_Class', target)
    addEmptyLines(objectAddr)
    applyUStruct(aMethod,'M%02X'%(cutline-aMethod))
    cutline=aMethod
    aProperty=idc.get_qword(aMethod+0x30)
    if aProperty>0:
        cutline=aProperty
        arg=aMethod-8
        while arg>=aProperty:
            op_plain_offset(arg,0,0)
            target=idc.get_qword(arg)
            applyUStruct(target,'P%02X'%(cutline-target))
            cutline=target
            arg-=8
        applyArray(aProperty,(aMethod-aProperty)//8)

def ExtractParents(start,count):
    op_plain_offset(start,0,0)
    applyArray(start,count)

uobjectAddr=UObjectBuilder=PackageBuilder=UassetBuilder=MethodBuilder=ScriptAssetBuilder=EnumBuilder=None

def GetUObject():
    global uobjectAddr
    if uobjectAddr is None: 
        GetUObjectBuilder()
        uobjectAddr=idc.get_name_ea(dataStart,'UObject_Class')
    if notFound(uobjectAddr): halt('UObject_Class not found!')
    return uobjectAddr
 
def GetUObjectBuilder():
    global uobjectAddr,UObjectBuilder
    if UObjectBuilder is None:
        s_UObject=searchUTF16('UObject')
        if notFound(s_UObject): warning('UTF string: UObject not found!'); return
        addrs=SearchXrefASM(s_UObject,'ADRL','!X1',listAll=True)
        for addr in addrs:
            if notFound(addr): continue
            x0=SearchNextASM(addr,'ADRL','X0',limit=40)
            if notFound(x0): continue
            UObjectLoader=get_operand_value(x0,1)
            bl=SearchPrevASM(GetFuncEnd(UObjectLoader),'BL')
            if notFound(bl): continue
            UObjectBuilder=get_operand_value(bl,0)
            x1=SearchPrevASM(bl,'ADRL','X1')
            if notFound(x1): continue
            uobjectAddr=get_operand_value(x1,1)
            Patch(UObjectLoader,'UObject_Loader',x0)
            Patch(UObjectBuilder,'UObjectBuilder',bl)
            Patch(uobjectAddr,'UObject_Class',x1)
            break
    return UObjectBuilder

def GetPackageBuilder():
    global PackageBuilder
    if PackageBuilder is None:
        UobjectParent=idc.get_qword(GetUObject()+0x18)
        CoreUObject=idc.get_qword(UobjectParent)
        Patch(CoreUObject,'CoreUObject',UobjectParent)
        bl=SearchPrevASM(GetFuncEnd(CoreUObject),'BL')
        if notFound(bl): Debug(hex(CoreUObject)+' interrupt at line %d'%getframeinfo(currentframe()).lineno);return
        PackageBuilder=get_operand_value(bl,0)
        Patch(PackageBuilder,'PackageBuilder',bl)
        x1=SearchPrevASM(bl,'ADRL','X1')
        if notFound(x1): Debug(hex(PackageBuilder)+' interrupt at line %d'%getframeinfo(currentframe()).lineno);return
        objectAddr=get_operand_value(x1,1)
        Patch(objectAddr,'CoreUObject_Class',x1)
    return PackageBuilder

def GetUassetBuilder():
    global UassetBuilder
    if UassetBuilder is None:
        uobjectAddr=GetUObject()
        UObjectAsset=idc.get_qword(uobjectAddr)
        if idc.print_insn_mnem(UObjectAsset)=='B':
            Patch(UObjectAsset,'j_UObject_Loader',uobjectAddr)
            UObjectAsset=get_operand_value(UObjectAsset,0)
        Patch(UObjectAsset,'UObject_Loader',uobjectAddr)
        bl=SearchPrevASM(GetFuncEnd(UObjectAsset),'BL')
        if notFound(bl): Debug(hex(UObjectAsset)+' interrupt at line %d'%getframeinfo(currentframe()).lineno);return
        UassetBuilder=get_operand_value(bl,0)
        Patch(UassetBuilder,'UassetBuilder',bl)
    return UassetBuilder

def GetMethodBuilder():
    global MethodBuilder
    if MethodBuilder is None:
        anyMethod=idc.get_qword(idc.get_qword(GetUObject()+0x20))
        bl=SearchPrevASM(GetFuncEnd(anyMethod),'BL')
        if notFound(bl): Debug(hex(anyMethod)+' interrupt at line %d'%getframeinfo(currentframe()).lineno);return
        MethodBuilder=get_operand_value(bl,0)
        Patch(MethodBuilder,'MethodBuilder',bl)
    return MethodBuilder

def GetScriptAssetBuilder():
    global ScriptAssetBuilder
    if ScriptAssetBuilder is None:
        CoreuobjectAddr=idc.get_name_ea(dataStart,'CoreUObject_Class')
        if notFound(CoreuobjectAddr): GetPackageBuilder(); CoreuobjectAddr=idc.get_name_ea(dataStart,'CoreUObject_Class')
        anyScriptAsset=idc.get_qword(idc.get_qword(CoreuobjectAddr+0x8))
        bl=SearchPrevASM(GetFuncEnd(anyScriptAsset),'BL')
        if notFound(bl): Debug(hex(anyScriptAsset)+' interrupt at line %d'%getframeinfo(currentframe()).lineno);return
        ScriptAssetBuilder=get_operand_value(bl,0)
        Patch(ScriptAssetBuilder,'ScriptAssetBuilder',bl)
    return ScriptAssetBuilder

def GetEnumBuilder():
    global EnumBuilder
    if EnumBuilder is None:
        s_EUnit=searchAscii('EUnit')
        if notFound(s_EUnit): warning('Ascii EUnit not found!');return
        EUnit_Struc=searchDataRef(s_EUnit)
        if notFound(EUnit_Struc): Debug(hex(s_EUnit)+' interrupt at line %d'%getframeinfo(currentframe()).lineno);return
        Patch(EUnit_Struc-0x10,'EUnit_Class',EUnit_Struc)
        EUnit_Struc-=0x10
        EUnit=SearchXrefASM(EUnit_Struc,'ADRL','X1')
        if notFound(EUnit): Debug(hex(EUnit_Struc)+' interrupt at line %d'%getframeinfo(currentframe()).lineno);return
        Patch(GetFuncStart(EUnit),'EUnit',EUnit)
        bl=SearchNextASM(EUnit,'BL')
        if notFound(bl): Debug(hex(EUnit)+' interrupt at line %d'%getframeinfo(currentframe()).lineno);return
        EnumBuilder=get_operand_value(bl,0)
        Patch(EnumBuilder,'EnumBuilder',bl)
    return EnumBuilder


def BuildUAsset():
    UassetObjects=list(CodeRefsTo(GetUassetBuilder(),0))
    total=len(UassetObjects)
    current=0
    for addr in UassetObjects:
        current+=1
        objectName=ExtractUAsset(addr)
        show('Extracting UAsset ( %d / %d ) \n %s'%(current,total,objectName))

def BuildUObjects():
    UObjects=list(CodeRefsTo(GetUObjectBuilder(),0))
    total=len(UObjects)
    current=0
    for addr in UObjects:
        current+=1
        className=ExtractUObject(addr)
        show('Extracting UObjects ( %d / %d ) \n %s'%(current,total,className))
   
def ExtractUObject(addr):
    UObjectLoader=GetFuncStart(addr)
    x0=SearchXrefASM(UObjectLoader,'ADRL','X0')
    if notFound(x0): Debug('%X interrupt at line %d'%(addr,getframeinfo(currentframe()).lineno)); return
    bl=SearchNextASM(x0,'BL')
    if notFound(bl): bl=GetFuncEnd(x0)-4
    NameRegAddr=SearchPrevASM(bl,'MOV','X2')
    if notFound(NameRegAddr): Debug('%X interrupt at line %d'%(bl,getframeinfo(currentframe()).lineno));return
    NameReg=print_operand(NameRegAddr,1)
    nameAddr=SearchPrevASM(NameRegAddr,'ADRL',print_operand(NameRegAddr,1))
    if notFound(nameAddr):Debug('%X interrupt at line %d'%(addr,getframeinfo(currentframe()).lineno));return
    className=GetUTFstr(get_operand_value(nameAddr,1))
    Patch(UObjectLoader,'%s_Loader'%className,nameAddr)
    ExtractUClass(UObjectLoader,className)
    return className
    
    # funcStart=GetFuncStart(addr)
    # while (idc.print_insn_mnem(addr)!='ADRL' or print_operand(addr,0)!='X1') and addr>funcStart: addr-=4
    # if addr<=funcStart:Debug(hex(addr)+' interrupt at line  %d'%getframeinfo(currentframe()).lineno);continue
    # objectAddr=get_operand_value(addr,1)
    # for xref in XrefsTo(funcStart,0):
        # parentAddr=xref.frm
        # if idc.print_insn_mnem(parentAddr)=='ADRL': break
    # if idc.print_insn_mnem(parentAddr)!='ADRL': Debug(hex(objectAddr),hex(funcStart)+' interrupt at line %d'%getframeinfo(currentframe()).lineno);continue
        
    # parentStart=GetFuncStart(parentAddr)
    # parentEnd=GetFuncEnd(parentAddr)
    # addr=parentAddr

    # if print_operand(parentAddr,0)=='X0':
        # while (idc.print_insn_mnem(addr)!='MOV' or print_operand(addr,0)!='X2') and addr<parentEnd: addr+=4
        # if addr>=parentEnd: 
            # addr=parentAddr
            # while (idc.print_insn_mnem(addr)!='MOV' or print_operand(addr,0)!='X2') and addr>parentStart: addr-=4
            # if addr<=parentStart: Debug(hex(parentAddr)+' interrupt at line %d'%getframeinfo(currentframe()).lineno);continue
        # nameRegister=print_operand(addr,1)
        # while (idc.print_insn_mnem(addr)!='ADRL' or print_operand(addr,0)!=nameRegister) and addr>parentStart: addr-=4
        # if addr<=parentStart: Debug(hex(addr)+' interrupt at line %d'%getframeinfo(currentframe()).lineno);continue
    # elif print_operand(parentAddr,0)=='X1':
        # while (idc.print_insn_mnem(addr)!='ADRL' or print_operand(addr,0)!='X4') and addr<parentEnd: addr+=4
        # if addr>=parentEnd: Debug(hex(addr)+' interrupt at line %d'%getframeinfo(currentframe()).lineno);continue
    # else: Debug(hex(parentAddr),hex(funcStart)+' interrupt at line %d'%getframeinfo(currentframe()).lineno);continue
        
    # nameAddr=get_operand_value(addr,1)
    # if nameAddr>UTF16end or nameAddr<=UTF16start: Debug(hex(parentAddr),hex(addr)+' interrupt at line %d'%getframeinfo(currentframe()).lineno);continue
    # GetUTFstr(nameAddr)
    # Patch(funcStart,objectName,parentAddr)
    # show('Extracting UObjects ( %d / %d ) \n %s'%(current,total,objectName))
    # addr=SearchPrevASM(GetFuncEnd(funcStart),'MOV','X0')
    # if isFound(addr):
        # addr=SearchPrevASM(addr,'ADRL',print_operand(addr,1))
        # if isFound(addr): Patch(get_operand_value(addr,1),'%s_Pointer'%objectName,addr)
    # ExtractUObjectClass(objectAddr,objectName)

def BuildEnums():
    EnumObjects=list(CodeRefsTo(GetEnumBuilder(),0))
    total=len(EnumObjects)
    current=0
    for addr in EnumObjects:
        current+=1
        x1=SearchPrevASM(addr,'ADRL','X1')
        if notFound(x1):
            Debug('Extracting Enums ( %d / %d ) Fail at 0x%X'%(current,total,addr))
            continue
        objectAddr=get_operand_value(x1,1)
        enumName=ExtractEnum(objectAddr)
        if enumName=='': continue
        show('Extracting Enums ( %d / %d ) \n %s'%(current,total,enumName))
        loaderAddr=GetFuncStart(addr)
        Patch(loaderAddr,'%s_Loader'%enumName,addr)
        x0=SearchPrevASM(GetFuncEnd(loaderAddr),'MOV','X0')
        if isFound(x0):
            pointerAddr=SearchPrevASM(x0,'ADRL',print_operand(x0,1))
            if isFound(pointerAddr): Patch(get_operand_value(pointerAddr,1),'%s_Pointer'%enumName,pointerAddr)
            
        refs=XrefsTo(loaderAddr,0)
        for jumpAddr in refs:
            if isFunc(jumpAddr.frm):
                Patch(GetFuncStart(jumpAddr),'pre_'+enumName,loaderAddr)

def ExtractEnum2(addr):

    classOffsetRef=SearchNextASM(addr,'STR','X8','X19')
    classOffset=get_operand_value(classOffsetRef,1)
    
    nameAddrRef=SearchNextASM(classOffsetRef,'STR','X8','X19',ClassOffset+0x10)-8
    nameAddr=get_operand_value(nameAddrRef,1)
    objectName='s_'+idc.get_strlit_contents(nameAddr).decode();
    Patch(nameAddr,objectName,nameAddrRef)
    fullObjectName='Enum_%s'%(objectName)

    typeNameRef=SearchNextASM(classOffsetRef,'STR','X8','X19',ClassOffset+0x18)-8
    typeName=get_operand_value(typeNameRef,1)
    Patch(typeName,'s_'+idc.get_strlit_contents(typeName).decode(),typeNameRef)

    enumAddrRef=SearchNextASM(classOffsetRef,'STR','X8','X19',ClassOffset+0x20)-8
    enumAddr=get_operand_value(enumAddrRef,1)

    enumCountRef=SearchNextASM(classOffsetRef,'STR',None,'X19',ClassOffset+0x28)
    register=print_operand(enumCountRef,0)
    enumCountRef=SearchPrevASM(enumCountRef,'LDR',register)
    register=print_operand(enumCountRef,1).split(',')[0].replace('[','');
    enumCountAddr=get_operand_value(SearchPrevASM(enumCountRef,'ADRP',register),1)+get_operand_value(enumCountRef,1)
    enumCount=get_wide_word(enumCountAddr)

    ApplyStructArray(enumAddr,'E10',enumCount)


def ExtractEnum(objectAddr):
    applyUStruct(objectAddr,'E38')
    nameAddr=objectAddr+0x10
    if notFound(idc.get_qword(nameAddr)): 
        Debug('Extracting Enums Fail at 0x%X'%(objectAddr))
        return ''
    objectName=idc.get_strlit_contents(idc.get_qword(nameAddr)).decode()
    Patch(idc.get_qword(nameAddr),'s_'+objectName,nameAddr)
    # parentName=idc.get_name(idc.get_qword(objectAddr))
    fullObjectName='Enum_%s'%(objectName)
    typeName=idc.get_qword(objectAddr+0x18)
    Patch(typeName,'s_'+idc.get_strlit_contents(typeName).decode(),objectAddr+0x18)
    Patch(objectAddr,fullObjectName+'_Class',nameAddr)
    addEmptyLines(objectAddr)
    enumAddr=idc.get_qword(objectAddr+0x20)
    enumCount=ida_bytes.get_wide_dword(objectAddr+0x28)
    ApplyStructArray(enumAddr,'E10',enumCount)
    addPriorComment(enumAddr,fullObjectName+'_List')
    for i in range(enumCount):
        aEnum=enumAddr+i*16
        Patch(idc.get_qword(aEnum),'s_'+idc.get_strlit_contents(idc.get_qword(aEnum)).decode(),aEnum)
    return fullObjectName

def BuildStructures():
    FuncObjects=list(CodeRefsTo(GetScriptAssetBuilder(),0))
    total=len(FuncObjects)
    current=0
    for addr in FuncObjects:
        current+=1
        funcStart=GetFuncStart(addr)
        while (idc.print_insn_mnem(addr)!='ADRL' or print_operand(addr,0)!='X1') and addr>funcStart: addr-=4
        if addr<=funcStart: Debug(hex(addr)+' interrupt at line %d'%getframeinfo(currentframe()).lineno);continue
        objectAddr=get_operand_value(addr,1)
        objectName=ExtractStructObject(objectAddr)
        show('Extracting ScriptFList ( %d / %d ) \n %s'%(current,total,objectName))
        Patch(funcStart,'%s'%objectName,addr)
        addr=SearchPrevASM(GetFuncEnd(funcStart),'MOV','X0')
        if isFound(addr):
            addr=SearchPrevASM(addr,'ADRL',print_operand(addr,1))
            if isFound(addr): Patch(get_operand_value(addr,1),'%s_Pointer'%objectName,addr)

def ExtractStructObject(objectAddr):
    # parentName=idc.get_name(idc.get_qword(objectAddr))
    applyUStruct(objectAddr,'S48')
    objectName=idc.get_strlit_contents(idc.get_qword(objectAddr+0x18)).decode()
    Patch(idc.get_qword(objectAddr+0x18),'s_'+objectName,objectAddr+0x18)
    fullObjectName='Struct_%s'%(objectName)
    Patch(objectAddr,'%s_Class'%fullObjectName,objectAddr+0x18)
    Patch(idc.get_qword(objectAddr+0x10),'%s_Setter'%fullObjectName,objectAddr+0x10)
    addEmptyLines(objectAddr)
    if isPointer(objectAddr+0x30):
        addr=idc.get_qword(objectAddr+0x30)
        count=ida_bytes.get_wide_dword(objectAddr+0x38)
        ExtractUProperty(addr,count,fullObjectName)
        Patch(addr,fullObjectName+'_Properties',objectAddr+0x30)
    return fullObjectName

def BuildMethods():
    MethodObjects=list(CodeRefsTo(GetMethodBuilder(),0))
    total=len(MethodObjects)
    current=0
    for addr in MethodObjects:
        current+=1
        x1=SearchPrevASM(addr,'ADRL','X1')
        if notFound(x1): Debug(hex(addr)+' interrupt at line %d'%getframeinfo(currentframe()).lineno);continue
        objectAddr=get_operand_value(x1,1)
        show('Extracting Methods ( %d / %d ) \n at 0x%X -> 0x%X'%(current,total,x1,objectAddr))
        objectName=ExtractMethodObject(objectAddr)
        show('Extracting Methods ( %d / %d ) \n %s'%(current,total,objectName))
        Patch(GetFuncStart(addr),'%s_Loader'%objectName,addr)
        x0=SearchPrevASM(addr,'MOV','X0')
        if isFound(x0):
            pointerAddr=SearchPrevASM(x0,'ADRL',print_operand(x0,1))
            if isFound(pointerAddr): Patch(get_operand_value(pointerAddr,1),'%s_Pointer'%objectName,pointerAddr)

def ExtractMethodObject(objectAddr):
    applyUStruct(objectAddr,'F48')
    objectName=idc.get_strlit_contents(idc.get_qword(objectAddr+0x10)).decode()
    Patch(idc.get_qword(objectAddr+0x10),'s_'+objectName,objectAddr+0x10)
    parentName=idc.get_name(idc.get_qword(objectAddr)).replace('_Loader','')
    fullObjectName='%s.%s'%(parentName,objectName)
    Patch(objectAddr,fullObjectName+'_Class',objectAddr+0x10)
    addEmptyLines(objectAddr)
    if isPointer(objectAddr+0x30):
        addr=idc.get_qword(objectAddr+0x30)
        count=ida_bytes.get_wide_dword(objectAddr+0x38)
        ExtractUProperty(addr,count,fullObjectName)
        Patch(addr,fullObjectName+'_Arguments',objectAddr+0x30)
    return fullObjectName
  

def BuildUAsset():
    UassetObjects=list(CodeRefsTo(GetUassetBuilder(),0))
    total=len(UassetObjects)
    current=0
    for addr in UassetObjects:
        current+=1
        objectName=ExtractUAsset(addr)
        show('Extracting UAsset ( %d / %d ) \n %s'%(current,total,objectName))

def BuildPackages():
    Packages=list(CodeRefsTo(GetPackageBuilder(),0))
    total=len(Packages)
    current=0
    for addr in Packages:
        current+=1
        oriAddr=addr
        funcStart=GetFuncStart(addr)
        funcEnd=GetFuncEnd(addr)
        testAddr=addr+4
        while (idc.print_insn_mnem(testAddr)!='BL' and idc.print_insn_mnem(testAddr)!='B') and testAddr<=funcEnd: testAddr+=4
        if testAddr<=funcEnd: set_name(funcStart,'');continue
        testAddr=addr-4
        while (idc.print_insn_mnem(testAddr)!='BL' and idc.print_insn_mnem(testAddr)!='B') and testAddr>=funcStart: testAddr-=4
        if testAddr>=funcStart: set_name(funcStart,'');continue
        while (idc.print_insn_mnem(addr)!='ADRL' or print_operand(addr,0)!='X1') and addr>funcStart: addr-=4
        if addr<=funcStart: Debug(hex(addr)+' interrupt at line %d'%getframeinfo(currentframe()).lineno);continue
        objectAddr=get_operand_value(addr,1)
        objectName=ExtractPackage(objectAddr)
        show('Extracting Class Packages ( %d / %d ) \n %s'%(current,total,objectName))
        Patch(funcStart,'%s_Loader'%objectName,objectAddr)
        addr=SearchPrevASM(oriAddr,'MOV','X0')
        if isFound(addr):
            addr=SearchPrevASM(addr,'ADRL',print_operand(addr,1))
            if isFound(addr): Patch(get_operand_value(addr,1),'%s_Pointer'%objectName,addr)

def Explore(name):
    refs=list(XrefsTo(searchUTF16(name)))
    if refs==None:
        warning('UTF16 String %s cannot be found!'%name)
        return
    for ref in refs:
        addr=ref.frm
        if idc.print_insn_mnem(addr)!='ADRL': continue
        register=print_operand(addr,0)
        x2=SearchNextASM(addr,'MOV','X2',register)
        if notFound(x2): continue
        x0=SearchPrevASM(x2,'ADRL','X0')
        if notFound(x0) or x0<addr: continue
        Patch(GetFuncStart(get_operand_value(x0,1)),'%s_Loader'%name,x0)
        ExtractUClass(get_operand_value(x0,1),name)
        return
    warning('UObject %s cannot be found'%name);return

def elfSegment():
    ida_segment.set_segm_name(ida_segment.get_next_seg(ida_segment.get_segm_by_name('.got.plt').start_ea),'.got',0)
    gotAddr=ida_segment.get_segm_by_name('.got').start_ea
    set_segm_class(gotAddr,'CONST')
    set_segm_attr(gotAddr,SEGATTR_PERM,idaapi.SEGPERM_READ)
    ADRLx8=AOB("? ? ? ? 08 ? ? F9 ? ? ? ? ? ? ? ? 29 ? ? F9")
    dynamicStart=idc.get_qword(get_operand_value(ADRLx8,1)+get_operand_value(ADRLx8+4,1))
    dynamicEnd=ida_segment.get_segm_by_name('.got.plt').start_ea
    ida_segment.set_segm_end(dynamicStart,dynamicStart,SEGMOD_KEEP)
    ida_segment.add_segm(base//16, dynamicStart, dynamicEnd, '.dynamic', 'CONST', ida_segment.ADDSEG_NOAA|ida_segment.ADDSEG_QUIET|ida_segment.ADDSEG_SPARSE)
# ida_segment.set_segm_end(0x34AB248,0x34AB248,SEGMOD_KEEP)
# ida_segment.add_segm(base//16, 0x34AB248,0x35632E0, '.dynsym', 'CONST', ida_segment.ADDSEG_NOAA|ida_segment.ADDSEG_QUIET|ida_segment.ADDSEG_SPARSE)
# set_segm_attr(0x34AB248,SEGATTR_BITNESS,2)
# set_segm_attr(0x34AB248,SEGATTR_PERM,idaapi.SEGPERM_READ)

# ida_segment.add_segm(base//16, 0x35632E0,0x3BE3DA8, '.strTAB', 'CONST', ida_segment.ADDSEG_NOAA|ida_segment.ADDSEG_QUIET|ida_segment.ADDSEG_SPARSE)
# set_segm_attr(0x35632E0,SEGATTR_BITNESS,2)
# set_segm_attr(0x35632E0,SEGATTR_PERM,idaapi.SEGPERM_READ)
    set_segm_attr(dynamicStart,SEGATTR_BITNESS,2)
    set_segm_attr(dynamicStart,SEGATTR_PERM,idaapi.SEGPERM_READ|idaapi.SEGPERM_WRITE)
    set_segm_attr(dynamicStart,SEGATTR_ALIGN,saRelQword)
    dynCount=(dynamicEnd-dynamicStart)//0x10
    createStruct('Elf64_Dyn_Link',(('d_tag',ida_bytes.FF_QWORD),('d_un',FF_OFFSET)))
    for i in range(dynCount):
        loc=dynamicStart+i*0x10
        if idc.get_qword(loc) in (3,4,5,6,7,12,13,17,22,23,25,26,32,0x6ffffef5,0x6ffffeff): ApplyStruct(loc,'Elf64_Dyn_Link')

def nsoSegment():
    createStruct('Elf64_Dyn',(('d_tag',ida_bytes.FF_QWORD),('d_un',ida_bytes.FF_QWORD)))
    createStruct('Elf64_Dyn_Link',(('d_tag',ida_bytes.FF_QWORD),('d_un',FF_OFFSET)))
    createStruct('Elf64_Rela',(('r_offset',FF_OFFSET),('r_info',ida_bytes.FF_DWORD),('r_other',ida_bytes.FF_DWORD),('r_addend',FF_OFFSET)))
    createStruct('Elf64_Sym',(('st_name',ida_bytes.FF_DWORD),('st_info',ida_bytes.FF_BYTE),('st_other',ida_bytes.FF_BYTE),('st_shndx',ida_bytes.FF_WORD),('st_value',FF_OFFSET),('st_size',ida_bytes.FF_QWORD)))
    dynamicStart=ida_segment.get_segm_by_name('.dynamic').start_ea
    dynamicEnd=ida_segment.get_segm_by_name('.dynamic').end_ea
    dynCount=(dynamicEnd-dynamicStart)//0x10
    ApplyStructArray(dynamicStart,'Elf64_Dyn',dynCount)
    for i in range(dynCount):
        loc=dynamicStart+i*0x10
        opr=idc.get_qword(loc)
        if opr==0: ApplyComment(loc,'DT_NULL - Marks end of dynamic section')
        elif opr==1: ApplyComment(loc,'DT_NEEDED - Name of needed library')
        elif opr==2: ApplyComment(loc,'DT_PLTRELSZ - Size in bytes of PLT relocs')
        elif opr==3: ApplyComment(loc,'DT_PLTGOT - Processor defined value'); Rebase(loc+8);ApplyStruct(loc,'Elf64_Dyn_Link')
        elif opr==4: ApplyComment(loc,'DT_HASH - Address of symbol hash table'); Rebase(loc+8);ApplyStruct(loc,'Elf64_Dyn_Link')
        elif opr==5: ApplyComment(loc,'DT_STRTAB - Address of string table'); Rebase(loc+8);ApplyStruct(loc,'Elf64_Dyn_Link')
        elif opr==6: ApplyComment(loc,'DT_SYMTAB - Address of symbol table'); Rebase(loc+8);ApplyStruct(loc,'Elf64_Dyn_Link')
        elif opr==7: ApplyComment(loc,'DT_RELA - Address of Rela relocs'); Rebase(loc+8);ApplyStruct(loc,'Elf64_Dyn_Link')
        elif opr==8: ApplyComment(loc,'DT_RELASZ - Total size of Rela relocs')
        elif opr==9: ApplyComment(loc,'DT_RELAENT - Size of one Rela reloc')
        elif opr==10: ApplyComment(loc,'DT_STRSZ - Size of string table')
        elif opr==11: ApplyComment(loc,'DT_SYMENT - Size of one symbol table entry')
        elif opr==12: ApplyComment(loc,'DT_INIT - Address of init function'); Rebase(loc+8);ApplyStruct(loc,'Elf64_Dyn_Link')
        elif opr==13: ApplyComment(loc,'DT_FINI - Address of termination function'); Rebase(loc+8);ApplyStruct(loc,'Elf64_Dyn_Link')
        elif opr==14: ApplyComment(loc,'DT_SONAME - Name of shared object')
        elif opr==15: ApplyComment(loc,'DT_RPATH - Library search path (deprecated)')
        elif opr==16: ApplyComment(loc,'DT_SYMBOLIC - Start symbol search here')
        elif opr==17: ApplyComment(loc,'DT_REL - Address of Rel relocs'); Rebase(loc+8);ApplyStruct(loc,'Elf64_Dyn_Link')
        elif opr==18: ApplyComment(loc,'DT_RELSZ - Total size of Rel relocs')
        elif opr==19: ApplyComment(loc,'DT_RELENT - Size of one Rel reloc')
        elif opr==20: ApplyComment(loc,'DT_PLTREL - Type of reloc in PLT')
        elif opr==21: ApplyComment(loc,'DT_Debug - For Debugging; unspecified')
        elif opr==22: ApplyComment(loc,'DT_TEXTREL - Reloc might modify .text'); Rebase(loc+8);ApplyStruct(loc,'Elf64_Dyn_Link')
        elif opr==23: ApplyComment(loc,'DT_JMPREL - Address of PLT relocs'); Rebase(loc+8);ApplyStruct(loc,'Elf64_Dyn_Link')
        elif opr==24: ApplyComment(loc,'DT_BIND_NOW - Process relocations of object')
        elif opr==25: ApplyComment(loc,'DT_INIT_ARRAY - Array with addresses of init fct'); Rebase(loc+8);ApplyStruct(loc,'Elf64_Dyn_Link')
        elif opr==26: ApplyComment(loc,'DT_FINI_ARRAY - Array with addresses of fini fct'); Rebase(loc+8);ApplyStruct(loc,'Elf64_Dyn_Link')
        elif opr==27: ApplyComment(loc,'DT_INIT_ARRAYSZ - Size in bytes of DT_INIT_ARRAY')
        elif opr==28: ApplyComment(loc,'DT_FINI_ARRAYSZ - Size in bytes of DT_FINI_ARRAY')
        elif opr==29: ApplyComment(loc,'DT_RUNPATH - Library search path')
        elif opr==30: ApplyComment(loc,'DT_FLAGS - Flags for the object being loaded')
        elif opr==31: ApplyComment(loc,'DT_ENCODING - Start of encoded range')
        elif opr==32: ApplyComment(loc,'DT_PREINIT_ARRAY - Array with addresses of preinit fct'); Rebase(loc+8);ApplyStruct(loc,'Elf64_Dyn_Link')
        elif opr==33: ApplyComment(loc,'DT_PREINIT_ARRAYSZ - size in bytes of DT_PREINIT_ARRAY')
        elif opr==34: ApplyComment(loc,'DT_NUM - Number used')
        elif opr==0x6000000d: ApplyComment(loc,'DT_LOOS - Start of OS-specific')
        elif opr==0x6ffff000: ApplyComment(loc,'DT_HIOS - End of OS-specific ')
        elif opr==0x70000000: ApplyComment(loc,'DT_LOPROC - Start of processor-specific')
        elif opr==0x7fffffff: ApplyComment(loc,'DT_HIPROC - End of processor-specific')
        elif opr==0x6ffffe00: ApplyComment(loc,'DT_ADDRRNGLO')
        elif opr==0x6ffffef5: ApplyComment(loc,'DT_GNU_HASH - GNU-style hash table.'); Rebase(loc+8);ApplyStruct(loc,'Elf64_Dyn_Link')
        elif opr==0x6ffffef6: ApplyComment(loc,'DT_TLSDESC_PLT')
        elif opr==0x6ffffef7: ApplyComment(loc,'DT_TLSDESC_GOT')
        elif opr==0x6ffffef8: ApplyComment(loc,'DT_GNU_CONFLICT - Start of conflict section')
        elif opr==0x6ffffef9: ApplyComment(loc,'DT_GNU_LIBLIST - Library list')
        elif opr==0x6ffffefa: ApplyComment(loc,'DT_CONFIG - Configuration information.')
        elif opr==0x6ffffefb: ApplyComment(loc,'DT_DEPAUDIT - Dependency auditing.')
        elif opr==0x6ffffefc: ApplyComment(loc,'DT_AUDIT - Object auditing.')
        elif opr==0x6ffffefd: ApplyComment(loc,'DT_PLTPAD - PLT padding.')
        elif opr==0x6ffffefe: ApplyComment(loc,'DT_MOVETAB - Move table.')
        elif opr==0x6ffffeff: ApplyComment(loc,'DT_SYMINFO - Syminfo table.'); Rebase(loc+8);ApplyStruct(loc,'Elf64_Dyn_Link')
        elif opr==0x6ffffeff: ApplyComment(loc,'DT_ADDRRNGHI')
        elif opr==0x6ffffff9: ApplyComment(loc,'DT_RELACOUNT - Number of Rela relocs')
        elif opr==0x6ffffffa: ApplyComment(loc,'DT_RELCOUNT')
        elif opr==0x6ffffffb: ApplyComment(loc,'DT_FLAGS_1')
        elif opr==0x6ffffffc: ApplyComment(loc,'DT_VERDEF')
        elif opr==0x6ffffffd: ApplyComment(loc,'DT_VERDEFNUM')

def analysisRELA():
    if notFound(DT_RELACOUNT) or notFound(DT_RELA) or notFound(DT_PLTRELSZ) or notFound(DT_JMPREL): return
    if ida_kernwin.ask_yn(False, 'HIDECANCEL\nConstruct the Rela relocs Table? %d elements\n(Need a long time!)'%DT_RELACOUNT)==1:
        ApplyStructArray(DT_RELA,'Elf64_Rela',DT_RELACOUNT)
        ApplyStructArray(DT_JMPREL,'Elf64_Rela',DT_PLTRELSZ//0x18)
    if ida_kernwin.ask_yn(False, 'HIDECANCEL\nMake Function by the Rela relocs Table? %d elements\n(May need more than 1 hour!)'%DT_RELACOUNT)==1:
        for i in range(DT_RELACOUNT):
            Rebase(DT_RELA+i*0x18)
            Rebase(DT_RELA+i*0x18+0x10)
            funcAddr=idc.get_qword(DT_RELA+i*0x18+0x10)
            if idaapi.get_func(funcAddr)==None:
                show('Make Function at 0x%X ( %d / %d )'%(funcAddr,i,DT_RELACOUNT))
                ida_funcs.add_func(funcAddr)
        ida_kernwin.hide_wait_box()

def ExtractProperty(propertyAddr,indent='',baseOffset=0):
    extraInfo=''
    propertyName=idc.get_strlit_contents(idc.get_qword(propertyAddr)).decode()
    typeID=ida_bytes.get_wide_dword(propertyAddr+0x18)
    propertyOffset=ida_bytes.get_wide_dword(propertyAddr+0x24)
    # Debug(hex(propertyAddr),propertyName,typeID,hex(propertyOffset))
    if typeID==0:
        propertyType='Byte'
    elif typeID==0x3:
        propertyType='Bool'
    elif typeID==0x5:
        propertyType='Int16'
    elif typeID==0x6:
        propertyType='Int32'
    elif typeID==0xA:
        propertyType='Float'
    elif typeID==0xB:
        propertyType='Double'
    elif typeID==0xC:
        setterAddr=idc.get_qword(propertyAddr+0x30)
        if idc.print_insn_mnem(setterAddr)=='ADD':
            propertyOffset=get_operand_value(setterAddr,2)
            bit=get_operand_value(setterAddr+8,2)
        else:
            propertyOffset=get_operand_value(setterAddr,1)
            if get_operand_value(setterAddr+4,2)>0:
                bit=get_operand_value(setterAddr+4,2)
            else:
                bit=get_operand_value(setterAddr+0x10,2)//0x100000000
                propertyOffset+=4
        while bit>=256:
            propertyOffset+=1
            bit=bit//256
        propertyType='bool^%d'%int(math.log2(bit)) if bit>0 else 'unknown %s'%bit        
    elif typeID==0xE:
        propertyType='Component'
    elif typeID==0x11:
        propertyType='Class'
    elif typeID==0x12:
        propertyType='Object'
        extraInfo='Class:%s'%idc.get_name(idc.get_qword(propertyAddr+0x28)).replace('_Loader','').replace('_0','').replace('_1','').replace('_2','').replace('_3','')
    elif typeID==0x14:
        propertyType='Name'
    elif typeID==0x15:
        propertyType='String'
    elif typeID==0x16:
        propertyType='Array'
        extraInfo='Class:%s'%idc.get_name(idc.get_qword(propertyAddr+0x28)).replace('_Loader','').replace('_0','').replace('_1','').replace('_2','').replace('_3','')
    elif typeID==0x17:
        propertyType='List'
    elif typeID==0x18:
        propertyType='Set'
    elif typeID==0x19:
        propertyType='Struct'
        structName=idc.get_name(idc.get_qword(propertyAddr+0x28)).replace('Struct_','').replace('_Loader','').replace('_0','').replace('_1','').replace('_2','').replace('_3','')
        extraInfo='Struct: %s'%structName
        structClass=idc.get_name_ea(dataStart,'Struct_%s_Class'%structName)
        propertiesAddr=idc.get_qword(structClass+0x30)
        propertiesCount=ida_bytes.get_wide_dword(structClass+0x38)
        for i in reversed(range(propertiesCount)) if reverseSDK else range(propertiesCount):
            argAddr=idc.get_qword(propertiesAddr+i*8)
            (argName,argType,argOffset,argExtraInfo)=ExtractProperty(argAddr,indent+'    ',baseOffset+propertyOffset)
            if propertyOffset==0: #StructArray
                # propertyOffset=ida_bytes.get_wide_dword(propertyAddr-0xC)
                extraInfo+='\n     \t%s+%02X: %s \t%s (%X)\t%s'%(indent,argOffset,argType,argName,argAddr,argExtraInfo)
            else:
                extraInfo+='\n     \t%s+%02X(%X): %s \t%s (%X)\t%s'%(indent,argOffset,baseOffset+propertyOffset+argOffset,argType,argName,argAddr,argExtraInfo)
    elif typeID==0x1B:
        propertyType='M.Delegate'
    elif typeID==0x1C:
        propertyType='Event'
    elif typeID==0x1D:
        propertyType='Vector'
    elif typeID==0x1E:
        propertyType='Enum'
        enumName=idc.get_name(idc.get_qword(propertyAddr+0x28))
        enumClass=idc.get_name_ea(dataStart,enumName.replace('_Loader','')+'_Class')
        if enumName[:4]=='sub_' or notFound(enumClass): 
            loaderAddr=idc.get_qword(propertyAddr+0x28)
            x1=SearchNextASM(loaderAddr,'ADRL','X1')
            enumClass=get_operand_value(x1,1)
            enumName=ExtractEnum(enumClass)
            Patch(loaderAddr,'%s_Loader'%enumName,propertyAddr+0x28)
            x0=SearchPrevASM(GetFuncEnd(loaderAddr),'MOV','X0')
            if isFound(x0):
                pointerAddr=SearchPrevASM(x0,'ADRL',print_operand(x0,1))
                if isFound(pointerAddr): Patch(get_operand_value(pointerAddr,1),'%s_Pointer'%enumName,pointerAddr)
                refs=XrefsTo(loaderAddr,0)
                for jumpAddr in refs:
                    if isFunc(jumpAddr.frm):
                        Patch(GetFuncStart(jumpAddr),'pre_'+enumName,loaderAddr)
        enumAddr=idc.get_qword(enumClass+0x20)
        enumCount=ida_bytes.get_wide_dword(enumClass+0x28)
        extraInfo='\n'+'\n'.join(indent+'\t\t%2d: %s'%(idc.get_qword(enumAddr+i*16+8),idc.get_strlit_contents(idc.get_qword(enumAddr+i*16)).decode()) for i in range(enumCount))
    elif typeID==0x2C:
        propertyType='bool'
        setterAddr=idc.get_qword(propertyAddr+0x30)
        propertyOffset=get_operand_value(setterAddr+4,1)
    else:
        propertyType=hex(typeID)
    return (propertyName,propertyType,propertyOffset,extraInfo)

def ExtractFunction(funcAddr,parentName):
    funcName=idc.get_strlit_contents(idc.get_qword(funcAddr+0x10)).decode()
    fullFuncName='%s.%s'%(parentName,funcName)
    ArgsCount=ida_bytes.get_wide_dword(funcAddr+0x38)
    ArgsAddr=ida_bytes.get_wide_dword(funcAddr+0x30)
    buffer=lastInfo=lastType=''
    for i in range(ArgsCount):
        argAddr=idc.get_qword(ArgsAddr+i*8)
        (argName,argType,argOffset,extraInfo)=ExtractProperty(argAddr)
        if argName=='UnderlyingType': continue
        if argType in ('Array','Set'): 
            argType=lastType+argType
            extraInfo=lastInfo
        else:
            msg(buffer)
        lastType=argType
        lastInfo=extraInfo
        buffer='%+8X%12s\t%s.%s (%X) %s\n'%(argOffset,argType,fullFuncName,argName,argAddr,extraInfo)
    msg(buffer)
    
def ExploreScript(funcAddr,fullFuncName):
    ArgsCount=ida_bytes.get_wide_dword(funcAddr+0x38)
    ArgsAddr=ida_bytes.get_wide_dword(funcAddr+0x30)
    buffer=lastInfo=lastType=''
    for i in range(ArgsCount):
        argAddr=idc.get_qword(ArgsAddr+i*8)
        (argName,argType,argOffset,extraInfo)=ExtractProperty(argAddr)
        if argName=='UnderlyingType': continue
        if argType in ('Array','Set'): 
            argType=lastType+argType
            extraInfo=lastInfo
        else:
            msg(buffer)
        lastType=argType
        lastInfo=extraInfo
        buffer='%+8X%12s\t%s.%s (%X) %s\n'%(argOffset,argType,fullFuncName,argName,argAddr,extraInfo)
    msg(buffer)

def sdk(classname='AActor',listFunc=False,listChildren=True ):
    cls();
    classAddr=idc.get_name_ea(dataStart,classname+'_Class')
    if notFound(classAddr):
        Explore(classname)
        classAddr=idc.get_name_ea(dataStart,classname+'_Class')
        if notFound(classAddr):
            warning('%s not found'%classname)
            return
    # jumpto(classAddr)
    parentCount=ida_bytes.get_wide_dword(classAddr+0x38)
    parentAddr=idc.get_name_ea(dataStart,classname+'_Parents')
    fullclassname=classname
    closeparent=None
    for i in range(parentCount):
        parentName=idc.get_name(idc.get_qword(parentAddr+i*8)).replace('_Loader','')
        if closeparent is None: closeparent=parentName
        fullclassname=parentName+'.'+fullclassname
    if closeparent is not None and closeparent not in ('UObject','UEngine','UClass'): sdk(closeparent,listFunc,False)
    print('\t\t%s (%X)'%(fullclassname,classAddr))

    buffer=lastInfo=lastType=''
    propertiesCount=ida_bytes.get_wide_dword(classAddr+0x40)
    propertiesAddr=idc.get_name_ea(dataStart,classname+'_Properties')
    for i in reversed(range(propertiesCount)) if reverseSDK else range(propertiesCount):
        propertyAddr=idc.get_qword(propertiesAddr+i*8)
        (propertyName,propertyType,propertyOffset,extraInfo)=ExtractProperty(propertyAddr)
        if propertyName=='UnderlyingType': continue
        if propertyType in ('Array','Set','List'): 
            propertyType=lastType+propertyType
            extraInfo=lastInfo
        # elif propertyType in ('Struct'): 
            # extraInfo='
        else:
            msg(buffer)
        lastType=propertyType
        lastInfo=extraInfo
        buffer='%+8X%12s\t%s.%s (%X) %s\n'%(propertyOffset,propertyType,classname,propertyName,propertyAddr,extraInfo)
    msg(buffer)
    if listFunc:
        methodsCount=ida_bytes.get_wide_dword(classAddr+0x3C)
        methodsAddr=idc.get_name_ea(codeStart,classname+'_Methods')
        for i in range(methodsCount):
            methodName=idc.get_strlit_contents(idc.get_qword(methodsAddr+i*16+8)).decode()
            methodAddr=idc.get_name_ea(codeStart,'%s.%s_Class'%(classname,methodName))
            funcAddr=idc.get_name_ea(codeStart,'%s.%s'%(classname,methodName)) & 0xFFFFFFFF
            # memoryAddr=idc.get_name(methodName+'_Pointer')
            pointerAddr=BADADDR
            addr=SearchPrevASM(GetFuncEnd(idc.get_qword(methodsAddr+i*16)),'MOV','X0')
            if isFound(addr):
                addr=SearchPrevASM(addr,'ADRL',print_operand(addr,1))
                if isFound(addr): pointerAddr=get_operand_value(addr,1)
            msg('%08X%12s\t%s.%s (%X) #%X\n'%(funcAddr,'function',classname,methodName,pointerAddr,methodAddr))
            ExtractFunction(methodAddr,classname)
        FListCount=ida_bytes.get_wide_dword(classAddr+0x44)
    print()
    if listChildren: msg('Children of %s: '%classname);FindChildren(classname)

def FindChildren(classname='AActor'):
    classAddr=idc.get_name_ea(dataStart,classname+'_Loader')
    xrefs=list(XrefsTo(classAddr))
    if notFound(classAddr):
        Explore(classname)
        classAddr=idc.get_name_ea(dataStart,classname)
        if notFound(classAddr):
            warning('%s not found'%classname)
            return
    results=[]
    for ref in xrefs:
        if not(dataStart<ref.frm<dataEnd): continue
        FindChildrenName=idc.get_name(ref.frm)
        if not('_Parents' in FindChildrenName): continue
        results.append(FindChildrenName.replace('_Parents',''))
    print(', '.join(results))
    
def GetFuncName(name):
    assetsAddr=idc.get_name_ea(codeStart,'%s_Assets'%name)
    loaderAddr=idc.get_name_ea(codeStart,'%s_FList_Loader'%name)
    if notFound(loaderAddr): loaderAddr=idc.get_name_ea(codeStart,'%s_Constructor'%name)
    p(loaderAddr)
    x8=AOB('? ? ? ? ? ? ? 91 FD 7B 44 A9 E2 00 80 52 FF ? ? 91',loaderAddr,GetFuncEnd(loaderAddr))
    if isFound(x8):
        fListAddr=get_operand_value(x8,1)
    else:
        x10=AOB('? ? ? 34 ? ? ? ? ? ? ? 91 6A ? ? F9 ? 00 80 52 ? ? ? ? ? ? ? 91',loaderAddr,GetFuncEnd(loaderAddr))
        if isFound(x10):
            offset=get_operand_value(x10+0xC,1)
            x19=AOB('? ? ? ? ? ? ? 91 A0 ? ? F9 E0 03 13 AA ? ? ? 94',loaderAddr,GetFuncEnd(loaderAddr))
            fListAddr=get_operand_value(x19,1)+offset
        else:
            x8=AOB('? ? ? ? ? ? ? 91 1F A1 00 39 0B ? ? 52',loaderAddr,GetFuncEnd(loaderAddr))
            if isFound(x8):
                r=print_operand(x8,0)
                stp=SearchNextASM(x8,'STP',None,None,r)
                fListAddr=get_operand_value(stp,2)+get_operand_value(x8,1)
            else:
                x8=AOB('? ? ? ? ? ? ? 91 A0 0F 00 F9 E0 03 13 AA ? ? ? 94',loaderAddr,GetFuncEnd(loaderAddr))
                r=print_operand(x8,0)
                str=SearchNextASM(x8,'STR',None,r)
                fListAddr=get_operand_value(str,1)+get_operand_value(x8,1)
    p("extractUFuncList(0x%X,'%s',0x%X)"%(fListAddr,name,assetsAddr))
def extractUFuncList(addr,name,flist=None):
    print()
    addr=base+addr
    while idc.get_qword(addr)!=0 and idc.get_qword(addr+8)!=0 and idc.get_qword(addr+0x30) in (2,3):  
        methodName='%s.%s'%(name,GetASCstr(idc.get_qword(addr)))
        ApplyComment(addr,methodName)
        ApplyStruct(addr,'FuncMap')
        jfuncAddr=idc.get_qword(addr+8)
        AddFunc(jfuncAddr)
        Patch(jfuncAddr,'j_%s'%methodName,addr)
        if idc.get_qword(addr+0x18)==0:
            funcAddr=idc.get_qword(addr+0x10)
            AddFunc(funcAddr)
            Patch(funcAddr,methodName,addr)
        else:
            if flist!=None:
                funcAddr=idc.get_qword(base+flist+idc.get_qword(addr+0x10))
                AddFunc(funcAddr)
                Patch(funcAddr,methodName,addr)
        addr+=0x38
        
ReBuildStruct=None

cls()
show('Analysis begins')

if not gdb:
    if ida_segment.get_segm_by_name('.dynamic') is None:
        elfSegment()
    else:
        nsoSegment()

    dynamicStart=ida_segment.get_segm_by_name('.dynamic').start_ea
    dynamicEnd=ida_segment.get_segm_by_name('.dynamic').end_ea
    dynCount=(dynamicEnd-dynamicStart)//0x10
    DT_RELACOUNT=DT_RELA=DT_RELASZ=DT_JMPREL=DT_PLTRELSZ=DT_STRTAB=DT_STRSZ=BADADDR
    for i in range(dynCount): 
        loc=dynamicStart+i*0x10
        opr=idc.get_qword(loc)
        if opr==5: DT_STRTAB=idc.get_qword(loc+8)
        if opr==10: DT_STRSZ=idc.get_qword(loc+8)
        if opr==2: DT_PLTRELSZ=idc.get_qword(loc+8)
        elif opr==7: DT_RELA=idc.get_qword(loc+8)
        elif opr==8: DT_RELASZ=idc.get_qword(loc+8)
        elif opr==23: DT_JMPREL=idc.get_qword(loc+8)
        elif opr==0x6ffffff9: DT_RELACOUNT=idc.get_qword(loc+8)
    AsciiSTRstart=dataStart if notFound(DT_STRTAB) else DT_STRTAB
    AsciiSTRend1=dynamicStart if notFound(DT_STRTAB) or notFound(DT_STRSZ) else DT_STRTAB+DT_STRSZ
    AsciiSTRend=dynamicStart
    RELAstart=DT_RELA
    RELAend=DT_RELA+DT_RELASZ
    GOTstart=ida_segment.get_segm_by_name('.got').start_ea
    GOTend=ida_segment.get_segm_by_name('.got').end_ea
    UTF16start=ida_search.find_binary(dataStart, GOTstart, '55 00 54 00 46 00 38 00 4F 00 75 00 74 00 70 00', 0, idc.SEARCH_DOWN)
    UTF16end=ida_search.find_binary(UTF16start, GOTstart, '3C 00 53 00 63 00 61 00 6C 00 65 00 3E 00 00 00', 0, idc.SEARCH_DOWN)+0x10

    if ida_kernwin.ask_yn(False, 'HIDECANCEL\nFix the Strings\nrun once only')==1:
        if dataStart<UTF16start<dataEnd and dataStart<UTF16end<dataEnd: fixUTF16() # run once only
        if dataStart<AsciiSTRstart<dataEnd and dataStart<AsciiSTRend<dataEnd: fixAscString() # run once only

#analysisRELA()


    if not(isDebug):
        print('import idc, ida_segment, ida_bytes')
        print('FF_OFFSET=ida_bytes.FF_QWORD|FF_DATA|ida_bytes.off_flag();FF_DEC=ida_bytes.FF_DWORD|FF_DATA|ida_bytes.dec_flag()')
        print("codeStart=ida_segment.get_segm_by_name('.text' if ida_segment.get_segm_by_name('main')==None else 'main').start_ea")
        print("codeEnd=ida_segment.get_segm_by_name('.text' if ida_segment.get_segm_by_name('main')==None else 'main').end_ea")
        print("dataStart=ida_segment.get_segm_by_name('.data' if ida_segment.get_segm_by_name('main_data')==None else 'main_data').start_ea")
        print("dataEnd=ida_segment.get_segm_by_name('.data' if ida_segment.get_segm_by_name('main_data')==None else 'main_data').end_ea")
        print('def p(x): print(hex(x) if isinstance(x, int) else x)')
        print('def Patch(targetAddr,newName,ref): targetAddr+=codeStart;set_name(targetAddr, newName, 0x3901)')
        print()

    if UTF16start == BADADDR or UTF16end == BADADDR:
        warning('This nso/elf is not supported!')
    else:
        createStructs()
        if ida_kernwin.ask_yn(True, 'HIDECANCEL\nStart Building GObjects and GName?'):
            BuildPackages()
            BuildUObjects()
            BuildEnums()
            BuildMethods()
            BuildStructures()
            BuildUAsset()
            print()
            warning('Done')
        # else:
            # cls()
            # UEngine.UActorComponent.UMovementComponent.UNavMovementComponent.UPawnMovementComponent.UCharacterMovementComponent
            # sdk('UEngine')
            # sdk('UActorComponent')
            # sdk('UMovementComponent')
            # sdk('UNavMovementComponent')
            # sdk('UPawnMovementComponent')
            # sdk('UCharacterMovementComponent')
            # UEngine.UObject.AActor.APawn.ACharacter.APaperCharacter
            # print('\n\n ================================================================ \n\n')
            # sdk('AActor')
            # sdk('APawn')
            # sdk('ACharacter')
            # sdk('APaperCharacter')
            # print('\n\n ================================================================ \n\n')
            # sdk('AActor')
            # sdk('AController')
            # sdk('APlayerController')
            # print('\n\n ================================================================ \n\n')
            # sdk('AActor')
            # sdk('AController')
            # sdk('AAIController')
            # print('\n\n ================================================================ \n\n')
            # sdk('AActor')
            # sdk('AInfo')
            # sdk('AGameModebase')
            # sdk('AGameMode')
            # sdk('AARSharedWorldGameMode')
            # print('\n\n')

else:
    createStructs()
    
'''

def GetFuncName(name):
    assetsAddr=idc.get_name_ea(codeStart,'UAsset_%s_Assets'%name)
    loaderAddr=idc.get_name_ea(codeStart,'UAsset_%s_FList_Loader'%name)
    p(assetsAddr)
    p(loaderAddr)
    
def extractUFuncList(addr,name,flist=None):
    addr=base+addr
    while idc.get_qword(addr)!=0 and idc.get_qword(addr+8)!=0 and idc.get_qword(addr+0x30) in (2,3):  
        methodName='%s.%s'%(name,GetASCstr(idc.get_qword(addr)))
        ApplyComment(addr,methodName)
        ApplyStruct(addr,'FuncMap')
        jfuncAddr=idc.get_qword(addr+8)
        AddFunc(jfuncAddr)
        Patch(jfuncAddr,'j_%s'%methodName,addr)
        if idc.get_qword(addr+0x18)==0:
            funcAddr=idc.get_qword(addr+0x10)
            AddFunc(funcAddr)
            Patch(funcAddr,methodName,addr)
        else:
            if flist!=None:
                funcAddr=idc.get_qword(base+flist+idc.get_qword(addr+0x10))
                AddFunc(funcAddr)
                Patch(funcAddr,methodName,addr)
        addr+=0x38

cls()

extractUFuncList(0x609EF18,'AMIAPlayerbase',0x58B7480)

extractUFuncList(0x6050530,'UMIACharacterStatus',0x58EE420)

extractUFuncList(0x603F648,'UMIABagInterface',0x58EDAD8)

extractUFuncList(0x6D9CC80,'UPrimitiveComponent',0x5DC2540)

extractUFuncList(0x6062138,'UMIAGameInstance',0x58C24E0)

extractUFuncList(0x60AD018,'MIASingletonObject',0x58C5240)

extractUFuncList(0x6065A18,'UMIAGameplayTagsNotify',0x58bbb60)

extractUFuncList(0x6055FC8,'UMIADatabaseFunctionLibrary',0x58c89d8)

extractUFuncList(0x60276C0,'ULibDebug',0x58FFEF0)
'''