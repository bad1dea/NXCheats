# This Script is Programmed by Eiffel2018
# Works in IDA PRO v7.5+
# Requirement: Python 3.9.x (with idapyswitch) and Keystone 
#
# This script perform in with NSO that was fully analysed
# (i.e. Before run this script, you need to wait painfully until the IDA shows IDLE at the bottom status bar )
#
# The script will rename the functions with proper name.
# It will also generate another script on the View of Output Window 
# You can copy it and run the generated script in another IDA that connected to GBD Debugger and defined sections
#
# Note: the analysis may wrong, and it may damage your .i64 file.
# So, better making a save before using this script!
#
#
if 'GetBase' in dir(): ClearCache('uEngine');ClearCache('cheatLib');ClearCache('idahelper')


isDebug = True
reverseSDK=False

import idc, ida_bytes, ida_search, ida_struct, idautils, sys, ida_kernwin, ida_funcs, idaapi, ida_segment, math, pathlib, ida_auto
from inspect import currentframe, getframeinfo

from idahelper import *

if sys.hexversion < 0x03090000:
    raise ImportError("This script is tested on Python 3.9.x only\nCurrently, your python version is " + sys.version)

# isGDB() = ida_segment.get_segm_by_name('main') != None

FF_OFFSET=0x30500400 #ida_bytes.FF_QWORD|FF_DATA|ida_bytes.off_flag()
FF_4BIT=ida_bytes.FF_DWORD|ida_bytes.FF_DATA|ida_bytes.dec_flag()
FF_8BIT=ida_bytes.FF_QWORD|ida_bytes.FF_DATA|ida_bytes.dec_flag()

def FindAESKey():
    func=AOB('00 04 00 AD C0 03 5F D6')
    while isFound(func):
        addr2=SearchPrevASM(func,'ADRP','X8')
        addr1=SearchPrevASM(addr2-4,'ADRP','X8')
        if notFound(addr1) or notFound(addr2) or inWriteableMemory(GetADRP(addr1)) or inWriteableMemory(GetADRP(addr2)): 
            func=AOB('00 04 00 AD C0 03 5F D6',func+4)
            continue
        print(''.join('%02X'%ida_bytes.get_wide_byte(GetADRP(addr1)+i) for i in range(16)) + ''.join('%02X'%ida_bytes.get_wide_byte(GetADRP(addr2)+i) for i in range(16)))
        return
    print('Pattern Not found!')
# def FindAESKey():
    # func=AOB('? ? ? ? ? ? ? ? 00 ? ? 3D 21 ? ? 3D 00 04 00 AD C0 03 5F D6')
    # if notFound(func): return BADADDR
    # firstAddr=idc.get_operand_value(func,1)+idc.get_operand_value(func+8,1)
    # secondAddr=idc.get_operand_value(func+4,1)+idc.get_operand_value(func+12,1)
    # return ''.join('%02X'%ida_bytes.get_wide_byte(firstAddr+i) for i in range(16)) + ''.join('%02X'%ida_bytes.get_wide_byte(secondAddr+i) for i in range(16))

def Patch(targetAddr,newName,ref=BADADDR):
    if isGDB() and targetAddr<base: targetAddr+=base
    if not isGDB() and inCodeRange(targetAddr): 
        AddFunc(targetAddr)
    if isFound(ref):
        Debug('Patch(0x%X, \'%s\', 0x%X)' % (targetAddr,newName,ref))
    else:
        Debug('Patch(0x%X, \'%s\')' % (targetAddr,newName))
    idc.set_name(idc.get_name_ea(codeStart,newName),'')
    idc.set_name(targetAddr, newName, (0x3901 if targetAddr<=codeEnd else 0x3981))

def ApplyStruct(targetAddr,name):
    if targetAddr>base and base>0: targetAddr-=base
    sid=ida_struct.get_struc_id(name)
    size=ida_struct.get_struc_size(sid)
    ida_bytes.create_struct(targetAddr+base, size, ida_struct.get_struc_id(name),True)
def ApplyUStruct(targetAddr,name):
    if targetAddr>base and base>0: targetAddr-=base
    Debug('ApplyStruct('+hex(targetAddr)+',\''+name+'\')')
    ApplyStruct(targetAddr+base,name)
def ApplyArray(targetAddr,size):
    if targetAddr>base and base>0: targetAddr-=base
    ida_bytes.del_items(targetAddr+base)
    idc.op_plain_offset(targetAddr+base, 0, 0)
    Debug('ApplyArray(0x%X,%d)' % (targetAddr,size))
    idc.make_array(targetAddr+base,size)
def ApplyStructArray(targetAddr,name,n):
    if targetAddr>base and base>0: targetAddr-=base
    sid=ida_struct.get_struc_id(name)
    size=ida_struct.get_struc_size(sid)
    for i in range(n): ApplyStruct(targetAddr+base+size*i,name)

def searchUTF16(name):
    pattern='00 00 '+' '.join('{:02X}'.format(x) for x in name.encode('utf-16le'))+' 00 00'
    for i in ((UTF16start, UTF16end, pattern, 0, idc.SEARCH_DOWN)): p(i)
    result=ida_search.find_binary(UTF16start, UTF16end, pattern, 0, idc.SEARCH_DOWN)
    return result+2 if isFound(result) else BADADDR
def searchAscii(name):
    pattern='00 '+' '.join('{:02X}'.format(x) for x in name.encode('utf-8'))+' 00'
    result=ida_search.find_binary(AsciiSTRstart, AsciiSTRend, pattern, 0, idc.SEARCH_DOWN)
    return result+1 if isFound(result) else BADADDR
def searchDataRef(targetAddr):
    dataSeg=ida_segment.get_segm_by_name('.data')
    return ida_search.find_binary(dataSeg.start_ea, dataSeg.end_ea, '%X'%targetAddr, 0, idc.SEARCH_DOWN)

def fixUTF16(isManual=True):
    if not isManual and ReBuildStruct==False: return 
    addr=UTF16start
    while addr<UTF16end:
        end=ida_search.find_binary(addr, UTF16end, '0 0 0', 0, idc.SEARCH_DOWN)
        if notFound(end) or addr>=UTF16end:break
        length=end-addr+3
        ida_bytes.del_items(addr,0,length)
        ida_bytes.create_strlit(addr, length, 0x2000001)
        Show(idc.get_strlit_contents(addr,length,STRTYPE_C_16).decode())
        addr+=length
        while get_wide_word(addr)==0: addr+=2
def fixUTF32(addr):
    while ida_bytes.has_xref(ida_bytes.get_full_flags(addr)) and GetQword(addr)&0xFFFF0000==0:
        end=addr+4
        while not(ida_bytes.has_xref(ida_bytes.get_full_flags(end))) and GetQword(end)&0xFFFF0000==0:end+=4
        assert ida_bytes.has_xref(ida_bytes.get_full_flags(end))
        length=end-addr
        ida_bytes.del_items(addr,0,length)
        ida_bytes.create_strlit(addr, length, STRTYPE_C_32)
        Show(idc.get_strlit_contents(addr,length,STRTYPE_C_32).decode())
        addr+=length
        while get_wide_word(addr)==0: addr+=4
def fixSTR():
    addr=get_screen_ea()
    segend=ida_segment.Getseg(addr).end_ea
    while (ida_bytes.has_xref(ida_bytes.get_full_flags(addr)) or get_wide_byte(addr-1)==0) and get_wide_byte(addr)!=0 and addr<segend:
        end=addr+1
        while not(ida_bytes.has_xref(ida_bytes.get_full_flags(end))) and get_wide_byte(end-1)!=0:end+=1
        length=end-addr
        if length<2 or end>segend:break
        ida_bytes.del_items(addr,0,length)
        ida_bytes.create_strlit(addr, length,STRTYPE_C)
        Show(idc.get_strlit_contents(addr,length).decode())
        addr+=length
# def fixAscString(isManual=True):
    # if not isManual and ReBuildStruct==False: return 
    # addr=AsciiSTRstart+1
    # while addr<AsciiSTRend:
        # end=ida_search.find_binary(addr, AsciiSTRend, '0', 0, idc.SEARCH_DOWN)
        # if notFound(end) or addr>=AsciiSTRend:break
        # length=end-addr+1
        # ida_bytes.del_items(addr,0,length)
        # ida_bytes.create_strlit(addr, length, STRTYPE_C)
        # Show(idc.get_strlit_contents(addr).decode())
        # addr+=length
        # while get_wide_word(addr)==0: addr+=1
def GetUTFstr(addr):
    if not UTF16start<=addr<UTF16end: halt(hex(addr));return 'unknown'
    end=ida_search.find_binary(addr, addr+0x100, '0 0 0', 0, idc.SEARCH_DOWN)
    length=end-addr+3
    result=idc.get_strlit_contents(addr,length,STRTYPE_C_16).decode()
    if not isString(addr) or idaapi.get_item_head(addr+length-1)!=addr or idaapi.get_item_head(addr)!=addr: 
        ida_bytes.del_items(addr,0,length)
        ida_bytes.create_strlit(addr, length, STRTYPE_C_16)
    idc.set_name(addr,'utf_'+result,0x3981)
    return result
def GetASCstr(addr):
    if not AsciiSTRstart<=addr<AsciiSTRend: halt(hex(addr));return 'unknown'
    end=ida_search.find_binary(addr, addr+0x100, '0', 0, idc.SEARCH_DOWN)
    length=end-addr+1
    result=idc.get_strlit_contents(addr,length,STRTYPE_C).decode()
    if not isString(addr) or idaapi.get_item_head(addr+length-1)!=addr or idaapi.get_item_head(addr)!=addr: 
        ida_bytes.del_items(addr,0,length)
        ida_bytes.create_strlit(addr, length, STRTYPE_C)
    idc.set_name(addr,'str_'+result,0x3981)
    return result

def createStruct(name,members):
    global ReBuildStruct
    struct=ida_struct.get_struc_id(name)
    if struct != BADADDR:
        # if ReBuildStruct is None: ReBuildStruct=ida_kernwin.ask_yn(False, 'HIDECANCEL\nReBuild all struct?')
        ReBuildStruct=False
        if not(ReBuildStruct): return
        idc.del_struc(struct)
    struct=idc.add_struc(BADADDR, name, False)
    for fieldname,ftype in members:
        size=dict(((ida_bytes.FF_BYTE,1),(ida_bytes.FF_WORD,2),(ida_bytes.FF_DWORD,4),(ida_bytes.FF_FLOAT,4),(FF_4BIT,4),(ida_bytes.FF_QWORD,8),(FF_OFFSET,8),(ida_bytes.FF_DOUBLE,8),(FF_8BIT,8)))[ftype]
        idc.add_struc_member(struct, fieldname, BADADDR, ftype, BADADDR, size) 
def createStructs():
    global ReBuildStruct
    createStruct('U50',(('init',FF_OFFSET),('class',FF_OFFSET),('id',ida_bytes.FF_QWORD),('Parents',FF_OFFSET),('Methods',FF_OFFSET),('Properties',FF_OFFSET),('FList',FF_OFFSET),('ParentCount',FF_4BIT),('MethodsCount',FF_4BIT),('PropertiesCount',FF_4BIT),('FListCount',FF_4BIT),('f48',ida_bytes.FF_WORD),('f4A',ida_bytes.FF_WORD),('f4C',ida_bytes.FF_DWORD)))
    createStruct('O48',(('class',FF_OFFSET),('f8',ida_bytes.FF_QWORD),('delegateSign',FF_OFFSET),('parents',FF_OFFSET),('funcName',FF_OFFSET),('f28',ida_bytes.FF_DWORD),('UProperty',FF_OFFSET),('f38',ida_bytes.FF_DWORD),('f3C',ida_bytes.FF_DWORD),('id',ida_bytes.FF_QWORD)))
    createStruct('F48',(('class',FF_OFFSET),('f8',ida_bytes.FF_QWORD),('methodName',FF_OFFSET),('f18',ida_bytes.FF_QWORD),('f20',ida_bytes.FF_QWORD),('f28',ida_bytes.FF_QWORD),('arguments',FF_OFFSET),('ArgsNum',ida_bytes.FF_DWORD),('f3C',ida_bytes.FF_DWORD),('id',ida_bytes.FF_QWORD)))
    createStruct('S48',(('class',FF_OFFSET),('f8',ida_bytes.FF_QWORD),('script',FF_OFFSET),('scriptName',FF_OFFSET),('size',ida_bytes.FF_QWORD),('u28',ida_bytes.FF_QWORD),('properties',FF_OFFSET),('propertiesCount',ida_bytes.FF_DWORD),('f3C',ida_bytes.FF_DWORD),('type',ida_bytes.FF_QWORD)))
    createStruct('E38',(('class',FF_OFFSET),('f8',ida_bytes.FF_QWORD),('name',FF_OFFSET),('typeName',FF_OFFSET),('Enum',FF_OFFSET),('EnumCount',FF_4BIT),('f2C',ida_bytes.FF_DWORD),('f30',ida_bytes.FF_QWORD)))
    createStruct('P20',(('ClassName',FF_OFFSET),('delegateSign',FF_OFFSET),('count',ida_bytes.FF_DWORD),('f14',ida_bytes.FF_DWORD),('ID',ida_bytes.FF_QWORD)))
    createStruct('E10',(('enumName',FF_OFFSET),('index',FF_8BIT)))
    createStruct('F10',(('funcName',FF_OFFSET),('funcAddr',FF_OFFSET)))
    createStruct('M10',(('methodAddr',FF_OFFSET),('methodName',FF_OFFSET)))
    createStruct('P28',(('fieldname',FF_OFFSET),('f8',ida_bytes.FF_QWORD),('f10',ida_bytes.FF_WORD),('f12',ida_bytes.FF_WORD),('f14',ida_bytes.FF_DWORD),('f18',ida_bytes.FF_DWORD),('f1C',ida_bytes.FF_DWORD),('f20',ida_bytes.FF_DWORD),('f24',ida_bytes.FF_DWORD)))
    createStruct('P30',(('fieldname',FF_OFFSET),('f8',ida_bytes.FF_QWORD),('f10',ida_bytes.FF_WORD),('f12',ida_bytes.FF_WORD),('f14',ida_bytes.FF_DWORD),('f18',ida_bytes.FF_DWORD),('f1C',ida_bytes.FF_DWORD),('f20',ida_bytes.FF_DWORD),('offset',ida_bytes.FF_DWORD),('f28',FF_OFFSET)))
    createStruct('P38',(('fieldname',FF_OFFSET),('f8',ida_bytes.FF_QWORD),('f10',ida_bytes.FF_WORD),('f12',ida_bytes.FF_WORD),('f14',ida_bytes.FF_DWORD),('f18',ida_bytes.FF_DWORD),('f1C',ida_bytes.FF_DWORD),('f20',ida_bytes.FF_DWORD),('f24',ida_bytes.FF_DWORD),('f28',ida_bytes.FF_QWORD),('f30',FF_OFFSET)))
    createStruct('UClass',(('Assets',FF_OFFSET),('f08',ida_bytes.FF_DWORD),('f0C',ida_bytes.FF_DWORD),('f10',FF_OFFSET),('f18',ida_bytes.FF_QWORD),('f20',FF_OFFSET),('f28',ida_bytes.FF_QWORD),('f30',FF_OFFSET),('f38',ida_bytes.FF_QWORD),('f40',FF_OFFSET),('f48',FF_OFFSET),('f50',FF_OFFSET),('f58',ida_bytes.FF_DWORD),('f5C',ida_bytes.FF_DWORD),('f60',ida_bytes.FF_QWORD),('f68',ida_bytes.FF_QWORD),('f70',FF_OFFSET),('f78',FF_OFFSET),('f80',ida_bytes.FF_QWORD),('f88',ida_bytes.FF_QWORD),('f90',ida_bytes.FF_QWORD),('f98',ida_bytes.FF_QWORD),('fA0',ida_bytes.FF_QWORD),('fA8',ida_bytes.FF_QWORD),('Contructor',FF_OFFSET),('fB8',FF_OFFSET),('fC0',FF_OFFSET),('fC8',ida_bytes.FF_QWORD),('fD0',ida_bytes.FF_QWORD),('fD8',FF_OFFSET)))
    createStruct('UFunc',(('FunctionBuilder',FF_OFFSET),('f08',ida_bytes.FF_DWORD),('f0C',ida_bytes.FF_DWORD),('f10',FF_OFFSET),('f18',ida_bytes.FF_QWORD),('f20',FF_OFFSET),('f28',ida_bytes.FF_QWORD),('f30',FF_OFFSET),('f38',ida_bytes.FF_QWORD),('f40',ida_bytes.FF_QWORD),('f48',ida_bytes.FF_QWORD),('f50',FF_OFFSET),('f58',ida_bytes.FF_DWORD),('f5C',ida_bytes.FF_DWORD),('f60',ida_bytes.FF_QWORD),('f68',ida_bytes.FF_QWORD),('f70',FF_OFFSET),('f78',ida_bytes.FF_QWORD),('f80',ida_bytes.FF_QWORD),('f88',ida_bytes.FF_QWORD),('f90',ida_bytes.FF_QWORD),('f98',ida_bytes.FF_QWORD),('fA0',ida_bytes.FF_QWORD),('fA8',ida_bytes.FF_QWORD),('fB0',ida_bytes.FF_QWORD),('fB8',ida_bytes.FF_QWORD),('fC0',ida_bytes.FF_QWORD),('fC8',ida_bytes.FF_QWORD),('fD0',ida_bytes.FF_QWORD),('fD8',FF_OFFSET)))
    createStruct('FuncMap',(('fname',FF_OFFSET),('loader',FF_OFFSET),('funcAddr',FF_OFFSET),('isOffset',ida_bytes.FF_QWORD),('f20',FF_OFFSET),('f28',ida_bytes.FF_QWORD),('f30',FF_OFFSET)))
    createStruct('Array',(('content',FF_OFFSET),('s1',ida_bytes.FF_DWORD),('s2',ida_bytes.FF_DWORD)))
    createStruct('ObjHeader',(('Assets',FF_OFFSET),('f08',ida_bytes.FF_DWORD),('f0C',ida_bytes.FF_DWORD),('ClassType',FF_OFFSET),('PrimaryAssetId',ida_bytes.FF_DWORD),('Guid',ida_bytes.FF_DWORD),('Owner',FF_OFFSET)))
def Rebase(targetAddr):
    if GetQword(targetAddr)<base: ide.patch_qword(targetAddr,GetQword(targetAddr)+base)
    

def ExtractUObjectClass(objectAddr,name):
    ApplyUStruct(objectAddr, 'U50')
    Patch(objectAddr,name+'_Class',next(idautils.XrefsTo(objectAddr)).frm)
    AddEmptyLines(objectAddr)
    if isPointer(objectAddr+0x30):
        addr=GetQword(objectAddr+0x30)
        count=GetDword(objectAddr+0x44)
        ApplyStructArray(addr,'E10',count)
        Patch(addr,name+'_Events',objectAddr+0x30)
    if isPointer(objectAddr+0x28):
        addr=GetQword(objectAddr+0x28)
        count=GetDword(objectAddr+0x40)
        ExtractUProperty(addr,count,name)
        Patch(addr,name+'_Properties',objectAddr+0x28)
    if isPointer(objectAddr+0x20):
        addr=GetQword(objectAddr+0x20)
        count=GetDword(objectAddr+0x3C)
        ExtractMethodPairs(addr,count,name)
        Patch(addr,name+'_Methods',objectAddr+0x20)
    if isPointer(objectAddr+0x18):
        addr=GetQword(objectAddr+0x18)
        count=GetDword(objectAddr+0x38)
        ExtractParents(addr,count)
        Patch(addr,name+'_Parents',objectAddr+0x18)
    if isPointer(objectAddr) and inCodeRange(GetQword(objectAddr)): # offset 0 .init
        uObjectConstructor=GetQword(objectAddr)
        if not isFunc(uObjectConstructor): AddFunc(uObjectConstructor)
        if idc.print_insn_mnem(uObjectConstructor)=='B':
            Patch(uObjectConstructor,'j_%s_Constructor'%name,addr)
            uObjectConstructor=idc.get_operand_value(uObjectConstructor,0)
        elif idc.print_insn_mnem(uObjectConstructor+8)=='BL' and idc.print_insn_mnem(uObjectConstructor+16)=='RET':
            Patch(uObjectConstructor,'j_%s_Constructor'%name,addr)
            uObjectConstructor=idc.get_operand_value(uObjectConstructor+8,0)
        print("ExtractUObjectClass(0x%X,'%s')"%(objectAddr,name))
        p(uObjectConstructor)
        if not isFunc(uObjectConstructor): AddFunc(uObjectConstructor)
        ExtractUAssetBuilder(uObjectConstructor)

def ExtractUAssetBuilder(addr):
    uObjectConstructor=GetFuncStart(addr)
    if print_insn_mnem(addr)=='BL' and isFunc(addr): CombineFunc(addr)
    blUAssetBuilder=addr if print_insn_mnem(addr)=='BL' else SearchNextASM(uObjectConstructor,'BL',GetUAssetBuilder())
    if notFound(blUAssetBuilder): return
    if not isCode(blUAssetBuilder) and isFunc(addr): 
        blUAssetBuilder=SearchNextASM(uObjectConstructor,'BL',GetUAssetBuilder(),limit=0x100)
        if isFunc(blUAssetBuilder): CombineFunc(blUAssetBuilder)
    if not isCode(blUAssetBuilder): halt(hex(blUAssetBuilder)+' interrupt at line %d'%getframeinfo(currentframe()).lineno);return
    
    nameAddr=GetParameterHelper(blUAssetBuilder,'X1','UTF')
    if notFound(nameAddr): ApplyComment(blUAssetBuilder,'Case too complex, Skipped'); return 
    uClassName=GetUTFstr(nameAddr-2)
    ApplyComment(blUAssetBuilder,uClassName)
    
    Patch(uObjectConstructor, '%s_Constructor'%uClassName, blUAssetBuilder)

    x2=GetParameterHelper(blUAssetBuilder,'X2','Writeable')
    if isFound(x2): Patch(x2,'%s_Constructor_Pointer'%uClassName,blUAssetBuilder)
        
    flistConstructor=GetParameterHelper(blUAssetBuilder,'X3','Code')
    if isFound(flistConstructor):
        if print_insn_mnem(flistConstructor)=='RET': 
            Patch(flistConstructor,'r_%s_Flist_Constructor'%uClassName,blUAssetBuilder)
        else:
            if print_insn_mnem(flistConstructor)=='B': 
                Patch(flistConstructor,'j_%s_Flist_Constructor'%uClassName,blUAssetBuilder)
                flistConstructor=get_operand_value(flistConstructor,0)
            if not inCodeRange(flistConstructor): 
                p(flistConstructor)
                halt()
            Patch(flistConstructor,'%s_Flist_Constructor'%uClassName,blUAssetBuilder)
            ExtractFListConstructor(flistConstructor,uClassName)

    stp=SearchPrevASM(blUAssetBuilder,'STP',None,None,0,limit=0x80)
    if isFound(stp): 
        assetConstructor=GetParameterHelper(stp,idc.print_operand(stp,1),'Code') # [SP+8] load functions for this class  (btw, SP+20 = parent's functions)
        if isFound(assetConstructor): 
            if not(isFunc(assetConstructor)): AddFunc(assetConstructor)
            p(assetConstructor)
            addr=SearchNextASM(assetConstructor,'B')
            if isFound(addr) and addr-assetConstructor<16:
                Patch(assetConstructor,'j_%s_Assets'%uClassName,blUAssetBuilder)
                assetConstructor=idc.get_operand_value(addr,0)
            Patch(assetConstructor,'%s_Assets'%uClassName,blUAssetBuilder)
            ExtractAssetsConstructor(assetConstructor,uClassName)

    return uClassName

def ExtractFListConstructor(flistConstructor,uClassName):
    if not(isFunc(flistConstructor)): AddFunc(flistConstructor)
    blFListBuilder=SearchNextASM(flistConstructor,'B',GetFListBuilder())
    if notFound(blFListBuilder): blFListBuilder=SearchNextASM(flistConstructor,'BL',GetFListBuilder())
    count=idc.get_operand_value(SearchPrevASM(blFListBuilder,'MOV','W2'),1) 
    fListAddr=GetParameterHelper(blFListBuilder,'X1','ASC') 
    if isFound(fListAddr) and isString(GetQword(fListAddr)) and count>0: 
        ExtractFList(fListAddr,uClassName,flistConstructor,count)
    else:
        print(fListAddr)
        print(count)
        halt()

def ExtractFList(fListAddr,uClassName,flistConstructor,count):
    ReplacePriorComment(fListAddr,'')
    # idc.set_name(idc.get_name_ea(codeStart,'%s_FList'%uClassName),'')
    Patch(fListAddr,'%s_FList'%uClassName,flistConstructor)
    # addr=fListAddr
    # while isString(GetQword(addr)) and isCode(GetQword(addr+8)):
    for addr in range(fListAddr,fListAddr+count*16,16):
        ApplyUStruct(addr, 'F10')
        functionName=GetASCstr(GetQword(addr))
        functionLoader=GetQword(addr+8)
        if not isFunc(functionLoader): AddFunc(functionLoader)
        Patch(functionLoader,'%s.%s'%(uClassName,functionName),addr+8)
        ExtractUFunctionCore(functionLoader,'%s.%s'%(uClassName,functionName))
        # fListAddr+=16
    AddEmptyLines(fListAddr+count*16-16)

def ExtractAssetsConstructor(assetConstructor,uClassName):
    if not isFunc(assetConstructor): AddFunc(assetConstructor)
    addr=assetConstructor
    while isFound(SearchNextASM(addr,'ADRL')):
        addr=SearchNextASM(addr,'ADRL')
        target=idc.get_operand_value(addr,1)
        if isFound(target) and GetQword(target)==0 and GetQword(target+0x10)!=0: target+=0x10
        if isFound(target) and isCode(GetQword(target)):
            # idc.set_name(target,'')
            AddPriorComment(target,'Functions used by '+uClassName)
    # if not(isFunc(assetConstructor)): AddFunc(assetConstructor)
    # addr=SearchNextASM(assetConstructor,'B')
    # if isFound(addr) and addr-assetConstructor<16:
        # Patch(assetConstructor,'j_%s_Assets_Constructor'%uClassName,blUAssetBuilder)
        # assetConstructor=idc.get_operand_value(addr,0)
        # blUAssetBuilder=addr
        # if not(isFunc(assetConstructor)): AddFunc(assetConstructor)
        # x0=SearchNextASM(assetConstructor,'MOV',None,'X0') # to find MOV ??, X0
        # temp=SearchNextASM(assetConstructor,'STR','X0','X29')  # to find STR X0, [X29,??]
        # if isFound(temp) and (notFound(x0) or temp<x0):
            # x0=SearchNextASM(assetConstructor,'LDR',None,'X29',idc.get_operand_value(temp,1))  # to find LDR X?, [X29,n]
    # else:
        # x0=SearchNextASM(assetConstructor,'LDR',None,'X0',0) 
    # if notFound(x0): 
        # Show('Cannot find %s_Assets_Constructor %X'%(uClassName,assetConstructor))
        # return uClassName
    # Patch(assetConstructor,'%s_Assets_Constructor'%uClassName,blUAssetBuilder)
    # x8=SearchNextASM(x0,'STR',None,idc.print_operand(x0,0),0) # to find STR X?, [Xn]
    # AssetAddr=BADADDR
    # if isFound(x8):
        # regName=idc.print_operand(x8,0)
        # adrl=SearchPrevASM(x8,'ADRL',regName)
        # if isFound(adrl):
            # AssetAddr=idc.get_operand_value(adrl,1)
        # else:
            # addend=SearchPrevASM(x8,'ADD',regName)
            # if isFound(addend):
                # offset=SearchPrevASM(addend,'LDR',idc.print_operand(addend,1))
                # offset2=SearchPrevASM(x8,'LDR',regName)
                # if isFound(addend) and isFound(offset) and (notFound(offset2) or addend>offset2):
                    # regName=idc.print_operand(addend,1)
                    # addendOffset=idc.get_operand_value(addend,2)
                # elif isFound(offset2):
                    # addendOffset=0
                    # offset=offset2
                # else:
                    # Show('Cannot find %s_Assets %X'%(uClassName,assetConstructor))
                    # return uClassName
                # base=SearchPrevASM(offset,'ADRP',idc.print_operand(offset,0))
                # if isFound(base):
                    # AssetAddr=idc.get_operand_value(base,1)+idc.get_operand_value(offset,1)
                # else:
                    # Show('Cannot find %s_Assets %X'%(uClassName,assetConstructor))
                    # return uClassName
    # else:
        # Show('Cannot find %s_Assets %X'%(uClassName,assetConstructor))
        # return uClassName
    # if RELAstart<=AssetAddr<RELAend or GOTstart<=AssetAddr<GOTend:
        # Patch(AssetAddr,'j_%s_Assets'%uClassName,blUAssetBuilder)
        # blUAssetBuilder=AssetAddr
        # AssetAddr=GetQword(blUAssetBuilder)
    # if GetQword(AssetAddr)|GetQword(AssetAddr+8)==0 and GetQword(AssetAddr+0x10)>0:
        # idc.set_name(AssetAddr,'')
        # AssetAddr+=0x10
    # Patch(AssetAddr,'%s_Assets'%uClassName,blUAssetBuilder)


def ExtractUFunctionCore(functionLoader,functionName):
    x0=SearchNextASM(functionLoader,'MOV',None,'X0') # to find MOV ??, X0
    if notFound(x0):
        addr=functionLoader
    else:    
        addr=SearchNextASM(x0,'MOV','X0',idc.print_operand(x0,0)) # to find MOV X0, Xn
    if isFound(addr):
        bl=SearchNextASM(addr,'BL')
        if notFound(bl):
            if print_insn_mnem(GetFuncEnd(addr)-4)=='B': bl=GetFuncEnd(addr)-4 
        if isFound(bl) and idc.get_name(idc.get_operand_value(bl,0))[0:4] in ('sub_','unk_'):
            Patch(idc.get_operand_value(bl,0),functionName+'_core',bl)    


def ExtractPackage(objectAddr):
    ApplyUStruct(objectAddr,'P20')
    nameAddr=GetQword(objectAddr)
    PackageName=idc.get_strlit_contents(nameAddr).decode().replace('/Script/','')
    PackageName='%s'%(PackageName)
    Patch(objectAddr,PackageName+'_Class',nameAddr)
    AddEmptyLines(objectAddr)
    if isPointer(objectAddr+0x8) and GetQword(objectAddr+0x10)>0:
        startAddr=GetQword(objectAddr+0x8)
        Patch(startAddr,PackageName,objectAddr+0x8)
    return PackageName
    
def ExtractMethodPairs(startAddr,count,parentName):
    for i in range(count):
        addr=startAddr+i*16
        if not(isString(GetQword(addr+8)) and isFunc(GetQword(addr))): continue
        ApplyUStruct(addr, 'M10')
        methodName='%s.%s'%(parentName,GetASCstr(GetQword(addr+8)))
        methodAddr=GetQword(addr)
        Patch(methodAddr,'%s_Loader'%methodName,addr)
        
        addr=SearchPrevASM(GetFuncEnd(methodAddr),'MOV','X0')
        if isFound(addr):
            addr=SearchPrevASM(addr,'ADRL',idc.print_operand(addr,1))
            if isFound(addr): Patch(idc.get_operand_value(addr,1),'%s_Method_Pointer'%methodName,addr)

        addr=SearchPrevASM(GetFuncEnd(methodAddr),'ADRL','X1')
        if isFound(addr): ExtractMethodObject(idc.get_operand_value(addr,1))

def ExtractUProperty(start,count,className):
    op_plain_offset(start,0,0);
    ApplyArray(start,count)
    lastPos=start
    for i in reversed(range(count)):
        aProperty=GetQword(start+i*8)
        length=lastPos-aProperty
        lastPos=aProperty
        ApplyUStruct(aProperty,'P%02X'%length)
        propertyName=GetASCstr(GetQword(aProperty))
        Patch(aProperty,className+'.'+propertyName,GetQword(aProperty))
        if length==0x38:
            setter=aProperty+0x30
            if isPointer(setter) and isFunc(GetQword(setter)):
                Patch(GetQword(setter),'%s.%s_Setter'%(className,propertyName),setter)
        # elif length==0x30:
            # setter=aProperty+0x28
            # if isPointer(setter) and isFunc(GetQword(setter)):
                # Patch(GetQword(setter),'%s_Setter'%(className,propertyName),setter)

def studyMethod(addr):
    methodName=GetASCstr(GetQword(addr+8))
    target=GetQword(addr)
    Patch(target,methodName,addr)
    while not(idc.print_insn_mnem(target)=='ADRL' and idc.print_operand(target,0)=='X1'): target+=4
    aMethod=idc.get_operand_value(target,1)
    Patch(aMethod, methodName+'_Class', target)
    AddEmptyLines(objectAddr)
    ApplyUStruct(aMethod,'M%02X'%(cutline-aMethod))
    cutline=aMethod
    aProperty=GetQword(aMethod+0x30)
    if aProperty>0:
        cutline=aProperty
        arg=aMethod-8
        while arg>=aProperty:
            op_plain_offset(arg,0,0)
            target=GetQword(arg)
            ApplyUStruct(target,'P%02X'%(cutline-target))
            cutline=target
            arg-=8
        ApplyArray(aProperty,(aMethod-aProperty)//8)

def ExtractParents(start,count):
    op_plain_offset(start,0,0)
    ApplyArray(start,count)

UObjectBuilder=UClassBuilder=PackageBuilder=MethodBuilder=UAssetBuilder=FListBuilder=StructureBuilder=EnumBuilder=None


def ExtractAActor():
    global UObjectBuilder,UClassBuilder,PackageBuilder,MethodBuilder,UAssetBuilder,FListBuilder
    utf_AActor=searchUTF16('AActor')
    if notFound(utf_AActor): Warning('UTF string: AActor not found!'); return
    addrs=SearchXrefASM(utf_AActor,'ADRL','!X1',listAll=True)
    for addr in addrs:
        if notFound(addr): continue
        x2=SearchNextASM(addr,'MOV','X2',idc.print_operand(addr,0),limit=0x60)
        if notFound(x2): continue
        blUObjectBuilder=min(SearchNextASM(x2,'BL',limit=0x60),SearchNextASM(x2,'B',limit=0x60))

        AActor=GetParameterHelper(blUObjectBuilder,'X0','Code')
        AActor_Constructor=GetParameterHelper(blUObjectBuilder,'X1','Code')
        if notFound(AActor) or notFound(AActor_Constructor): continue

        UObjectBuilder=idc.get_operand_value(blUObjectBuilder,0)
        Patch(UObjectBuilder,'UObjectBuilder',blUObjectBuilder)
        Patch(AActor,'AActor',blUObjectBuilder)
        
        blUClassBuilder=SearchNextASM(SearchNextASM(AActor,'ADRL','X1'),'BL')
        UClassBuilder=idc.get_operand_value(blUClassBuilder,0)
        Patch(UClassBuilder,'UClassBuilder',blUClassBuilder)
        
        AActor_Class=GetParameterHelper(blUClassBuilder,'X1','Pointer')
        Patch(AActor_Class,'AActor_Class',blUClassBuilder)

        AActor_Constructor=GetQword(AActor_Class)
        if idc.print_insn_mnem(AActor_Constructor)=='B':
            Patch(AActor_Constructor,'j_AActor_Constructor',blUObjectBuilder)
            AActor_Constructor=idc.get_operand_value(AActor_Constructor,0)
        Patch(AActor_Constructor,'AActor_Constructor',AActor_Class)

        Engine=GetQword(GetQword(AActor_Class+0x18)+0x8)
        Patch(Engine,'Engine',AActor_Class)

        blPackageBuilder=SearchNextASM(SearchNextASM(Engine,'ADRL','X1'),'BL')
        PackageBuilder=idc.get_operand_value(blPackageBuilder,0)
        Patch(PackageBuilder,'PackageBuilder',blPackageBuilder)

        aMethod=GetQword(GetQword(AActor_Class+0x20))
        blMethodBuilder=SearchNextASM(SearchNextASM(aMethod,'ADRL','X1'),'BL')
        MethodBuilder=idc.get_operand_value(blMethodBuilder,0)
        Patch(MethodBuilder,'MethodBuilder',blMethodBuilder)

        blUAssetBuilder=SearchNextASM(SearchNextASM(AActor_Constructor,'MOV','X7'),'BL')
        UAssetBuilder=idc.get_operand_value(blUAssetBuilder,0)
        Patch(UAssetBuilder,'UAssetBuilder',blUAssetBuilder)
        
        AActor_Flist_Constructor=GetParameterHelper(blUAssetBuilder,'X3','Code')
        w2=SearchNextASM(AActor_Flist_Constructor,'MOV','W2')
        blFListBuilder=min(SearchNextASM(w2,'B'),SearchNextASM(w2,'BL'))
        FListBuilder=idc.get_operand_value(blFListBuilder,0)
        Patch(FListBuilder,'FListBuilder',blFListBuilder)
        break
    if UObjectBuilder==None or notFound(UObjectBuilder) or notFound(UClassBuilder) or notFound(UAssetBuilder) or notFound(FListBuilder): halt('Logic Error in ExtractAActor!')
    return UObjectBuilder


    if not(isFunc(flistConstructor)): AddFunc(flistConstructor)
    m=SearchNextASM(flistConstructor,'MOV','W2')
    while isFound(m) and print_operand(m,1)[0] != '#':
        m=SearchNextASM(m,'MOV','W2')
    if isFound(m): 
        b=SearchNextASM(m,'B')
        bl=SearchNextASM(m,'BL')
        blFListBuilder=min(b,bl)
    count=idc.get_operand_value(SearchPrevASM(blFListBuilder,'MOV','W2'),1) 
    fListAddr=GetParameterHelper(blFListBuilder,'X1','ASC') 
    # if isFound(fListAddr) and isString(GetQword(fListAddr)) and count>0: 
        # ExtractFList(fListAddr,'AActor',flistConstructor,count)
    # else:
        # halt('Logic Error in finding FlistBuilder')
 
def GetUObjectBuilder():
    global UObjectBuilder
    if UObjectBuilder is None: ExtractAActor()
    return UObjectBuilder

def GetUAssetBuilder():
    global UAssetBuilder
    if UAssetBuilder is None: ExtractAActor()
    return UAssetBuilder

def GetUClassBuilder():
    global UClassBuilder
    if UClassBuilder is None: ExtractAActor()
    return UClassBuilder

def GetFListBuilder():
    global FListBuilder
    if FListBuilder is None: ExtractAActor()
    return FListBuilder
    
def GetPackageBuilder():
    global PackageBuilder
    if PackageBuilder is None: ExtractAActor()
    return PackageBuilder

def GetMethodBuilder():
    global MethodBuilder
    if MethodBuilder is None: ExtractAActor()
    return MethodBuilder

def GetStructureBuilder():
    global StructureBuilder
    if StructureBuilder is None:
        CoreuobjectAddr=idc.get_name_ea(dataStart,'CoreUObject_Class')
        if notFound(CoreuobjectAddr): GetPackageBuilder(); CoreuobjectAddr=idc.get_name_ea(dataStart,'CoreUObject_Class')
        anyScriptAsset=GetQword(GetQword(CoreuobjectAddr+0x8))
        bl=SearchPrevASM(GetFuncEnd(anyScriptAsset),'BL')
        if notFound(bl): Debug(hex(anyScriptAsset)+' interrupt at line %d'%getframeinfo(currentframe()).lineno);return
        StructureBuilder=idc.get_operand_value(bl,0)
        Patch(StructureBuilder,'StructureBuilder',bl)
    return StructureBuilder

def GetEnumBuilder():
    global EnumBuilder
    if EnumBuilder is None:
        s_EUnit=searchAscii('EUnit')
        if notFound(s_EUnit): Warning('Ascii EUnit not found!');return
        EUnit_Struc=searchDataRef(s_EUnit)
        if notFound(EUnit_Struc): Debug(hex(s_EUnit)+' interrupt at line %d'%getframeinfo(currentframe()).lineno);return
        Patch(EUnit_Struc-0x10,'EUnit_Class',EUnit_Struc)
        EUnit_Struc-=0x10
        EUnit=SearchXrefASM(EUnit_Struc,'ADRL','X1')
        if notFound(EUnit): Debug(hex(EUnit_Struc)+' interrupt at line %d'%getframeinfo(currentframe()).lineno);return
        Patch(GetFuncStart(EUnit),'EUnit',EUnit)
        bl=SearchNextASM(EUnit,'BL')
        if notFound(bl): Debug(hex(EUnit)+' interrupt at line %d'%getframeinfo(currentframe()).lineno);return
        EnumBuilder=idc.get_operand_value(bl,0)
        Patch(EnumBuilder,'EnumBuilder',bl)
    return EnumBuilder

    
def ExtractUObject(classname):
    utf_string=searchUTF16(classname)
    if notFound(utf_string): Warning('UTF string: %s not found!'%classname); return
    addrs=SearchXrefASM(utf_string,'ADRL','!X1',listAll=True)
    for addr in addrs:
        if not inCodeRange(addr): continue
        bl=SearchNextASM(addr,'BL',GetUObjectBuilder())
        if notFound(bl): bl=SearchNextASM(addr,'B',GetUObjectBuilder())
        if notFound(bl): continue
        BuildUObject(bl)
        
def BuildUObjects():
    UObjects=list(idautils.CodeRefsTo(GetUObjectBuilder(),0))
    total=len(UObjects)
    current=0
    for blUObjectBuilder in UObjects:
        current+=1
        Show('ExtractUObject(0x%X)\n( %d / %d )'%(blUObjectBuilder,current,total))
        BuildUObject(blUObjectBuilder)

def BuildUObject(blUObjectBuilder):
    x2=GetParameterHelper(blUObjectBuilder,'X2','UTF')
    if not UTF16start<=x2<UTF16end: halt('x2 not found at %X'%blUObjectBuilder)
    className=GetUTFstr(x2)
    Patch(x2,'utf_%s'%className,blUObjectBuilder)
    
    uFuncLoader=GetParameterHelper(blUObjectBuilder,'X1','Code') # FList and Assets Loader (has AssetBuilder)
    if print_insn_mnem(uFuncLoader)=='B':
        Patch(uFuncLoader,'j_%s_Constructor'%className,blUObjectBuilder)
        uFuncLoader=idc.get_operand_value(uFuncLoader,0)
    elif idc.print_insn_mnem(uFuncLoader+8)=='BL' and idc.print_insn_mnem(uFuncLoader+16)=='RET':
        Patch(uFuncLoader,'j_%s_Constructor'%className,blUObjectBuilder)
        uFuncLoader=idc.get_operand_value(uFuncLoader+8,0)
    Patch(uFuncLoader,'%s_Constructor'%className,blUObjectBuilder)

    UClassAddr=GetParameterHelper(blUObjectBuilder,'X0','Pointer')
    Patch(UClassAddr,'%s'%className,blUObjectBuilder) 
    ApplyComment(blUObjectBuilder,className)
    ExtractUClass(UClassAddr,className)
        
def ExtractUClass(UClassAddr,UClassName):
    Debug("ExtractUClass(%s,'%s')"%(hex(UClassAddr),UClassName))
    blUClassBuilder=SearchPrevASM(GetFuncEnd(UClassAddr),'BL',GetUClassBuilder())
    if isFound(blUClassBuilder):
        x0=GetParameterHelper(blUClassBuilder,'X0','Writeable')
        if isFound(x0): Patch(x0,'%s_Pointer'%UClassName,UClassAddr)
        uObjectClass=GetParameterHelper(blUClassBuilder,'X1','Code')
        if isFound(uObjectClass): ExtractUObjectClass(uObjectClass,UClassName)

def BuildEnums():
    EnumObjects=list(idautils.CodeRefsTo(GetEnumBuilder(),0))
    total=len(EnumObjects)
    current=0
    for addr in EnumObjects:
        current+=1
        if isFound(SearchPrevASM(addr,'ADD','X0','SP',limit=0x10)): continue
        x1=SearchPrevASM(addr,'ADRL','X1')
        Show('ExtractEnum(0x%X)\n( %d / %d )'%(addr,current,total))
        if notFound(x1):
            Debug('Extracting Enums ( %d / %d ) Fail with SearchPrevASM(0x%X,\'ADRL\',\'X1\')'%(current,total,addr))
            continue
        objectAddr=idc.get_operand_value(x1,1)
        enumName=ExtractEnum(objectAddr)
        if enumName=='': continue
        loaderAddr=GetFuncStart(addr)
        Patch(loaderAddr,'%s_Loader'%enumName,addr)
        x0=SearchPrevASM(GetFuncEnd(loaderAddr),'MOV','X0')
        if isFound(x0):
            pointerAddr=SearchPrevASM(x0,'ADRL',idc.print_operand(x0,1))
            if isFound(pointerAddr): Patch(idc.get_operand_value(pointerAddr,1),'%s_Enums_Pointer'%enumName,pointerAddr)
            
        refs=idautils.XrefsTo(loaderAddr,0)
        for jumpAddr in refs:
            if isFunc(jumpAddr.frm):
                Patch(GetFuncStart(jumpAddr),'pre_'+enumName,loaderAddr)

# def ExtractEnum2(addr):

    # classOffsetRef=SearchNextASM(addr,'STR','X8','X19')
    # classOffset=idc.get_operand_value(classOffsetRef,1)
    
    # nameAddrRef=SearchNextASM(classOffsetRef,'STR','X8','X19',ClassOffset+0x10)-8
    # nameAddr=idc.get_operand_value(nameAddrRef,1)
    # fullObjectName='Enum_%s'%(GetUTFstr(nameAddr))

    # typeNameRef=SearchNextASM(classOffsetRef,'STR','X8','X19',ClassOffset+0x18)-8
    # typeName=idc.get_operand_value(typeNameRef,1)

    # enumAddrRef=SearchNextASM(classOffsetRef,'STR','X8','X19',ClassOffset+0x20)-8
    # enumAddr=idc.get_operand_value(enumAddrRef,1)

    # enumCountRef=SearchNextASM(classOffsetRef,'STR',None,'X19',ClassOffset+0x28)
    # register=idc.print_operand(enumCountRef,0)
    # enumCountRef=SearchPrevASM(enumCountRef,'LDR',register)
    # register=idc.print_operand(enumCountRef,1).split(',')[0].replace('[','');
    # enumCountAddr=idc.get_operand_value(SearchPrevASM(enumCountRef,'ADRP',register),1)+idc.get_operand_value(enumCountRef,1)
    # enumCount=get_wide_word(enumCountAddr)

    # ApplyStructArray(enumAddr,'E10',enumCount)


def ExtractEnum(objectAddr):
    ApplyUStruct(objectAddr,'E38')
    nameAddr=objectAddr+0x10
    objectName=GetASCstr(GetQword(nameAddr))
    typeName=GetASCstr(GetQword(objectAddr+0x18))
    fullObjectName='Enum_%s'%(objectName)
    Patch(objectAddr,fullObjectName+'_Class',nameAddr)
    AddEmptyLines(objectAddr)
    enumAddr=GetQword(objectAddr+0x20)
    enumCount=GetDword(objectAddr+0x28)
    ApplyStructArray(enumAddr,'E10',enumCount)
    AddPriorComment(enumAddr,fullObjectName+'_List')
    for i in range(enumCount):
        aEnum=enumAddr+i*16
        ApplyComment(aEnum,'%02d=%s'%(i,GetASCstr(GetQword(aEnum))))
    return fullObjectName

def BuildStructures():
    FuncObjects=list(idautils.CodeRefsTo(GetStructureBuilder(),0))
    total=len(FuncObjects)
    current=0
    for addr in FuncObjects:
        current+=1
        funcStart=GetFuncStart(addr)
        while (idc.print_insn_mnem(addr)!='ADRL' or idc.print_operand(addr,0)!='X1') and addr>funcStart: addr-=4
        if addr<=funcStart: Debug(hex(addr)+' interrupt at line %d'%getframeinfo(currentframe()).lineno);continue
        objectAddr=idc.get_operand_value(addr,1)
        Show('ExtractStructObject(0x%X)\n( %d / %d )'%(objectAddr,current,total))
        objectName=ExtractStructObject(objectAddr)
        Patch(funcStart,'%s'%objectName,addr)
        addr=SearchPrevASM(GetFuncEnd(funcStart),'MOV','X0')
        if isFound(addr):
            addr=SearchPrevASM(addr,'ADRL',idc.print_operand(addr,1))
            if isFound(addr): Patch(idc.get_operand_value(addr,1),'%s_struc_Pointer'%objectName,addr)

def ExtractStructObject(objectAddr):
    ApplyUStruct(objectAddr,'S48')
    fullObjectName='Struct_%s'%GetASCstr(GetQword(objectAddr+0x18))
    Patch(objectAddr,'%s_Class'%fullObjectName,objectAddr+0x18)
    Patch(GetQword(objectAddr+0x10),'%s_Setter'%fullObjectName,objectAddr+0x10)
    AddEmptyLines(objectAddr)
    if isPointer(objectAddr+0x30):
        addr=GetQword(objectAddr+0x30)
        count=GetDword(objectAddr+0x38)
        ExtractUProperty(addr,count,fullObjectName)
        Patch(addr,fullObjectName+'_Properties',objectAddr+0x30)
    return fullObjectName

def BuildMethods():
    MethodObjects=list(idautils.CodeRefsTo(GetMethodBuilder(),0))
    total=len(MethodObjects)
    current=0
    for addr in MethodObjects:
        current+=1
        x1=SearchPrevASM(addr,'ADRL','X1')
        if notFound(x1): Debug(hex(addr)+' interrupt at line %d'%getframeinfo(currentframe()).lineno);continue
        objectAddr=idc.get_operand_value(x1,1)
        Show('ExtractMethodObject(0x%X)\n( %d / %d )'%(objectAddr,current,total))
        # Show('Extracting Methods ( %d / %d ) \n at 0x%X -> 0x%X'%(current,total,x1,objectAddr))
        objectName=ExtractMethodObject(objectAddr)
        # Show('Extracting Methods ( %d / %d ) \n %s'%(current,total,objectName))
        Patch(GetFuncStart(addr),objectName+'_Loader',addr)
        x0=SearchPrevASM(addr,'MOV','X0')
        if isFound(x0):
            pointerAddr=SearchPrevASM(x0,'ADRL',idc.print_operand(x0,1))
            if isFound(pointerAddr): Patch(idc.get_operand_value(pointerAddr,1),'%s_method_Pointer'%objectName,pointerAddr)

def ExtractMethodObject(objectAddr):
    ApplyUStruct(objectAddr,'F48')
    parentName=idc.get_name(GetQword(objectAddr)).replace('_Loader','')
    fullObjectName='%s.%s'%(parentName,GetASCstr(GetQword(objectAddr+0x10)))
    Patch(objectAddr,fullObjectName+'_Class',objectAddr+0x10)
    AddEmptyLines(objectAddr)
    if isPointer(objectAddr+0x30):
        addr=GetQword(objectAddr+0x30)
        count=GetDword(objectAddr+0x38)
        ExtractUProperty(addr,count,fullObjectName)
        Patch(addr,fullObjectName+'_Arguments',objectAddr+0x30)
    return fullObjectName
  

def BindUFunctions():
    UassetObjects=list(idautils.CodeRefsTo(GetUAssetBuilder(),0))
    total=len(UassetObjects)
    current=0
    for addr in UassetObjects:
        current+=1
        Show('ExtractUAssetBuilder(0x%X)\n( %d / %d )'%(addr,current,total))
        p(addr)
        objectName=ExtractUAssetBuilder(addr)


def BuildPackages():
    Packages=list(idautils.CodeRefsTo(GetPackageBuilder(),0))
    total=len(Packages)
    current=0
    for addr in Packages:
        current+=1
        oriAddr=addr
        funcStart=GetFuncStart(addr)
        funcEnd=GetFuncEnd(addr)
        testAddr=addr+4
        while (idc.print_insn_mnem(testAddr)!='BL' and idc.print_insn_mnem(testAddr)!='B') and testAddr<=funcEnd: testAddr+=4
        if testAddr<=funcEnd: set_name(funcStart,'');continue
        testAddr=addr-4
        while (idc.print_insn_mnem(testAddr)!='BL' and idc.print_insn_mnem(testAddr)!='B') and testAddr>=funcStart: testAddr-=4
        if testAddr>=funcStart: set_name(funcStart,'');continue
        while (idc.print_insn_mnem(addr)!='ADRL' or idc.print_operand(addr,0)!='X1') and addr>funcStart: addr-=4
        if addr<=funcStart: Debug(hex(addr)+' interrupt at line %d'%getframeinfo(currentframe()).lineno);continue
        objectAddr=idc.get_operand_value(addr,1)
        Show('ExtractPackage(0x%X)\n( %d / %d )'%(objectAddr,current,total))
        objectName=ExtractPackage(objectAddr)
        # Show('Extracting Class Packages ( %d / %d ) \n %s'%(current,total,objectName))
        Patch(funcStart,'%s_Loader'%objectName,objectAddr)
        addr=SearchPrevASM(oriAddr,'MOV','X0')
        if isFound(addr):
            addr=SearchPrevASM(addr,'ADRL',idc.print_operand(addr,1))
            if isFound(addr): Patch(idc.get_operand_value(addr,1),'%s_Package_Pointer'%objectName,addr)

def Explore(name):
    refs=list(idautils.XrefsTo(searchUTF16(name)))
    if refs==None:
        Warning('UTF16 String %s cannot be found!'%name)
        return
    for ref in refs:
        addr=ref.frm
        if idc.print_insn_mnem(addr)!='ADRL': continue
        register=idc.print_operand(addr,0)
        x2=SearchNextASM(addr,'MOV','X2',register)
        if notFound(x2): continue
        x0=SearchPrevASM(x2,'ADRL','X0')
        if notFound(x0) or x0<addr: continue
        Patch(GetFuncStart(idc.get_operand_value(x0,1)),'%s_Loader'%name,x0)
        ExtractUClass(idc.get_operand_value(x0,1),name)
        return
    Warning('UObject %s cannot be found'%name);return

def elfSegment():
    ida_segment.set_segm_name(ida_segment.get_next_seg(ida_segment.get_segm_by_name('.got.plt').start_ea),'.got',0)
    gotAddr=ida_segment.get_segm_by_name('.got').start_ea
    set_segm_class(gotAddr,'CONST')
    set_segm_attr(gotAddr,SEGATTR_PERM,idaapi.SEGPERM_READ)
    ADRLx8=AOB("? ? ? ? 08 ? ? F9 ? ? ? ? ? ? ? ? 29 ? ? F9")
    dynamicStart=GetQword(idc.get_operand_value(ADRLx8,1)+idc.get_operand_value(ADRLx8+4,1))
    dynamicEnd=ida_segment.get_segm_by_name('.got.plt').start_ea
    ida_segment.set_segm_end(dynamicStart,dynamicStart,SEGMOD_KEEP)
    ida_segment.add_segm(base//16, dynamicStart, dynamicEnd, '.dynamic', 'CONST', ida_segment.ADDSEG_NOAA|ida_segment.ADDSEG_QUIET|ida_segment.ADDSEG_SPARSE)
# ida_segment.set_segm_end(0x34AB248,0x34AB248,SEGMOD_KEEP)
# ida_segment.add_segm(base//16, 0x34AB248,0x35632E0, '.dynsym', 'CONST', ida_segment.ADDSEG_NOAA|ida_segment.ADDSEG_QUIET|ida_segment.ADDSEG_SPARSE)
# set_segm_attr(0x34AB248,SEGATTR_BITNESS,2)
# set_segm_attr(0x34AB248,SEGATTR_PERM,idaapi.SEGPERM_READ)

# ida_segment.add_segm(base//16, 0x35632E0,0x3BE3DA8, '.strTAB', 'CONST', ida_segment.ADDSEG_NOAA|ida_segment.ADDSEG_QUIET|ida_segment.ADDSEG_SPARSE)
# set_segm_attr(0x35632E0,SEGATTR_BITNESS,2)
# set_segm_attr(0x35632E0,SEGATTR_PERM,idaapi.SEGPERM_READ)
    set_segm_attr(dynamicStart,SEGATTR_BITNESS,2)
    set_segm_attr(dynamicStart,SEGATTR_PERM,idaapi.SEGPERM_READ|idaapi.SEGPERM_WRITE)
    set_segm_attr(dynamicStart,SEGATTR_ALIGN,saRelQword)
    dynCount=(dynamicEnd-dynamicStart)//0x10
    createStruct('Elf64_Dyn_Link',(('d_tag',ida_bytes.FF_QWORD),('d_un',FF_OFFSET)))
    for i in range(dynCount):
        loc=dynamicStart+i*0x10
        if GetQword(loc) in (3,4,5,6,7,12,13,17,22,23,25,26,32,0x6ffffef5,0x6ffffeff): ApplyStruct(loc,'Elf64_Dyn_Link')

def nsoSegment():
    createStruct('Elf64_Dyn',(('d_tag',ida_bytes.FF_QWORD),('d_un',ida_bytes.FF_QWORD)))
    createStruct('Elf64_Dyn_Link',(('d_tag',ida_bytes.FF_QWORD),('d_un',FF_OFFSET)))
    createStruct('Elf64_Rela',(('r_offset',FF_OFFSET),('r_info',ida_bytes.FF_DWORD),('r_other',ida_bytes.FF_DWORD),('r_addend',FF_OFFSET)))
    createStruct('Elf64_Sym',(('st_name',ida_bytes.FF_DWORD),('st_info',ida_bytes.FF_BYTE),('st_other',ida_bytes.FF_BYTE),('st_shndx',ida_bytes.FF_WORD),('st_value',FF_OFFSET),('st_size',ida_bytes.FF_QWORD)))
    dynamicStart=ida_segment.get_segm_by_name('.dynamic').start_ea
    dynamicEnd=ida_segment.get_segm_by_name('.dynamic').end_ea
    dynCount=(dynamicEnd-dynamicStart)//0x10
    ApplyStructArray(dynamicStart,'Elf64_Dyn',dynCount)
    for i in range(dynCount):
        loc=dynamicStart+i*0x10
        opr=GetQword(loc)
        if opr==0: ApplyComment(loc,'DT_NULL - Marks end of dynamic section')
        elif opr==1: ApplyComment(loc,'DT_NEEDED - Name of needed library')
        elif opr==2: ApplyComment(loc,'DT_PLTRELSZ - Size in bytes of PLT relocs')
        elif opr==3: ApplyComment(loc,'DT_PLTGOT - Processor defined value'); Rebase(loc+8);ApplyStruct(loc,'Elf64_Dyn_Link')
        elif opr==4: ApplyComment(loc,'DT_HASH - Address of symbol hash table'); Rebase(loc+8);ApplyStruct(loc,'Elf64_Dyn_Link')
        elif opr==5: ApplyComment(loc,'DT_STRTAB - Address of string table'); Rebase(loc+8);ApplyStruct(loc,'Elf64_Dyn_Link')
        elif opr==6: ApplyComment(loc,'DT_SYMTAB - Address of symbol table'); Rebase(loc+8);ApplyStruct(loc,'Elf64_Dyn_Link')
        elif opr==7: ApplyComment(loc,'DT_RELA - Address of Rela relocs'); Rebase(loc+8);ApplyStruct(loc,'Elf64_Dyn_Link')
        elif opr==8: ApplyComment(loc,'DT_RELASZ - Total size of Rela relocs')
        elif opr==9: ApplyComment(loc,'DT_RELAENT - Size of one Rela reloc')
        elif opr==10: ApplyComment(loc,'DT_STRSZ - Size of string table')
        elif opr==11: ApplyComment(loc,'DT_SYMENT - Size of one symbol table entry')
        elif opr==12: ApplyComment(loc,'DT_INIT - Address of init function'); Rebase(loc+8);ApplyStruct(loc,'Elf64_Dyn_Link')
        elif opr==13: ApplyComment(loc,'DT_FINI - Address of termination function'); Rebase(loc+8);ApplyStruct(loc,'Elf64_Dyn_Link')
        elif opr==14: ApplyComment(loc,'DT_SONAME - Name of shared object')
        elif opr==15: ApplyComment(loc,'DT_RPATH - Library search path (deprecated)')
        elif opr==16: ApplyComment(loc,'DT_SYMBOLIC - Start symbol search here')
        elif opr==17: ApplyComment(loc,'DT_REL - Address of Rel relocs'); Rebase(loc+8);ApplyStruct(loc,'Elf64_Dyn_Link')
        elif opr==18: ApplyComment(loc,'DT_RELSZ - Total size of Rel relocs')
        elif opr==19: ApplyComment(loc,'DT_RELENT - Size of one Rel reloc')
        elif opr==20: ApplyComment(loc,'DT_PLTREL - Type of reloc in PLT')
        elif opr==21: ApplyComment(loc,'DT_Debug - For Debugging; unspecified')
        elif opr==22: ApplyComment(loc,'DT_TEXTREL - Reloc might modify .text'); Rebase(loc+8);ApplyStruct(loc,'Elf64_Dyn_Link')
        elif opr==23: ApplyComment(loc,'DT_JMPREL - Address of PLT relocs'); Rebase(loc+8);ApplyStruct(loc,'Elf64_Dyn_Link')
        elif opr==24: ApplyComment(loc,'DT_BIND_NOW - Process relocations of object')
        elif opr==25: ApplyComment(loc,'DT_INIT_ARRAY - Array with addresses of init fct'); Rebase(loc+8);ApplyStruct(loc,'Elf64_Dyn_Link')
        elif opr==26: ApplyComment(loc,'DT_FINI_ARRAY - Array with addresses of fini fct'); Rebase(loc+8);ApplyStruct(loc,'Elf64_Dyn_Link')
        elif opr==27: ApplyComment(loc,'DT_INIT_ARRAYSZ - Size in bytes of DT_INIT_ARRAY')
        elif opr==28: ApplyComment(loc,'DT_FINI_ARRAYSZ - Size in bytes of DT_FINI_ARRAY')
        elif opr==29: ApplyComment(loc,'DT_RUNPATH - Library search path')
        elif opr==30: ApplyComment(loc,'DT_FLAGS - Flags for the object being loaded')
        elif opr==31: ApplyComment(loc,'DT_ENCODING - Start of encoded range')
        elif opr==32: ApplyComment(loc,'DT_PREINIT_ARRAY - Array with addresses of preinit fct'); Rebase(loc+8);ApplyStruct(loc,'Elf64_Dyn_Link')
        elif opr==33: ApplyComment(loc,'DT_PREINIT_ARRAYSZ - size in bytes of DT_PREINIT_ARRAY')
        elif opr==34: ApplyComment(loc,'DT_NUM - Number used')
        elif opr==0x6000000d: ApplyComment(loc,'DT_LOOS - Start of OS-specific')
        elif opr==0x6ffff000: ApplyComment(loc,'DT_HIOS - End of OS-specific ')
        elif opr==0x70000000: ApplyComment(loc,'DT_LOPROC - Start of processor-specific')
        elif opr==0x7fffffff: ApplyComment(loc,'DT_HIPROC - End of processor-specific')
        elif opr==0x6ffffe00: ApplyComment(loc,'DT_ADDRRNGLO')
        elif opr==0x6ffffef5: ApplyComment(loc,'DT_GNU_HASH - GNU-style hash table.'); Rebase(loc+8);ApplyStruct(loc,'Elf64_Dyn_Link')
        elif opr==0x6ffffef6: ApplyComment(loc,'DT_TLSDESC_PLT')
        elif opr==0x6ffffef7: ApplyComment(loc,'DT_TLSDESC_GOT')
        elif opr==0x6ffffef8: ApplyComment(loc,'DT_GNU_CONFLICT - Start of conflict section')
        elif opr==0x6ffffef9: ApplyComment(loc,'DT_GNU_LIBLIST - Library list')
        elif opr==0x6ffffefa: ApplyComment(loc,'DT_CONFIG - Configuration information.')
        elif opr==0x6ffffefb: ApplyComment(loc,'DT_DEPAUDIT - Dependency auditing.')
        elif opr==0x6ffffefc: ApplyComment(loc,'DT_AUDIT - Object auditing.')
        elif opr==0x6ffffefd: ApplyComment(loc,'DT_PLTPAD - PLT padding.')
        elif opr==0x6ffffefe: ApplyComment(loc,'DT_MOVETAB - Move table.')
        elif opr==0x6ffffeff: ApplyComment(loc,'DT_SYMINFO - Syminfo table.'); Rebase(loc+8);ApplyStruct(loc,'Elf64_Dyn_Link')
        elif opr==0x6ffffeff: ApplyComment(loc,'DT_ADDRRNGHI')
        elif opr==0x6ffffff9: ApplyComment(loc,'DT_RELACOUNT - Number of Rela relocs')
        elif opr==0x6ffffffa: ApplyComment(loc,'DT_RELCOUNT')
        elif opr==0x6ffffffb: ApplyComment(loc,'DT_FLAGS_1')
        elif opr==0x6ffffffc: ApplyComment(loc,'DT_VERDEF')
        elif opr==0x6ffffffd: ApplyComment(loc,'DT_VERDEFNUM')

def analysisRELA():
    if notFound(DT_RELACOUNT) or notFound(DT_RELA) or notFound(DT_PLTRELSZ) or notFound(DT_JMPREL): return
    if ida_kernwin.ask_yn(False, 'HIDECANCEL\nConstruct the Rela relocs Table? %d elements\n(Need a long time!)'%DT_RELACOUNT)==1:
        ApplyStructArray(DT_RELA,'Elf64_Rela',DT_RELACOUNT)
        ApplyStructArray(DT_JMPREL,'Elf64_Rela',DT_PLTRELSZ//0x18)
    if ida_kernwin.ask_yn(False, 'HIDECANCEL\nMake Function by the Rela relocs Table? %d elements\n(May need more than 1 hour!)'%DT_RELACOUNT)==1:
        for i in range(DT_RELACOUNT):
            Rebase(DT_RELA+i*0x18)
            Rebase(DT_RELA+i*0x18+0x10)
            funcAddr=GetQword(DT_RELA+i*0x18+0x10)
            if ida_funcs.get_func(funcAddr)==None:
                Show('Make Function at 0x%X ( %d / %d )'%(funcAddr,i,DT_RELACOUNT))
                AddFunc(funcAddr)
        ida_kernwin.hide_wait_box()

def ExtractProperty(propertyAddr,indent='',baseOffset=0):
    extraInfo=''
    propertyName=idc.get_strlit_contents(GetQword(propertyAddr)).decode()
    typeID=GetDword(propertyAddr+0x18)
    propertyOffset=GetDword(propertyAddr+0x24)
    # Debug(hex(propertyAddr),propertyName,typeID,hex(propertyOffset))
    if typeID==0:
        propertyType='Byte'
    elif typeID==0x2:
        propertyType='u16'
    elif typeID==0x3:
        propertyType='u32'
    elif typeID==0x5:
        propertyType='s16'
    elif typeID==0x6:
        propertyType='s32'
    elif typeID==0xA:
        propertyType='Float'
    elif typeID==0xB:
        propertyType='Double'
    elif typeID==0xC:
        setterAddr=GetQword(propertyAddr+0x30)
        if idc.print_insn_mnem(setterAddr)=='ADD':
            propertyOffset=idc.get_operand_value(setterAddr,2)
            bit=idc.get_operand_value(setterAddr+8,2)
        else:
            propertyOffset=idc.get_operand_value(setterAddr,1)
            if idc.get_operand_value(setterAddr+4,2)>0:
                bit=idc.get_operand_value(setterAddr+4,2)
            else:
                bit=idc.get_operand_value(setterAddr+0x10,2)//0x100000000
                propertyOffset+=4
        while bit>=256:
            propertyOffset+=1
            bit=bit//256
        propertyType='bool^%d'%int(math.log2(bit)) if bit>0 else 'unknown %s'%bit        
    elif typeID==0xE:
        propertyType='Component'
    elif typeID==0x11:
        propertyType='Class'
    elif typeID==0x12:
        propertyType='Object'
        extraInfo="SDK('%s')"%idc.get_name(GetQword(propertyAddr+0x28)).replace('_Loader','')
    elif typeID==0x14:
        propertyType='Name'
    elif typeID==0x15:
        propertyType='String'
    elif typeID==0x16:
        propertyType='Array'
    elif typeID==0x17:
        propertyType='List'
    elif typeID==0x18:
        propertyType='Set'
    elif typeID==0x19:
        structName=idc.get_name(GetQword(propertyAddr+0x28)).replace('Struct_','').replace('_Loader','')
        extraInfo="SDK('%s')"%structName
        size=GetDword(idc.get_name_ea(codeStart,'Struct_%s_Class'%structName)+0x20)
        propertyType='Struct(%X)'%size
        '''
        structClass=idc.get_name_ea(dataStart,'Struct_%s_Class'%structName)
        propertiesAddr=GetQword(structClass+0x30)
        propertiesCount=GetDword(structClass+0x38)
        for i in reversed(range(propertiesCount)) if reverseSDK else range(propertiesCount):
            argAddr=GetQword(propertiesAddr+i*8)
            (argName,argType,argOffset,argExtraInfo)=ExtractProperty(argAddr,indent+'    ',baseOffset+propertyOffset)
            if propertyOffset==0: #StructArray
                # propertyOffset=GetDword(propertyAddr-0xC)
                extraInfo+='\n     \t%s+%02X: %s \t%s (%X)\t%s'%(indent,argOffset,argType,argName,argAddr,argExtraInfo)
            else:
                extraInfo+='\n     \t%s+%02X(%X): %s \t%s (%X)\t%s'%(indent,argOffset,baseOffset+propertyOffset+argOffset,argType,argName,argAddr,argExtraInfo)
                '''
    elif typeID==0x1B:
        propertyType='M.Delegate'
    elif typeID==0x1C:
        propertyType='Event'
    elif typeID==0x1D:
        propertyType='Vector'
    elif typeID==0x1E:
        propertyType='Enum'
        enumName=idc.get_name(GetQword(propertyAddr+0x28)).replace('Enum_','').replace('_Loader','')
        extraInfo="SDK('%s')"%enumName
        # enumClass=idc.get_name_ea(dataStart,'Enum_%s_Class'%enumName)
        # if enumName[:4]=='sub_' or notFound(enumClass): 
            # loaderAddr=GetQword(propertyAddr+0x28)
            # x1=SearchNextASM(loaderAddr,'ADRL','X1')
            # enumClass=idc.get_operand_value(x1,1)
            # enumName=ExtractEnum(enumClass)
            # Patch(loaderAddr,'%s_Loader'%enumName,propertyAddr+0x28)
            # x0=SearchPrevASM(GetFuncEnd(loaderAddr),'MOV','X0')
            # if isFound(x0):
                # pointerAddr=SearchPrevASM(x0,'ADRL',idc.print_operand(x0,1))
                # if isFound(pointerAddr): Patch(idc.get_operand_value(pointerAddr,1),'%s_Pointer'%enumName,pointerAddr)
                # refs=idautils.XrefsTo(loaderAddr,0)
                # for jumpAddr in refs:
                    # if isFunc(jumpAddr.frm):
                        # Patch(GetFuncStart(jumpAddr),'pre_'+enumName,loaderAddr)
        # enumAddr=GetQword(enumClass+0x20)
        # enumCount=GetDword(enumClass+0x28)
        # extraInfo='\n'+'\n'.join(indent+'\t\t%2d: %s'%(GetQword(enumAddr+i*16+8),idc.get_strlit_contents(GetQword(enumAddr+i*16)).decode()) for i in range(enumCount))
    elif typeID==0x2C:
        propertyType='bool'
        setterAddr=GetQword(propertyAddr+0x30)
        propertyOffset=idc.get_operand_value(setterAddr+4,1)
    else:
        propertyType=hex(typeID)
    return (propertyName,propertyType,propertyOffset,extraInfo)

def ExploreScript(funcAddr,fullFuncName):
    ArgsCount=GetDword(funcAddr+0x38)
    ArgsAddr=GetDword(funcAddr+0x30)
    buffer=lastInfo=lastType=''
    for i in range(ArgsCount):
        argAddr=GetQword(ArgsAddr+i*8)
        (argName,argType,argOffset,extraInfo)=ExtractProperty(argAddr)
        if argName=='UnderlyingType': continue
        if argType in ('Array','Set','List'): 
            argType=lastType+argType
            extraInfo=lastInfo
        else:
            msg(buffer)
        lastType=argType
        lastInfo=extraInfo
        buffer='%+8X%12s\t%s.%s (%X) %s\n'%(argOffset,argType,fullFuncName,argName,argAddr,extraInfo)
    msg(buffer)

def ExtractFunction(funcAddr,parentName):
    funcName=idc.get_strlit_contents(GetQword(funcAddr+0x10)).decode()
    fullFuncName='%s.%s'%(parentName,funcName)
    ArgsCount=GetDword(funcAddr+0x38)
    ArgsAddr=GetDword(funcAddr+0x30)
    buffer=lastInfo=lastType=''
    for i in range(ArgsCount):
        argAddr=GetQword(ArgsAddr+i*8)
        (argName,argType,argOffset,extraInfo)=ExtractProperty(argAddr)
        if argName=='UnderlyingType': continue
        if argType in ('Array','Set','List'): 
            argType=lastType+argType
            extraInfo=lastInfo
        else:
            msg(buffer)
        lastType=argType
        lastInfo=extraInfo
        buffer='%+8X%12s\t%s.%s (%X) %s\n'%(argOffset,argType,fullFuncName,argName,argAddr,extraInfo)
    msg(buffer)
    
def SDKFunc(func,simple=False): # check('UDataTableFunctionLibrary.GetDataTableRowFromName')
    msg('%X: %s'%(idc.get_name_ea(codeStart,func),func))
    msg('(' if simple else '\n') 
    realAddr=idc.get_name_ea(codeStart,func+'_core')
    if isFound(realAddr) and not simple: msg('\n%X: %s_core\n'%(realAddr,func))
    classAddr=idc.get_name_ea(dataStart,func+'_Class')
    if isFound(classAddr):
        argsCount=GetDword(classAddr+0x38)
        argsAddr=GetQword(classAddr+0x30)
        hasBuffer=False
        comma=''
        for j_argAddr in range(argsAddr+argsCount*8-8,argsAddr-8,-8) if reverseSDK else range(argsAddr,argsAddr+argsCount*8,8):
            argAddr=GetQword(j_argAddr)
            (argName,argType,argOffset,extraInfo)=ExtractProperty(argAddr)
            if hasBuffer: 
                (lastargAddr,lastargType,lastargName,lastargOffset,lastextraInfo)=lastrecord
                if argType in ('Array','Set','List'): 
                    msg(comma+argType if simple else '%+7X%13s    %s (%X) %s\n     '%(argOffset,argType,argName,argAddr,extraInfo))
                    comma='_'
                if lastargName!='UnderlyingType' and lastargType not in ('Array','Set','List'): 
                    msg(comma+lastargName if simple else '%+7X%13s    %s (%X) %s\n'%(lastargOffset,lastargType,lastargName,lastargAddr,lastextraInfo))
                    comma=', '
            lastrecord=(argAddr,argType,argName,argOffset,extraInfo)
            hasBuffer=True
        if hasBuffer and argType not in ('Array','Set','List'): 
            msg(comma+argName if simple else '%+7X%13s    %s (%X) %s\n\n'%(argOffset,argType,argName,argAddr,extraInfo))
        if simple:msg(')\n')

def SDKStruc(structName,offset=0): # check('UDataTableFunctionLibrary.GetDataTableRowFromName')
    structClass='Struct_%s_Class'%structName
    classAddr=idc.get_name_ea(codeStart,structClass)
    if isFound(classAddr): 
        size=GetDword(classAddr+0x20)
        print('%X: %s (size=0x%X)'%(classAddr,structClass,size))
        propertiesAddr=GetQword(classAddr+0x30)
        propertiesCount=GetDword(classAddr+0x38)
        for i in reversed(range(propertiesCount)) if reverseSDK else range(propertiesCount):
            argAddr=GetQword(propertiesAddr+i*8)
            (argName,argType,argOffset,argExtraInfo)=ExtractProperty(argAddr)
            if offset:
                print('%+8X(+%X): %s \t%s (%X)\t%s'%(argOffset,argOffset+offset,argType,argName,argAddr,argExtraInfo))
            else:
                print('%+8X: %s \t%s (%X)\t%s'%(argOffset,argType,argName,argAddr,argExtraInfo))
    print()

def SDKEnum(enumName):
    enumClass='Enum_%s_Class'%enumName
    classAddr=idc.get_name_ea(codeStart,enumClass)
    if isFound(classAddr): 
        print('%X: %s'%(classAddr,enumClass))
        enumAddr=GetQword(classAddr+0x20)
        enumCount=GetDword(classAddr+0x28)
        for itemAddr in range(enumAddr+enumCount*0x10-0x10,enumAddr-0x10,-0x10) if reverseSDK else range(enumAddr,enumAddr+enumCount*0x10,0x10):
            itemName=GetASCstr(GetQword(itemAddr))
            itemIdx=GetDword(itemAddr+8)
            print('\t%2d: %s'%(itemIdx,itemName))
    print()

def SDK(classname='AActor',listFunc=True,listChildren=True ):
    classAddr=idc.get_name_ea(dataStart,classname+'_Class')
    if notFound(classAddr):
        if isFound(idc.get_name_ea(dataStart,'Enum_'+classname+'_Class')): return SDKEnum(classname)
        if isFound(idc.get_name_ea(dataStart,'Struct_'+classname+'_Class')): return SDKStruc(classname)
        Explore(classname)
        classAddr=idc.get_name_ea(dataStart,classname+'_Class')
        if notFound(classAddr):
            Warning('%s not found'%classname)
            return
    else:
        if '.' in classname: return SDKFunc(classname)
    # jumpto(classAddr)
    parentCount=GetDword(classAddr+0x38)
    parentAddr=idc.get_name_ea(dataStart,classname+'_Parents')
    fullclassname=classname
    closeparent=None
    for i in range(parentCount):
        parentName=idc.get_name(GetQword(parentAddr+i*8)).replace('_Loader','')
        if closeparent is None: closeparent=parentName
        fullclassname=parentName+'.'+fullclassname
    if closeparent is not None and closeparent not in ('UObject','UEngine','UClass'): SDK(closeparent,listFunc,False)
    print('\t\t%s (%X)'%(fullclassname,classAddr))

    buffer=lastInfo=lastType=''
    propertiesCount=GetDword(classAddr+0x40)
    propertiesAddr=idc.get_name_ea(dataStart,classname+'_Properties')
    for i in reversed(range(propertiesCount)) if reverseSDK else range(propertiesCount):
        propertyAddr=GetQword(propertiesAddr+i*8)
        (propertyName,propertyType,propertyOffset,extraInfo)=ExtractProperty(propertyAddr)
        if propertyName=='UnderlyingType': continue
        if propertyType in ('Array','Set','List'): 
            propertyType=lastType+propertyType
            extraInfo=lastInfo
        # elif propertyType in ('Struct'): 
            # extraInfo='
        elif propertyName[-8:]=='List_Key': 
            propertyType=lastType
            extraInfo=lastInfo
        else:
            msg(buffer)
        lastType=propertyType
        lastInfo=extraInfo
        buffer='%+8X%12s\t%s.%s (%X) %s\n'%(propertyOffset,propertyType,classname,propertyName,propertyAddr,extraInfo)
    msg(buffer)
    if listFunc:
        print()
        methodsCount=GetDword(classAddr+0x3C)
        methodsAddr=idc.get_name_ea(codeStart,classname+'_Methods')
        for i in range(methodsCount):
            methodName=idc.get_strlit_contents(GetQword(methodsAddr+i*16+8)).decode()
            methodAddr=idc.get_name_ea(codeStart,'%s.%s_Class'%(classname,methodName))
            funcAddr=idc.get_name_ea(codeStart,'%s.%s'%(classname,methodName)) & 0xFFFFFFFF
            # memoryAddr=idc.get_name(methodName+'_Pointer')
            pointerAddr=BADADDR
            addr=SearchPrevASM(GetFuncEnd(GetQword(methodsAddr+i*16)),'MOV','X0')
            if isFound(addr):
                addr=SearchPrevASM(addr,'ADRL',idc.print_operand(addr,1))
                if isFound(addr): pointerAddr=idc.get_operand_value(addr,1)
            SDKFunc(classname+'.'+methodName, True)
            # msg("%8X%12s\t%s.%s (%X) SDKFunc('%s.%s')\n"%(funcAddr,'function',classname,methodName,pointerAddr,classname,methodName))
            # ExtractFunction(methodAddr,classname)
        FListCount=GetDword(classAddr+0x44)
    print()
    if listChildren: msg('Children of %s: '%classname);FindChildren(classname)

def FindChildren(classname='AActor'):
    classAddr=idc.get_name_ea(dataStart,classname+'_Loader')
    xrefs=list(idautils.XrefsTo(classAddr))
    if notFound(classAddr):
        Explore(classname)
        classAddr=idc.get_name_ea(dataStart,classname)
        if notFound(classAddr):
            Warning('%s not found'%classname)
            return
    results=[]
    for ref in xrefs:
        if not(dataStart<ref.frm<dataEnd): continue
        FindChildrenName=idc.get_name(ref.frm)
        if not('_Parents' in FindChildrenName): continue
        results.append(FindChildrenName.replace('_Parents',''))
    print(', '.join(results))
    
def GetFuncName(name):
    assetsAddr=idc.get_name_ea(codeStart,'%s_Assets'%name)
    loaderAddr=idc.get_name_ea(codeStart,'%s_FList_Constructor'%name)
    if notFound(loaderAddr): loaderAddr=idc.get_name_ea(codeStart,'%s_Constructor'%name)
    p(loaderAddr)
    x8=AOB('? ? ? ? ? ? ? 91 FD 7B 44 A9 E2 00 80 52 FF ? ? 91',loaderAddr,GetFuncEnd(loaderAddr))
    if isFound(x8):
        fListAddr=idc.get_operand_value(x8,1)
    else:
        x10=AOB('? ? ? 34 ? ? ? ? ? ? ? 91 6A ? ? F9 ? 00 80 52 ? ? ? ? ? ? ? 91',loaderAddr,GetFuncEnd(loaderAddr))
        if isFound(x10):
            offset=idc.get_operand_value(x10+0xC,1)
            x19=AOB('? ? ? ? ? ? ? 91 A0 ? ? F9 E0 03 13 AA ? ? ? 94',loaderAddr,GetFuncEnd(loaderAddr))
            fListAddr=idc.get_operand_value(x19,1)+offset
        else:
            x8=AOB('? ? ? ? ? ? ? 91 1F A1 00 39 0B ? ? 52',loaderAddr,GetFuncEnd(loaderAddr))
            if isFound(x8):
                r=idc.print_operand(x8,0)
                stp=SearchNextASM(x8,'STP',None,None,r)
                fListAddr=idc.get_operand_value(stp,2)+idc.get_operand_value(x8,1)
            else:
                x8=AOB('? ? ? ? ? ? ? 91 A0 0F 00 F9 E0 03 13 AA ? ? ? 94',loaderAddr,GetFuncEnd(loaderAddr))
                r=idc.print_operand(x8,0)
                str=SearchNextASM(x8,'STR',None,r)
                fListAddr=idc.get_operand_value(str,1)+idc.get_operand_value(x8,1)
    p("extractUFuncList(0x%X,'%s',0x%X)"%(fListAddr,name,assetsAddr))
def extractUFuncList(addr,name,flist=None):
    print()
    addr=base+addr
    while GetQword(addr)!=0 and GetQword(addr+8)!=0 and GetQword(addr+0x30) in (2,3):  
        methodName='%s.%s'%(name,GetASCstr(GetQword(addr)))
        ApplyComment(addr,methodName)
        ApplyStruct(addr,'FuncMap')
        jfuncAddr=GetQword(addr+8)
        AddFunc(jfuncAddr)
        Patch(jfuncAddr,'j_%s'%methodName,addr)
        if GetQword(addr+0x18)==0:
            funcAddr=GetQword(addr+0x10)
            AddFunc(funcAddr)
            Patch(funcAddr,methodName,addr)
        else:
            if flist!=None:
                funcAddr=GetQword(base+flist+GetQword(addr+0x10))
                AddFunc(funcAddr)
                Patch(funcAddr,methodName,addr)
        addr+=0x38
def ListUAssets():
    UObjectBuilders=list(idautils.CodeRefsTo(GetUObjectBuilder(),0))
    total=len(UObjectBuilders)
    current=0
    for bl_UObjectBuilder in UObjectBuilders:
        current+=1
        UObjectName=ida_funcs.get_func_name(bl_UObjectBuilder).replace('_Loader','')
        asset_ea=idc.get_name_ea(dataStart,UObjectName+'_Assets')
        if isFound(asset_ea): 
            if GetQword(asset_ea)==0: asset_ea+=0x10
            print("Patch(0x%X, '%s')"%(asset_ea,UObjectName+'_Assets'))
def Rebuild(isManual=True):
    if not isManual and ReBuildStruct==False: return 
    BuildPackages()
    BuildUObjects()
    BuildMethods()
    BindUFunctions()
    BuildStructures()
    BuildEnums()
    print()
    Warning('Done')
    
ReBuildStruct=None
base=GetBase()
codeStart=GetCodeStart()
codeEnd=GetCodeEnd()
dataStart=GetDataStart()
dataEnd=GetDataEnd()
cls()
Show('Analysis begins')

if not isGDB():
    if ida_segment.get_segm_by_name('.dynamic') is None:
        elfSegment()
    else:
        nsoSegment()

    dynamicStart=ida_segment.get_segm_by_name('.dynamic').start_ea
    dynamicEnd=ida_segment.get_segm_by_name('.dynamic').end_ea
    dynCount=(dynamicEnd-dynamicStart)//0x10
    DT_RELACOUNT=DT_RELA=DT_RELASZ=DT_JMPREL=DT_PLTRELSZ=DT_STRTAB=DT_STRSZ=BADADDR
    for i in range(dynCount): 
        loc=dynamicStart+i*0x10
        opr=GetQword(loc)
        if opr==5: DT_STRTAB=GetQword(loc+8)
        if opr==10: DT_STRSZ=GetQword(loc+8)
        if opr==2: DT_PLTRELSZ=GetQword(loc+8)
        elif opr==7: DT_RELA=GetQword(loc+8)
        elif opr==8: DT_RELASZ=GetQword(loc+8)
        elif opr==23: DT_JMPREL=GetQword(loc+8)
        elif opr==0x6ffffff9: DT_RELACOUNT=GetQword(loc+8)
    AsciiSTRstart=dataStart if notFound(DT_STRTAB) else DT_STRTAB
    # AsciiSTRend=dynamicStart if notFound(DT_STRTAB) or notFound(DT_STRSZ) else DT_STRTAB+DT_STRSZ
    AsciiSTRend=ida_segment.get_segm_by_name('.eh_frame_hdr').start_ea
    SetAsciiRange(AsciiSTRstart,AsciiSTRend)
    
    RELAstart=DT_RELA
    RELAend=DT_RELA+DT_RELASZ
    GOTstart=ida_segment.get_segm_by_name('.got').start_ea
    GOTend=ida_segment.get_segm_by_name('.got').end_ea
    UTF16start=ida_search.find_binary(dataStart, GOTstart, '55 00 54 00 46 00 38 00 4F 00 75 00 74 00 70 00', 0, idc.SEARCH_DOWN)
    if notFound(UTF16start):
        UTF16start=idc.get_operand_value(AOB('? ? ? ? ? ? ? 91 E0 03 16 AA ? ? ? 94 40 00 00 36'),1)
    UTF16end=ida_search.find_binary(UTF16start, GOTstart, '3C 00 53 00 63 00 61 00 6C 00 65 00 3E 00 00 00', 0, idc.SEARCH_DOWN)
    if notFound(UTF16end):
        UTF16end=AOB('0 0 20 00 6E 00 6F 00 74 00 20 00 69 00 6E 00 20 00 0 0',UTF16start,ida_segment.get_segm_by_name('.eh_frame_hdr').start_ea)
    if isFound(UTF16end):
        UTF16end=AOB('00 00 00 00 00',UTF16end,ida_segment.get_segm_by_name('.eh_frame_hdr').start_ea)+3
        
    # if ida_kernwin.ask_yn(False, 'HIDECANCEL\nFix the Strings\nrun once only')==1:
        # if dataStart<UTF16start<dataEnd and dataStart<UTF16end<dataEnd: fixUTF16() # run once only
        # if dataStart<AsciiSTRstart<dataEnd and dataStart<AsciiSTRend<dataEnd: fixAscString() # run once only

#analysisRELA()


    # if not(isDebug):
        # print('import idc, ida_segment, ida_bytes')
        # print('FF_OFFSET=ida_bytes.FF_QWORD|FF_DATA|ida_bytes.off_flag();FF_DEC=ida_bytes.FF_DWORD|FF_DATA|ida_bytes.dec_flag()')
        # print("codeStart=ida_segment.get_segm_by_name('.text' if ida_segment.get_segm_by_name('main')==None else 'main').start_ea")
        # print("codeEnd=ida_segment.get_segm_by_name('.text' if ida_segment.get_segm_by_name('main')==None else 'main').end_ea")
        # print("dataStart=ida_segment.get_segm_by_name('.data' if ida_segment.get_segm_by_name('main_data')==None else 'main_data').start_ea")
        # print("dataEnd=ida_segment.get_segm_by_name('.data' if ida_segment.get_segm_by_name('main_data')==None else 'main_data').end_ea")
        # print('def p(x): print(hex(x) if isinstance(x, int) else x)')
        # print('def Patch(targetAddr,newName,ref=None): targetAddr+=codeStart;set_name(targetAddr, newName, 0x3981)')
        # print()

    if notFound(UTF16start) or notFound(UTF16end):
        Warning('UTF String range cannot be defined! This nso/elf is not supported!')
    else:
        SetUTFRange(UTF16start,UTF16end)

        createStructs()
        # if dataStart<UTF16start<dataEnd and dataStart<UTF16end<dataEnd: fixUTF16(False) # run once only
        # if dataStart<AsciiSTRstart<dataEnd and dataStart<AsciiSTRend<dataEnd: fixAscString(False) # run once only
        Rebuild(False)
        # else:
            # Rebuild()

            # cls()
            # UEngine.UActorComponent.UMovementComponent.UNavMovementComponent.UPawnMovementComponent.UCharacterMovementComponent
            # SDK('UEngine')
            # SDK('UActorComponent')
            # SDK('UMovementComponent')
            # SDK('UNavMovementComponent')
            # SDK('UPawnMovementComponent')
            # SDK('UCharacterMovementComponent')
            # UEngine.UObject.AActor.APawn.ACharacter.APaperCharacter
            # print('\n\n ================================================================ \n\n')
            # SDK('AActor')
            # SDK('APawn')
            # SDK('ACharacter')
            # SDK('APaperCharacter')
            # print('\n\n ================================================================ \n\n')
            # SDK('AActor')
            # SDK('AController')
            # SDK('APlayerController')
            # print('\n\n ================================================================ \n\n')
            # SDK('AActor')
            # SDK('AController')
            # SDK('AAIController')
            # print('\n\n ================================================================ \n\n')
            # SDK('AActor')
            # SDK('AInfo')
            # SDK('AGameModebase')
            # SDK('AGameMode')
            # SDK('AARSharedWorldGameMode')
            # print('\n\n')
        juGameEngine = GetADRP(AOB('08 ? ? F9 13 01 40 F9 ? ? 00 B4 ? ? ? ? 68 0A 40 F9',0x2000,0x3000))
        # juWorld = GetADRP(AOB('08 ? ? F9 00 01 40 F9 A0 00 00 B4 ? ? ? 94'))
        juWorld = GetADRP(AOB('08 ? ? F9 00 01 40 F9 ? ? 00 B4 ? ? ? ? 08 04 00 51',0x2000,0x3000))
        if notFound(juGameEngine) or notFound(juWorld):
            print('UGameEngine or UWorld not found!')
            print('\nYou may type "Rebuild()" to rebuild the UClass and GNames')
        else:
            uGameEngine = GetQword(juGameEngine) 
            uWorld = GetQword(juWorld)
            Patch(juGameEngine,'j_uGameEngine_pointer')
            Patch(juWorld,'j_UWorld_pointer')
            Patch(uGameEngine,'uGameEngine_pointer')
            Patch(uWorld,'uWorld_pointer')
            uGameInstanceOffset=GetDword(get_name_ea(dataStart,'UWorld.OwningGameInstance')+0x24)
            uLocalPlayersOffset=GetDword(get_name_ea(dataStart,'UGameInstance.LocalPlayers')+0x54)
            aPlayerControllerOffset=GetDword(get_name_ea(dataStart,'UPlayer.PlayerController')+0x24)
            aCharacterOffset=GetDword(get_name_ea(dataStart,'AController.Character')+0x24)
            acknowledgedPawnOffset=GetDword(get_name_ea(dataStart,'APlayerController.AcknowledgedPawn')+0x24)
            uCharacterMovementComponentOffset=GetDword(get_name_ea(dataStart,'ACharacter.CharacterMovement')+0x24)
            MaxWalkSpeedOffset=GetDword(get_name_ea(dataStart,'UCharacterMovementComponent.MaxWalkSpeed')+0x24)
            MaxSwimSpeedOffset=GetDword(get_name_ea(dataStart,'UCharacterMovementComponent.MaxSwimSpeed')+0x24)
            MaxFlySpeedOffset=GetDword(get_name_ea(dataStart,'UCharacterMovementComponent.MaxFlySpeed')+0x24)
            GravityScaleOffset=GetDword(get_name_ea(dataStart,'UCharacterMovementComponent.GravityScale')+0x24)
            JumpZVelocityOffset=GetDword(get_name_ea(dataStart,'UCharacterMovementComponent.JumpZVelocity')+0x24)
            JumpOffJumpZFactorOffset=GetDword(get_name_ea(dataStart,'UCharacterMovementComponent.JumpOffJumpZFactor')+0x24)
            print('uGameInstance = ptr((0x%X, 0x%X, 0))'%(uWorld,uGameInstanceOffset))
            print('acknowledgedPawn = ptr((0x%X, 0x%X, 0x%X, 0, 0x%X, 0x%X, 0))'%(uWorld,uGameInstanceOffset,uLocalPlayersOffset,aPlayerControllerOffset,acknowledgedPawnOffset))
            print('UCharacterMovementComponent.MaxWalkSpeed = ptr((0x%X, 0x%X, 0x%X, 0, 0x%X, 0x%X, 0x%X, 0x%X))'%(uWorld,uGameInstanceOffset,uLocalPlayersOffset,aPlayerControllerOffset,aCharacterOffset,uCharacterMovementComponentOffset,MaxWalkSpeedOffset))
            print()
            print('You may type "SDK(\'UCharacterMovementComponent\')" in below')
            print('or you can copy the above ptr((XXXXXX)) statement onto another isGDB() instance after loading UEngine.py')
            print()
            print('here with cheat code for testing\n')
            from cheatLib import PointerCodeHeader, PointerCodeBody
            print('{UCharacterMovementComponent}')
            print(PointerCodeHeader((uWorld,uGameInstanceOffset,uLocalPlayersOffset,0,aPlayerControllerOffset,aCharacterOffset,uCharacterMovementComponentOffset)))
            print('[MaxWalkSpeed]')
            print(PointerCodeBody(MaxWalkSpeedOffset,4, Float2DWord(100)))
            print('[MaxSwimSpeed]')
            print(PointerCodeBody(MaxSwimSpeedOffset,4, Float2DWord(100)))
            print('[MaxFlySpeed]')
            print(PointerCodeBody(MaxFlySpeedOffset,4, Float2DWord(100)))
            print('[GravityScale]')
            print(PointerCodeBody(GravityScaleOffset,4, Float2DWord(0.5)))
            print('[JumpZVelocity]')
            print(PointerCodeBody(JumpZVelocityOffset,4, Float2DWord(50)))
            print('[JumpOffJumpZFactor]')
            print(PointerCodeBody(JumpOffJumpZFactorOffset,4, Float2DWord(5)))


    

else:
    createStructs()
    
'''


^(.+)\t([0-9A-F]+)\tP?$
Patch\(0x$2, '$1'\)

`([a-z \-\.]+?)'
$1

'''